WARNING!!!

Run the following command to install the missing dependencies (to avoid import errors or warnings)!!

pip install umap-learn plotly PyQtWebEngine scipy



This gui has improved including PCA, LDA, t-SNE, and UMAP techniques with configurable parameters for each method.

Each technique provides:

Parameter input fields (e.g., n_components, perplexity, learning rate, metric, projection type)

Visualization of 2D/3D projections using Matplotlib and optional Plotly integration

Display of relevant metrics and interpretation on a side panel:

PCA → Explained variance ratios, cumulative variance with quality comment

LDA → Explained variance ratio and separation quality interpretation

t-SNE → Parameters summary and visual inspection note

UMAP → Silhouette, Davies-Bouldin, Calinski-Harabasz scores with qualitative feedback

This allows the user to compare and interpret different dimensionality reduction methods both visually and quantitatively.
