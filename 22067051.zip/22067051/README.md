# ML Course GUI – Development and Feature Update Report

This document summarizes the differences between the **initial version** and the **latest version** of the **Machine Learning Course GUI (MLCourseGUI)** application, highlighting newly added and improved features.

# Boston Housing Dataset Update

Since `sklearn.datasets.load_boston()` has been deprecated, the Boston Housing dataset is now fetched manually from  
`http://lib.stat.cmu.edu/datasets/boston`. These datasets are already provided as .csv files within a zip archive.


### 1. Loss Function Selector

- **For Regression**: `MSE`, `MAE`, and `Huber Loss` options are now available to the user.
- **For Classification**: `Cross-Entropy (log loss)` and `Hinge Loss` can be selected directly from the GUI.

**Purpose**: Enables users to select the most appropriate loss function for their problem.


### 2. Missing Data Handling

A new `missing_value_combo` dropdown was added with the following fill methods:

- Mean Imputation  
- Interpolation  
- Forward Fill  
- Backward Fill  

Additionally, a **"Compare Missing Data Methods"** button was introduced. This feature:

- Applies different imputation methods on datasets with missing values,  
- Trains a model for each method,  
- Displays the resulting accuracy scores as a bar chart.

### 3. Train-Test Split Settings

- `Shuffle` checkbox for enabling/disabling data shuffling.  
- `Seed` spinbox to make randomness reproducible.  
- `Stratified Split` option allows class-balanced data splitting (for classification tasks).

These settings apply to both built-in and custom datasets.

### 4. Additional Supported Models and Parameters

- **Support Vector Regression (SVR)** was added.  
- Each model panel was updated to include proper hyperparameter input fields.  
- The `train_model` function now handles regression and classification workflows separately.

### 5. Naive Bayes Prior Support

For the Naive Bayes panel:

- `Uniform` and `Custom` prior options were introduced.  
- Users can manually enter prior values like `[0.3, 0.7]`.  
- The system validates whether the total of custom priors equals 1 and shows an error if not.

##  Code Quality and Structural Improvements

- **Loss computation blocks** have been modularized.  
- **Model training processes** are now logically separated for regression and classification.  
- `update_metrics()` and `update_visualization()` behave dynamically based on the type of target variable (numeric vs categorical).  
- Utility functions like `apply_scaling()` and `apply_missing_value_handling()` have been centralized.

##  Summary

This version is not just a user-friendly GUI; it also:

- Helps students understand model training workflows,  
- Enables experimental comparisons,  
- Offers flexible preprocessing options suitable for real-world problems.

The latest version provides a more comprehensive platform for educational projects, lab work, and model experimentation.

##  Developer Info

- **Author:** Ceyda Bedir  
- **University:** Yıldız Technical University  
- **Department:** Mechatronics Engineering  
- **Focus Areas:** Machine Learning • Data Science • GUI Development
