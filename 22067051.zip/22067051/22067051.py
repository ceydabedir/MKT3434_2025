import sys
import numpy as np
import pandas as pd
from sklearn.metrics import silhouette_score
from sklearn.svm import SVC, SVR
from sklearn.metrics import log_loss, hinge_loss
from sklearn.preprocessing import label_binarize
from sklearn.metrics import log_loss, hinge_loss, mean_squared_error, mean_absolute_error, accuracy_score, confusion_matrix
from sklearn.preprocessing import label_binarize
import tensorflow.keras.backend as K
import matplotlib.pyplot as plt
import os
import json


from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QTabWidget, QPushButton, QLabel,
    QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
    QGroupBox, QScrollArea, QTextEdit, QStatusBar,
    QProgressBar, QCheckBox, QGridLayout, QMessageBox,
    QDialog, QLineEdit
)

from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, mean_squared_error, confusion_matrix
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from tensorflow.keras import regularizers
from tensorflow.keras.callbacks import EarlyStopping
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from tensorflow.keras.utils import to_categorical
from tensorflow.keras.models import model_from_json
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None

        # Regression and classification settings
        self.regression_loss_combo = None
        self.classification_loss_combo = None
        self.current_model = None

        # Neural network configurations
       # Neural network configurations
        self.mlp_layer_config = []      # MLP katmanları
        self.rnn_layer_config = []      # RNN katmanları
        self.cnn_layer_config = []      # CNN katmanları


        # Gradient histogram figure and canvas (matplotlib)
        from matplotlib.figure import Figure
        from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

        self.gradient_figure = Figure(figsize=(5, 3))
        self.gradient_canvas = FigureCanvas(self.gradient_figure)

        # Burada gradient_canvas'ı uygun layout veya widget'a eklemelisin
        # Örnek olarak, ana layouta ekliyorum:
        self.layout.addWidget(self.gradient_canvas)

        # Create UI components
        self.create_data_section()
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()

    

    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_group.setStyleSheet("""
            QGroupBox {
                background-color: #f8c8dc;
                border: 1px solid gray;
                border-radius: 5px;
                margin-top: 10px;
                padding: 10px;
            }
        """)

        viz_layout = QHBoxLayout()

        # 📊 Eğitim eğrisi için ana grafik
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)

        # 📈 Yeni: Gradient histogramı için ek alan
        self.grad_figure = Figure(figsize=(4, 3))
        self.grad_canvas = FigureCanvas(self.grad_figure)

        # 🧾 Eğitim metrikleri
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        self.metrics_text.setStyleSheet("""
            QTextEdit {
                background-color: #fffde7;
                border: 1px solid #ccc;
            }
        """)

        # Layout’a ekle
        viz_layout.addWidget(self.canvas, 1)
        viz_layout.addWidget(self.grad_canvas, 1)  # 👈 BU SATIR YENİ
        viz_layout.addWidget(self.metrics_text, 1)

        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)




    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            # Load selected dataset
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            # Split data
            
            test_size = self.split_spin.value()
            random_state = self.seed_spin.value() 
            shuffle = self.shuffle_checkbox.isChecked()
            
            use_stratify = self.stratified_checkbox.isChecked()
            stratify = data.target if use_stratify and len(np.unique(data.target)) < len(data.target) else None


            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(data.data, data.target,
                                                 test_size=test_size,
                                                 random_state=random_state,
                                                 shuffle=shuffle,
                                                 stratify=stratify)
            print("Train sınıf dağılımı:", np.unique(self.y_train, return_counts=True))
            print("Test sınıf dağılımı:", np.unique(self.y_test, return_counts=True))
            # Apply scaling if selected
            self.apply_scaling()
            
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")
    
    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                # Load data
                data = pd.read_csv(file_name)
                
                # Ask user to select target column
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                if pd.api.types.is_numeric_dtype(y):
                    unique_values = y.nunique()
                    if unique_values > 10:
                        msg = QMessageBox.question(
                            self,
                            "Sınıf Dönüştürme",
                            f"Hedef sütunu sürekli sayısal ({unique_values} farklı değer var).\n"
                            "Bunu sınıflandırma için otomatik olarak 2 sınıfa çevirmek ister misiniz?",
                            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                        if msg == QMessageBox.StandardButton.Yes:
                            median = y.median()
                            y = (y > median).astype(int)  # medyan üstü = 1, altı = 0
                            self.status_bar.showMessage("Hedef sütunu sınıflara dönüştürüldü (otomatik).")
                    # Split data
                    test_size = self.split_spin.value()
                    random_state = self.seed_spin.value()
                    shuffle = self.shuffle_checkbox.isChecked()
                
                    stratify = y if self.stratified_checkbox.isChecked() else None
                    (self.X_train, self.X_test, self.y_train, self.y_test) =  model_selection.train_test_split(      
                        X, y,
                        test_size=test_size,
                        random_state=random_state,
                        shuffle=shuffle,
                        stratify=y if self.stratified_checkbox.isChecked() else None)
                    print("Train sınıf dağılımı:", np.unique(self.y_train, return_counts=True))
                    print("Test sınıf dağılımı:", np.unique(self.y_test, return_counts=True))
                    # Apply scaling if selected
                    self.apply_scaling()
                    
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")
    
    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None
    
    def save_cnn_model(self):
        if not hasattr(self, "trained_model"):
            self.show_error("No trained CNN model to save.")
            return

        try:
            filename, _ = QFileDialog.getSaveFileName(self, "Save CNN Model", "", "H5 Files (*.h5)")
            if filename:
                self.trained_model.save(filename)
                self.status_bar.showMessage(f"CNN model saved to: {filename}")
        except Exception as e:
            self.show_error(f"Error saving CNN model: {str(e)}")



    def load_cnn_model(self):
        try:
            filename, _ = QFileDialog.getOpenFileName(self, "Load CNN Model", "", "Model files (*.h5)")
            if filename:
                self.cnn_trained_model = tf.keras.models.load_model(filename)
                self.status_bar.showMessage(f"Model loaded from: {filename}")
        except Exception as e:
            self.show_error(f"Error loading model: {str(e)}")





    
    
    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                self.X_train = scaler.fit_transform(self.X_train)
                self.X_test = scaler.transform(self.X_test)
                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")
    def apply_missing_value_handling(self):
        """Uygun eksik veri doldurma yöntemini uygula"""
        method = self.missing_value_combo.currentText()

        try:
            if method == "No Fill":
                return

            if method == "Mean Imputation":
                from sklearn.impute import SimpleImputer
                imputer = SimpleImputer(strategy="mean")
                self.X_train = imputer.fit_transform(self.X_train)
                self.X_test = imputer.transform(self.X_test)

            elif method == "Interpolation":
                self.X_train = pd.DataFrame(self.X_train).interpolate().values
                self.X_test = pd.DataFrame(self.X_test).interpolate().values

            elif method == "Forward Fill":
                self.X_train = pd.DataFrame(self.X_train).fillna(method="ffill").values
                self.X_test = pd.DataFrame(self.X_test).fillna(method="ffill").values

            elif method == "Backward Fill":
                self.X_train = pd.DataFrame(self.X_train).fillna(method="bfill").values
                self.X_test = pd.DataFrame(self.X_test).fillna(method="bfill").values

            self.status_bar.showMessage(f"Applied missing value method: {method}")

        except Exception as e:
            self.show_error(f"Error handling missing values: {str(e)}")

    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_group.setStyleSheet("QGroupBox { background-color: #f8c8dc; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        data_layout = QVBoxLayout()

        row1 = QHBoxLayout()
        row2 = QHBoxLayout()

        # Dataset
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset", "Iris Dataset", "Breast Cancer Dataset",
            "Digits Dataset", "Boston Housing Dataset", "MNIST Dataset"
        ])
        self.dataset_combo.setFixedWidth(140)
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)

        self.load_btn = QPushButton("Load Data")
        self.load_btn.setFixedWidth(90)
        self.load_btn.clicked.connect(self.load_custom_data)

        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems(["No Scaling", "Standard Scaling", "Min-Max Scaling", "Robust Scaling"])
        self.scaling_combo.setFixedWidth(110)

        self.scaling_combo.setEditable(True)
        self.scaling_combo.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scaling_combo.setEditable(False)

        self.missing_value_combo = QComboBox()
        self.missing_value_combo.addItems(["No Fill", "Mean Imputation", "Interpolation", "Forward Fill", "Backward Fill"])
        self.missing_value_combo.setFixedWidth(100)

        self.missing_value_combo.setEditable(True)
        self.missing_value_combo.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.missing_value_combo.setEditable(False)

        self.compare_btn = QPushButton("Compare Missing Data Methods")
        self.compare_btn.setFixedWidth(200)
        self.compare_btn.clicked.connect(self.compare_missing_data_methods)

        # Test split and seed
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setSingleStep(0.05)
        self.split_spin.setValue(0.2)
        self.split_spin.setFixedWidth(70)

        self.shuffle_checkbox = QCheckBox("Shuffle")
        self.shuffle_checkbox.setChecked(True)

        self.seed_spin = QSpinBox()
        self.seed_spin.setRange(0, 9999)
        self.seed_spin.setValue(42)
        self.seed_spin.setFixedWidth(60)

        # Row 1
        row1.addWidget(QLabel("Dataset:"))
        row1.addWidget(self.dataset_combo)
        row1.addWidget(self.load_btn)
        row1.addWidget(QLabel("Scaling:"))
        row1.addWidget(self.scaling_combo)
        row1.addWidget(QLabel("Missing Values:"))
        row1.addWidget(self.missing_value_combo)
        row1.addWidget(self.compare_btn)
        row1.addWidget(QLabel("Test Split:"))
        row1.addWidget(self.split_spin)
        row1.addWidget(self.shuffle_checkbox)
        row1.addWidget(QLabel("Seed:"))
        row1.addWidget(self.seed_spin)
        row1.addStretch()

        self.stratified_checkbox = QCheckBox("Use Stratified Split (Classification Only)")

        # Yeni cross-validation bileşenleri (2. satıra ekliyoruz!)
        self.use_cv_checkbox = QCheckBox("Use Cross-Validation")
        self.use_cv_checkbox.setChecked(False)

        self.cv_train_ratio = QSpinBox()
        self.cv_train_ratio.setRange(10, 90)
        self.cv_train_ratio.setValue(70)
        self.cv_train_ratio.setSuffix("%")
        self.cv_train_ratio.setFixedWidth(70)

        self.cv_val_ratio = QSpinBox()
        self.cv_val_ratio.setRange(0, 40)
        self.cv_val_ratio.setValue(15)
        self.cv_val_ratio.setSuffix("%")
        self.cv_val_ratio.setFixedWidth(70)

        self.cv_test_ratio = QSpinBox()
        self.cv_test_ratio.setRange(10, 90)
        self.cv_test_ratio.setValue(15)
        self.cv_test_ratio.setSuffix("%")
        self.cv_test_ratio.setFixedWidth(70)

        self.kfold_checkbox = QCheckBox("Use K-Fold Cross-Validation")
        self.kfold_spin = QSpinBox()
        self.kfold_spin.setRange(2, 20)
        self.kfold_spin.setValue(5)


        # ✅ 2. satıra ekliyoruz
        row2.addWidget(self.use_cv_checkbox)
        row2.addWidget(QLabel("Train:"))
        row2.addWidget(self.cv_train_ratio)
        row2.addWidget(QLabel("Val:"))
        row2.addWidget(self.cv_val_ratio)
        row2.addWidget(QLabel("Test:"))
        row2.addWidget(self.cv_test_ratio)
        row2.addWidget(self.kfold_checkbox)
        row2.addWidget(QLabel("K:"))
        row2.addWidget(self.kfold_spin)
        row2.addStretch()

        self.kfold_spin.setEnabled(False)  # başlangıçta kapalı
        self.kfold_checkbox.stateChanged.connect(self.toggle_kfold_spin)

        self.use_cv_checkbox.stateChanged.connect(self.toggle_cv_spinboxes)
        self.cv_train_ratio.valueChanged.connect(self.validate_split_sum)
        self.cv_val_ratio.valueChanged.connect(self.validate_split_sum)
        self.cv_test_ratio.valueChanged.connect(self.validate_split_sum)

        self.cv_train_ratio.setEnabled(False)
        self.cv_val_ratio.setEnabled(False)
        self.cv_test_ratio.setEnabled(False)
        
        data_layout.addLayout(row1)
        data_layout.addLayout(row2)
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)

    def toggle_kfold_spin(self, state):
        enabled = (state == Qt.CheckState.Checked.value)
        self.kfold_spin.setEnabled(enabled)


    def toggle_cv_spinboxes(self, state):
        print(f"Checkbox durumu: {state}")
        enabled = (state == Qt.CheckState.Checked.value)
        self.cv_train_ratio.setEnabled(enabled)
        print(f"enabled: {enabled}")
        self.cv_val_ratio.setEnabled(enabled)
        self.cv_test_ratio.setEnabled(enabled)

    def compare_missing_data_methods(self):
        QMessageBox.information(self, "Info", "Compare Missing Data Methods özelliği henüz uygulanmadı.")

    def validate_split_sum(self):
        total = self.cv_train_ratio.value() + self.cv_val_ratio.value() + self.cv_test_ratio.value()
        if total > 100:
            QMessageBox.warning(self, "Invalid Split", "Total split percentage cannot exceed 100%.")

 

    
    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        # Create individual tabs
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab)
        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)
    
    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Regression section
        regression_group = QGroupBox("Regression")
        regression_group.setStyleSheet("QGroupBox { background-color: #fff9c4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        regression_layout = QVBoxLayout()
        
        # Linear Regression
        lr_group = self.create_algorithm_group(
            "Linear Regression",
            {"fit_intercept": "checkbox"})
             #"normalize": "checkbox"}
        #)
        regression_layout.addWidget(lr_group)
        
        # Logistic Regression
        logistic_group = self.create_algorithm_group(
            "Logistic Regression",
            {"C": "double",
             "max_iter": "int",
             "multi_class": ["ovr", "multinomial"]}
        )
        regression_layout.addWidget(logistic_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        layout.setColumnStretch(0, 1)
        layout.setColumnStretch(1, 1)


        # Support Vector Regression
        svr_group = self.create_algorithm_group(
        "Support Vector Regression",
        {
            "C": "double",
            "epsilon": "double",
            "kernel": ["linear", "rbf", "poly"]
        }
        )
        regression_layout.addWidget(svr_group)

        # Regression Loss Function Selector
        loss_layout = QHBoxLayout()
        loss_label = QLabel("Loss Function:")
        self.regression_loss_combo = QComboBox()
        self.regression_loss_combo.addItems(["MSE", "MAE", "Huber"])

        loss_layout.addWidget(loss_label)
        loss_layout.addWidget(self.regression_loss_combo)
        regression_layout.addLayout(loss_layout)


        # Classification section
        classification_group = QGroupBox("Classification")
        classification_group.setStyleSheet("QGroupBox { background-color: #bbdefb; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        classification_layout = QVBoxLayout()

        self.stratified_checkbox = QCheckBox("Use Stratified Split")
        classification_layout.addWidget(self.stratified_checkbox)
        
       # Naive Bayes (Özel panel)
        nb_group = QGroupBox("Naive Bayes")
        nb_layout = QVBoxLayout()

        # var_smoothing input
        smoothing_layout = QHBoxLayout()
        smoothing_layout.addWidget(QLabel("var_smoothing:"))
        smoothing_input = QDoubleSpinBox()
        smoothing_input.setRange(0.0, 1.0)
        smoothing_input.setSingleStep(0.001)
        smoothing_input.setValue(1e-9)
        smoothing_layout.addWidget(smoothing_input)
        nb_layout.addLayout(smoothing_layout)

        # Prior türü seçimi
        prior_layout = QHBoxLayout()
        prior_layout.addWidget(QLabel("Prior Type:"))
        self.nb_prior_combo = QComboBox()
        self.nb_prior_combo.addItems(["Uniform", "Custom"])
        prior_layout.addWidget(self.nb_prior_combo)
        nb_layout.addLayout(prior_layout)

        # Custom prior input
        prior_input_layout = QHBoxLayout()
        prior_input_layout.addWidget(QLabel("Custom Prior:"))
        self.nb_prior_input = QLineEdit()
        self.nb_prior_input.setPlaceholderText("[0.3, 0.7]")
        prior_input_layout.addWidget(self.nb_prior_input)
        nb_layout.addLayout(prior_input_layout)

        # Train butonu
        train_btn = QPushButton("Train Naive Bayes")
        train_btn.clicked.connect(lambda: self.train_naive_bayes(smoothing_input))
        nb_layout.addWidget(train_btn)



        nb_group.setLayout(nb_layout)
        classification_layout.addWidget(nb_group)

        
        # SVM
        svm_group = self.create_algorithm_group(
            "Support Vector Machine",
            {"C": "double",
             "kernel": ["linear", "rbf", "poly"],
             "degree": "int"}
        )
        classification_layout.addWidget(svm_group)
        
        # Decision Trees
        dt_group = self.create_algorithm_group(
            "Decision Tree",
            {"max_depth": "int",
             "min_samples_split": "int",
             "criterion": ["gini", "entropy"]}
        )
        classification_layout.addWidget(dt_group)
        
        # Random Forest
        rf_group = self.create_algorithm_group(
            "Random Forest",
            {"n_estimators": "int",
             "max_depth": "int",
             "min_samples_split": "int"}
        )
        classification_layout.addWidget(rf_group)
        
        # KNN
        knn_group = self.create_algorithm_group(
            "K-Nearest Neighbors",
            {"n_neighbors": "int",
             "weights": ["uniform", "distance"],
             "metric": ["euclidean", "manhattan"]}
        )
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)

        # Classification Loss Function Selector
        class_loss_layout = QHBoxLayout()
        class_loss_label = QLabel("Loss Function:")
        self.classification_loss_combo = QComboBox()
        self.classification_loss_combo.addItems(["Cross-Entropy", "Hinge"])
        class_loss_layout.addWidget(class_loss_label)
        class_loss_layout.addWidget(self.classification_loss_combo)
        classification_layout.addLayout(class_loss_layout)


        return widget
    
    def create_dim_reduction_tab(self):
        widget = QWidget()
        layout = QGridLayout(widget)
        print("[create_dim_reduction_tab] Tab oluşturuluyor...")
        
        # K-Means paneli
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_group.setStyleSheet("QGroupBox { background-color: #E0BBE4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        kmeans_layout = QVBoxLayout()

        # n_clusters
        n_clusters_layout = QHBoxLayout()
        n_clusters_layout.addWidget(QLabel("n_clusters:"))
        self.kmeans_n_clusters = QSpinBox()
        self.kmeans_n_clusters.setRange(1, 20)
        self.kmeans_n_clusters.setValue(3)
        n_clusters_layout.addWidget(self.kmeans_n_clusters)
        kmeans_layout.addLayout(n_clusters_layout)

        # max_iter
        max_iter_layout = QHBoxLayout()
        max_iter_layout.addWidget(QLabel("max_iter:"))
        self.kmeans_max_iter = QSpinBox()
        self.kmeans_max_iter.setRange(1, 1000)
        self.kmeans_max_iter.setValue(300)
        max_iter_layout.addWidget(self.kmeans_max_iter)
        kmeans_layout.addLayout(max_iter_layout)

        # n_init
        n_init_layout = QHBoxLayout()
        n_init_layout.addWidget(QLabel("n_init:"))
        self.kmeans_n_init = QSpinBox()
        self.kmeans_n_init.setRange(1, 100)
        self.kmeans_n_init.setValue(10)
        n_init_layout.addWidget(self.kmeans_n_init)
        kmeans_layout.addLayout(n_init_layout)

        # Train button
        kmeans_train_btn = QPushButton("Train K-Means")
        kmeans_train_btn.clicked.connect(self.train_kmeans)
        kmeans_layout.addWidget(kmeans_train_btn)

        # Elbow Method button
        elbow_btn = QPushButton("Plot Elbow Method (K-Means)")
        elbow_btn.clicked.connect(self.plot_elbow_method)
        kmeans_layout.addWidget(elbow_btn)

        # Hepsini gruba ekle
        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 0, 0)


        # PCA section
        pca_group = QGroupBox("Principal Component Analysis")
        pca_group.setStyleSheet("QGroupBox { background-color: #BFEFFF; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        pca_layout = QVBoxLayout()
        pca_layout.setSpacing(1)  # veya 0 yaparsan tamamen bitişik olur
        

        # n_components
        pca_param_layout = QHBoxLayout()
        pca_param_layout.addWidget(QLabel("n_components:"))
        self.pca_components_spin = QSpinBox()
        self.pca_components_spin.setRange(1, 10)
        self.pca_components_spin.setValue(2)
        pca_param_layout.addWidget(self.pca_components_spin)
        pca_layout.addLayout(pca_param_layout)

        # whiten
        whiten_layout = QHBoxLayout()
        whiten_layout.addWidget(QLabel("whiten:"))
        self.pca_whiten_checkbox = QCheckBox()
        whiten_layout.addWidget(self.pca_whiten_checkbox)
        pca_layout.addLayout(whiten_layout)

        # Projection Type (2D/3D) seçimi
        proj_layout = QHBoxLayout()
        proj_layout.addWidget(QLabel("Projection:"))
        self.pca_proj_combo = QComboBox()
        self.pca_proj_combo.addItems(["2D", "3D"])
        proj_layout.addWidget(self.pca_proj_combo)
        pca_layout.addLayout(proj_layout)

        # Train button
        pca_btn = QPushButton("Train PCA Parameters")
        pca_btn.clicked.connect(self.train_pca)
        pca_layout.addWidget(pca_btn)

        # Manual Covariance Entry Button
        manual_cov_btn = QPushButton("Manual Covariance Entry")
        manual_cov_btn.clicked.connect(self.open_covariance_dialog)
        pca_layout.addWidget(manual_cov_btn)


        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 0, 1)


        # --- LDA Section (YENİ EKLENEN KISIM) --- #
        lda_group = QGroupBox("Linear Discriminant Analysis")
        lda_group.setStyleSheet("QGroupBox { background-color: #BFEFFF; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        lda_layout = QVBoxLayout()

        lda_param_layout = QHBoxLayout()
        lda_param_layout.addWidget(QLabel("n_components:"))
        self.lda_components_spin = QSpinBox()
        self.lda_components_spin.setRange(1, 10)
        self.lda_components_spin.setValue(2)
        lda_param_layout.addWidget(self.lda_components_spin)
        lda_layout.addLayout(lda_param_layout)

        lda_btn = QPushButton("Train LDA")
        lda_btn.clicked.connect(self.train_lda)
        lda_layout.addWidget(lda_btn)

        lda_group.setLayout(lda_layout)
        layout.addWidget(lda_group, 1, 0)

            # --- t-SNE Section (YENİ EKLENEN KISIM) --- #
        tsne_group = QGroupBox("t-SNE")
        tsne_group.setStyleSheet("QGroupBox { background-color: #E0BBE4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        tsne_layout = QVBoxLayout()

        # Perplexity
        perplexity_layout = QHBoxLayout()
        perplexity_layout.addWidget(QLabel("Perplexity:"))
        self.tsne_perplexity = QDoubleSpinBox()
        self.tsne_perplexity.setRange(1.0, 100.0)
        self.tsne_perplexity.setValue(30)
        perplexity_layout.addWidget(self.tsne_perplexity)
        tsne_layout.addLayout(perplexity_layout)

        # Iterations
        iter_layout = QHBoxLayout()
        iter_layout.addWidget(QLabel("n_iter:"))
        self.tsne_iter = QSpinBox()
        self.tsne_iter.setRange(250, 5000)
        self.tsne_iter.setValue(1000)
        iter_layout.addWidget(self.tsne_iter)
        tsne_layout.addLayout(iter_layout)

        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.tsne_lr = QDoubleSpinBox()
        self.tsne_lr.setRange(10.0, 1000.0)
        self.tsne_lr.setValue(250)
        lr_layout.addWidget(self.tsne_lr)
        tsne_layout.addLayout(lr_layout)

        # Projection Type (2D/3D) seçimi
        proj_layout = QHBoxLayout()
        proj_layout.addWidget(QLabel("Projection:"))
        self.tsne_proj_combo = QComboBox()
        self.tsne_proj_combo.addItems(["2D", "3D"])
        proj_layout.addWidget(self.tsne_proj_combo)
        tsne_layout.addLayout(proj_layout)

        # Train button
        tsne_btn = QPushButton("Train t-SNE")
        tsne_btn.clicked.connect(self.train_tsne)
        tsne_layout.addWidget(tsne_btn)

        tsne_group.setLayout(tsne_layout)
        layout.addWidget(tsne_group, 1, 1)

        # --- UMAP Section --- #
        umap_group = QGroupBox("UMAP")
        umap_group.setStyleSheet("QGroupBox { background-color: #E0BBE4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        umap_layout = QVBoxLayout()

        # n_neighbors
        neighbors_layout = QHBoxLayout()
        neighbors_layout.addWidget(QLabel("n_neighbors:"))
        self.umap_neighbors = QSpinBox()
        self.umap_neighbors.setRange(2, 100)
        self.umap_neighbors.setValue(15)
        neighbors_layout.addWidget(self.umap_neighbors)
        umap_layout.addLayout(neighbors_layout)

        # min_dist
        min_dist_layout = QHBoxLayout()
        min_dist_layout.addWidget(QLabel("min_dist:"))
        self.umap_min_dist = QDoubleSpinBox()
        self.umap_min_dist.setRange(0.0, 1.0)
        self.umap_min_dist.setSingleStep(0.05)
        self.umap_min_dist.setValue(0.1)
        min_dist_layout.addWidget(self.umap_min_dist)
        umap_layout.addLayout(min_dist_layout)

        # metric seçimi
        metric_layout = QHBoxLayout()
        metric_layout.addWidget(QLabel("Metric:"))
        self.umap_metric_combo = QComboBox()
        self.umap_metric_combo.addItems(["euclidean", "manhattan", "cosine", "correlation"])
        metric_layout.addWidget(self.umap_metric_combo)
        umap_layout.addLayout(metric_layout)


        # Projection Type (2D/3D) seçimi
        proj_layout = QHBoxLayout()
        proj_layout.addWidget(QLabel("Projection:"))
        self.umap_proj_combo = QComboBox()
        self.umap_proj_combo.addItems(["2D", "3D"])
        proj_layout.addWidget(self.umap_proj_combo)
        umap_layout.addLayout(proj_layout)

        # Train button
        umap_btn = QPushButton("Train UMAP")
        umap_btn.clicked.connect(self.train_umap)
        umap_layout.addWidget(umap_btn)

        umap_group.setLayout(umap_layout)
        layout.addWidget(umap_group, 2, 0)


        widget.setLayout(layout)
        return widget

    
    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Environment selection
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        
        self.env_combo = QComboBox()
        self.env_combo.addItems([
            "CartPole-v1",
            "MountainCar-v0",
            "Acrobot-v1"
        ])
        env_layout.addWidget(self.env_combo)
        
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm selection
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems([
            "Q-Learning",
            "SARSA",
            "DQN"
        ])
        algo_layout.addWidget(self.rl_algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget
    
    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_group.setStyleSheet("""
            QGroupBox {
                background-color: #f8c8dc;  /* Açık pembe */
                border: 1px solid gray;
                border-radius: 5px;
                margin-top: 10px;
                padding: 10px;
            }
        """)

        viz_layout = QHBoxLayout()

        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        

        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        self.metrics_text.setStyleSheet("""
            QTextEdit {
                background-color: #fffde7;  /* Daha yumuşak pembe */
                border: 1px solid #ccc;
            }
        """)

        viz_layout.addWidget(self.canvas, 1)
        viz_layout.addWidget(self.metrics_text, 1)

        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)

    
    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)
    
    def create_algorithm_group(self, name, params):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        
        # Create parameter inputs
        param_widgets = {}
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        # Add train button
        train_btn = QPushButton(f"Train {name}")
        if name == "PCA Parameters":
            train_btn.clicked.connect(self.train_pca)
        else:
            train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))

        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
    def clear_mlp_layers(self):
        self.mlp_layer_config = []
        self.mlp_architecture_display.setText("(Empty)")

    def update_mlp_architecture_display(self):
        """MLP mimarisini kullanıcıya metin olarak göster"""
        if not hasattr(self, "mlp_architecture_label"):
            return

        if not self.mlp_layer_config:
            self.mlp_architecture_label.setText("Architecture:\n(Empty)")
            return

        desc = "Architecture:\n"
        for i, layer in enumerate(self.mlp_layer_config):
            desc += f"{i+1}. {layer['type']} - {layer['params']}\n"

        self.mlp_architecture_label.setText(desc)

    def create_deep_learning_tab(self):
        widget = QWidget()
        layout = QGridLayout(widget)

        # ----- MLP section -----
        mlp_group = QGroupBox("Multi-Layer Perceptron (MLP)")
        mlp_group.setStyleSheet("QGroupBox { background-color: #DCD0FF; border: 1px solid gray; border-radius: 5px; margin-top: 10px; }")
        mlp_layout = QVBoxLayout()

        self.mlp_layer_config = []

        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)

        clear_btn = QPushButton("Clear Layers")
        clear_btn.clicked.connect(self.clear_mlp_layers)
        mlp_layout.addWidget(clear_btn)

        self.mlp_architecture_display = QTextEdit()
        self.mlp_architecture_display.setReadOnly(True)
        self.mlp_architecture_display.setFixedHeight(100)
        mlp_layout.addWidget(self.mlp_architecture_display)

        group, self.mlp_params = self.create_training_params_group("MLP")
        mlp_layout.addWidget(group)

        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)

        save_mlp_btn = QPushButton("Save MLP (.h5)")
        save_mlp_btn.clicked.connect(self.save_mlp_model)
        mlp_layout.addWidget(save_mlp_btn)

        load_mlp_btn = QPushButton("Load MLP (.h5)")
        load_mlp_btn.clicked.connect(self.load_mlp_model)
        mlp_layout.addWidget(load_mlp_btn)

        save_mlp_arch_btn = QPushButton("Save MLP Architecture (.json)")
        save_mlp_arch_btn.clicked.connect(self.save_mlp_model_architecture)
        mlp_layout.addWidget(save_mlp_arch_btn)

        load_mlp_arch_btn = QPushButton("Load MLP Architecture (.json)")
        load_mlp_arch_btn.clicked.connect(self.load_mlp_model_architecture)
        mlp_layout.addWidget(load_mlp_arch_btn)

        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)

        # ----- CNN section -----
        cnn_group = QGroupBox("Convolutional Neural Network (CNN)")
        cnn_group.setStyleSheet("QGroupBox { background-color: #AFEEEE; border: 1px solid gray; border-radius: 5px; margin-top: 10px; }")
        cnn_layout = QVBoxLayout()

        cnn_controls = self.create_cnn_controls("CNN")
        cnn_layout.addWidget(cnn_controls)

        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)

        # ----- RNN section -----
        rnn_group = QGroupBox("Recurrent Neural Network (RNN)")
        rnn_group.setStyleSheet("QGroupBox { background-color: #DCD0FF; border: 1px solid gray; border-radius: 5px; margin-top: 10px; }")
        rnn_layout = QVBoxLayout()

        rnn_controls = self.create_rnn_controls("RNN")
        rnn_layout.addWidget(rnn_controls)

        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0, 1, 2)  # 👈 tüm alt satırı kaplar

        layout.setColumnStretch(0, 1)
        layout.setColumnStretch(1, 1)

        return widget




    def train_neural_network(self):
        if not self.mlp_layer_config:
            self.show_error("Please add at least one layer to the network")
            return
        try:
            # Modeli MLP katman konfigürasyonuna göre oluştur
            model = self.create_neural_network()

            # Eğitim parametrelerini al
            batch_size = self.mlp_params["batch_size"].value()
            epochs = self.mlp_params["epochs"].value()
            learning_rate = self.mlp_params["lr"].value()

            optimizer_name = self.mlp_params["optimizer"].currentText()
            if optimizer_name == "Adam":
                optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            elif optimizer_name == "SGD":
                optimizer = tf.keras.optimizers.SGD(learning_rate=learning_rate)
            elif optimizer_name == "RMSprop":
                optimizer = tf.keras.optimizers.RMSprop(learning_rate=learning_rate)
            else:
                self.show_error("Unsupported optimizer selected.")
                return

            # Giriş verisi 3 boyutlu ise (örneğin MNIST 28x28), düzleştir
            if len(self.X_train.shape) > 2:
                X_train = self.X_train.reshape(self.X_train.shape[0], -1)
                X_test = self.X_test.reshape(self.X_test.shape[0], -1)
            else:
                X_train = self.X_train
                X_test = self.X_test

            # One-hot encode etiketler
            num_classes = len(np.unique(self.y_train))
            y_train = tf.keras.utils.to_categorical(self.y_train, num_classes)
            y_test = tf.keras.utils.to_categorical(self.y_test, num_classes)

            num_classes = len(np.unique(self.y_train))
            y_train = tf.keras.utils.to_categorical(self.y_train, num_classes)
            y_test = tf.keras.utils.to_categorical(self.y_test, num_classes)
            # Modeli derle
            model.compile(
                optimizer=optimizer,
                loss='categorical_crossentropy',
                metrics=['accuracy']
            )

            # Callbacks
            callbacks = []
            scheduler_cb = None
            if hasattr(self, "mlp_training_params") and "scheduler" in self.mlp_training_params:
                scheduler_combo = self.mlp_training_params["scheduler"]
                # Eğer scheduler_combo bir QComboBox ise:
                scheduler_cb = self.get_scheduler_callback(learning_rate, epochs, scheduler_combo.currentText())
            if scheduler_cb:
                callbacks.append(scheduler_cb)

            early_stop_cb = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)
            callbacks.append(early_stop_cb)

            history = model.fit(
                X_train, y_train,
                batch_size=batch_size,
                epochs=epochs,
                validation_data=(X_test, y_test),
                callbacks=callbacks
            )


            # Eğitim sonuçlarını göster
            self.plot_training_history(history)
            self.show_final_test_metrics(model, X_test, y_test)
            self.status_bar.showMessage("Neural Network Training Complete")

            self.trained_model = model

        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")




    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        # Layer type selection
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        # Parameters input
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        self.layer_param_inputs = {}
        
        def update_params():
            # Remove previous widgets
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
                # L2 Regularization
                l2_label = QLabel("L2 (lambda):")
                l2_input = QDoubleSpinBox()
                l2_input.setRange(0.0, 0.1)
                l2_input.setSingleStep(0.001)
                l2_input.setValue(0.0)
                self.layer_param_inputs["l2"] = l2_input

                params_layout.addWidget(l2_label)
                params_layout.addWidget(l2_input)

            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size (x,y):")
                kernel_input = QLineEdit()
                kernel_input.setText("3,3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
                # L2 Regularization
                l2_label = QLabel("L2 (lambda):")
                l2_input = QDoubleSpinBox()
                l2_input.setRange(0.0, 0.1)
                l2_input.setSingleStep(0.001)
                l2_input.setValue(0.0)
                self.layer_param_inputs["l2"] = l2_input

                params_layout.addWidget(l2_label)
                params_layout.addWidget(l2_input)

            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)

            elif layer_type == "MaxPooling2D":
                # Sabit parametre için ek girdi yok (örnek)
                label = QLabel("MaxPooling2D with pool size (2,2)")
                params_layout.addWidget(label)
                
            elif layer_type == "Flatten":
                # Parametre girişi yok
                label = QLabel("Flatten layer has no parameters")
                params_layout.addWidget(label)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()  # initial call to set inputs
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox) or isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    if param_name == "kernel_size":
                        # tuple olarak al
                        try:
                            layer_params[param_name] = tuple(int(x.strip()) for x in widget.text().split(','))
                        except Exception:
                            self.show_error("Kernel size must be two integers separated by a comma.")
                            return
                    else:
                        layer_params[param_name] = widget.text()
            
            # Örnek olarak Flatten ve MaxPooling2D için parametre yok
            if layer_type in ["Flatten", "MaxPooling2D"]:
                layer_params = {}
            
            # Katmanı katman listesine ekle
            self.mlp_layer_config.append({
                "type": layer_type,
                "params": layer_params
            })
            
            # Mimariyi güncelle
            arch_summary = "Model Architecture:\n"
            for layer in self.mlp_layer_config:
                ltype = layer['type']
                params = layer['params']
                if ltype == "Dense":
                    arch_summary += f"- Dense(units={params.get('units')}, activation={params.get('activation')})\n"
                elif ltype == "Conv2D":
                    arch_summary += f"- Conv2D(filters={params.get('filters')}, kernel_size={params.get('kernel_size')})\n"
                elif ltype == "Flatten":
                    arch_summary += "- Flatten()\n"
                elif ltype == "Dropout":
                    arch_summary += f"- Dropout(rate={params.get('rate')})\n"
                elif ltype == "MaxPooling2D":
                    arch_summary += "- MaxPooling2D()\n"

            self.mlp_architecture_display.setText(arch_summary)
            self.status_bar.showMessage(f"{layer_type} layer added successfully.")
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        
        dialog.exec()




    

    


    def create_training_params_group(self, model_type=None):
        group = QGroupBox("Training Parameters")
        layout = QHBoxLayout()

        # Batch Size
        layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1024)
        self.batch_size_spin.setValue(32)
        layout.addWidget(self.batch_size_spin)

        # Epochs
        layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(20)
        layout.addWidget(self.epochs_spin)

        # Learning Rate
        layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setDecimals(5)
        self.lr_spin.setRange(0.00001, 1.0)
        self.lr_spin.setSingleStep(0.0001)
        self.lr_spin.setValue(0.001)
        layout.addWidget(self.lr_spin)

        # Optimizer
        layout.addWidget(QLabel("Optimizer:"))
        self.optimizer_combo = QComboBox()
        self.optimizer_combo.addItems(["Adam", "SGD", "RMSprop"])
        layout.addWidget(self.optimizer_combo)

        group.setLayout(layout)
        return group, {
            "batch_size": self.batch_size_spin,
            "epochs": self.epochs_spin,
            "lr": self.lr_spin,
            "optimizer": self.optimizer_combo,
        }


        # Enable/disable augmentation controls based on checkbox
        def toggle_augmentation_controls(state):
            enabled = state == Qt.CheckState.Checked
            rotation_spin.setEnabled(enabled)
            flip_check.setEnabled(enabled)
            zoom_spin.setEnabled(enabled)

        augment_enable.stateChanged.connect(toggle_augmentation_controls)
        toggle_augmentation_controls(Qt.CheckState.Unchecked)

        aug_group.setLayout(aug_layout)
        layout.addWidget(aug_group)

        group.setLayout(layout)

        # Dönüşte bu widgetları self ile kullanmak için dict olarak döndür
        return group, {
            "batch_size": batch_spin,
            "epochs": epochs_spin,
            "lr": lr_spin,
            "optimizer": optimizer_combo,
            "scheduler": scheduler_combo,
            "augment_enable": augment_enable,
            "augment_rotation": rotation_spin,
            "augment_flip": flip_check,
            "augment_zoom": zoom_spin,
        }



    
    def toggle_augmentation_options(self):
        enabled = self.augment_enable.isChecked()
        self.augment_rotation.setEnabled(enabled)
        self.augment_flip.setEnabled(enabled)
        self.augment_zoom.setEnabled(enabled)

    def create_gradient_histogram_area(self):
        self.gradient_figure = Figure(figsize=(6, 4))
        self.gradient_canvas = FigureCanvas(self.gradient_figure)
        
        # Örneğin bir tab veya groupbox içinde layout'a ekle
        layout = QVBoxLayout()
        layout.addWidget(self.gradient_canvas)

        container = QWidget()
        container.setLayout(layout)

        return container
    def create_gradient_histogram_callback(self, model, sample_X, sample_y):
        import tensorflow.keras.backend as K
        import numpy as np
        import matplotlib.pyplot as plt

        class GradientHistogramCallback(tf.keras.callbacks.Callback):
            def __init__(self, gui, sample_X, sample_y):
                super().__init__()
                self.gui = gui
                self.figure = gui.gradient_figure  # GUI içinde tanımlı matplotlib.figure.Figure
                self.canvas = gui.gradient_canvas    # GUI içinde tanımlı FigureCanvas
                self.sample_X = sample_X
                self.sample_y = sample_y

            def on_epoch_end(self, epoch, logs=None):
                with tf.GradientTape() as tape:
                    preds = self.model(self.sample_X, training=True)
                    loss = self.model.compiled_loss(self.sample_y, preds)
                grads = tape.gradient(loss, self.model.trainable_weights)

                # Tüm gradleri birleştir ve histogram çiz
                all_grads = np.concatenate([tf.reshape(g, [-1]).numpy() for g in grads if g is not None])

                self.figure.clear()
                ax = self.figure.add_subplot(111)
                ax.hist(all_grads, bins=50)
                ax.set_title(f"Gradient Histogram - Epoch {epoch + 1}")
                self.figure.tight_layout()
                self.canvas.draw()

        return GradientHistogramCallback(self, sample_X, sample_y)



    def get_scheduler_callback(self, learning_rate, epochs, scheduler_combo):
        scheduler_type = scheduler_combo.currentText()
            
        if scheduler_type == "Step Decay":
            def step_decay(epoch, lr):
                drop_rate = 0.5
                epochs_drop = 5
                return learning_rate * (drop_rate ** (epoch // epochs_drop))
            return tf.keras.callbacks.LearningRateScheduler(step_decay)
            
        elif scheduler_type == "Exponential Decay":
            def exp_decay(epoch):
                k = 0.1  # decay rate
                return learning_rate * tf.math.exp(-k * epoch)
            return tf.keras.callbacks.LearningRateScheduler(exp_decay)
            
        return None


    
    def add_cnn_layer_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Add CNN Layer")
        layout = QVBoxLayout(dialog)

        # Katman tipi
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Conv2D", "MaxPooling2D", "Flatten", "Dropout", "Dense"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)

        # Parametre giriş alanı
        param_group = QGroupBox("Layer Parameters")
        param_layout = QVBoxLayout()
        param_group.setLayout(param_layout)
        layout.addWidget(param_group)

        param_inputs = {}

        def update_params():
            for i in reversed(range(param_layout.count())):
                param_layout.itemAt(i).widget().setParent(None)
            param_inputs.clear()

            selected_type = type_combo.currentText()
            if selected_type == "Conv2D":
                filters = QSpinBox()
                filters.setRange(1, 512)
                filters.setValue(32)
                kernel_size = QLineEdit("3,3")
                l2_reg = QDoubleSpinBox()
                l2_reg.setRange(0.0, 1.0)
                l2_reg.setSingleStep(0.01)

                param_layout.addWidget(QLabel("Filters:"))
                param_layout.addWidget(filters)
                param_layout.addWidget(QLabel("Kernel Size (x,y):"))
                param_layout.addWidget(kernel_size)
                param_layout.addWidget(QLabel("L2 Regularization:"))
                param_layout.addWidget(l2_reg)

                param_inputs["filters"] = filters
                param_inputs["kernel_size"] = kernel_size
                param_inputs["l2"] = l2_reg

            elif selected_type == "MaxPooling2D":
                # Şimdilik sabit parametre
                pass

            elif selected_type == "Flatten":
                pass

            elif selected_type == "Dropout":
                rate = QDoubleSpinBox()
                rate.setRange(0.0, 1.0)
                rate.setSingleStep(0.1)
                rate.setValue(0.5)
                param_layout.addWidget(QLabel("Dropout Rate:"))
                param_layout.addWidget(rate)
                param_inputs["rate"] = rate

            elif selected_type == "Dense":
                units = QSpinBox()
                units.setRange(1, 1024)
                units.setValue(128)
                activation = QComboBox()
                activation.addItems(["relu", "sigmoid", "tanh", "softmax"])
                l2_reg = QDoubleSpinBox()
                l2_reg.setRange(0.0, 1.0)
                l2_reg.setSingleStep(0.01)

                param_layout.addWidget(QLabel("Units:"))
                param_layout.addWidget(units)
                param_layout.addWidget(QLabel("Activation:"))
                param_layout.addWidget(activation)
                param_layout.addWidget(QLabel("L2 Regularization:"))
                param_layout.addWidget(l2_reg)

                param_inputs["units"] = units
                param_inputs["activation"] = activation
                param_inputs["l2"] = l2_reg

        type_combo.currentIndexChanged.connect(update_params)
        update_params()

        # Katman ekle butonu
        button_box = QHBoxLayout()
        add_btn = QPushButton("Add")
        cancel_btn = QPushButton("Cancel")
        button_box.addWidget(add_btn)
        button_box.addWidget(cancel_btn)
        layout.addLayout(button_box)

        def add_layer():
            layer_type = type_combo.currentText()
            params = {}

            for key, widget in param_inputs.items():
                if isinstance(widget, QSpinBox) or isinstance(widget, QDoubleSpinBox):
                    params[key] = widget.value()
                elif isinstance(widget, QComboBox):
                    params[key] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    params[key] = widget.text()

                self.cnn_layer_config.append({
                    "type": layer_type,
                    "params": params
})

            # Mimariyi güncelle
            arch_text = "Model Architecture:\n"
            for layer in self.cnn_layer_config:
                arch_text += f"- {layer['type']}({', '.join(f'{k}={v}' for k, v in layer['params'].items())})\n"

            self.cnn_architecture_label.setText(arch_text)
            self.status_bar.showMessage(f"{layer_type} layer added to CNN.")
            dialog.accept()

        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        dialog.exec()


    
    def create_cnn_controls(self, model_type):
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()

        # Mimari gösterimi
        self.cnn_architecture_label = QLabel("Model Architecture:\n(Empty)")
        self.cnn_architecture_label.setStyleSheet("background-color: #fff; padding: 5px; border: 1px solid gray;")
        layout.addWidget(self.cnn_architecture_label)

        # Katman ekleme butonu
        add_layer_btn = QPushButton("Add CNN Layer")
        add_layer_btn.clicked.connect(self.add_cnn_layer_dialog)
        layout.addWidget(add_layer_btn)

        # Eğitim parametreleri (CNN'e özel)
        self.cnn_training_group, self.cnn_training_params = self.create_training_params_group("CNN")
        layout.addWidget(self.cnn_training_group)

        # Pretrained Model yükleme butonu
        load_pretrained_btn = QPushButton("Load Pretrained Model")
        load_pretrained_btn.clicked.connect(self.load_pretrained_model_dialog)
        layout.addWidget(load_pretrained_btn)

        # Pretrained Model eğitimi için buton
        train_pretrained_btn = QPushButton("Train Pretrained Model")
        train_pretrained_btn.clicked.connect(self.train_pretrained_model)
        layout.addWidget(train_pretrained_btn)

        # Normal CNN eğitimi
        train_btn = QPushButton("Train CNN")
        train_btn.clicked.connect(self.train_cnn_network)
        layout.addWidget(train_btn)

        # CNN modeli kaydetme butonu
        save_btn = QPushButton("Save CNN Model")
        save_btn.clicked.connect(self.save_cnn_model)
        layout.addWidget(save_btn)

        # CNN modeli yükleme butonu
        load_btn = QPushButton("Load CNN Model")
        load_btn.clicked.connect(self.load_cnn_model)
        layout.addWidget(load_btn)

        # JSON mimari kaydetme butonu
        save_arch_btn = QPushButton("Save CNN Architecture (.json)")
        save_arch_btn.clicked.connect(self.save_cnn_model_architecture)
        layout.addWidget(save_arch_btn)

        # JSON mimari yükleme butonu
        load_arch_btn = QPushButton("Load CNN Architecture (.json)")
        load_arch_btn.clicked.connect(self.load_cnn_model_architecture)
        layout.addWidget(load_arch_btn)

        # Clear CNN mimari butonu
        clear_btn = QPushButton("Clear CNN Layers")
        clear_btn.clicked.connect(self.clear_cnn_layers)
        layout.addWidget(clear_btn)


        augment_enable = QCheckBox("Enable Image Augmentation")
        augment_enable.setChecked(False)  # Varsayılan kapalı
        layout.addWidget(augment_enable)

        # Sonra bu checkbox'u self.cnn_training_params sözlüğüne ekle:
        self.cnn_training_params["augment_enable"] = augment_enable

        

        group.setLayout(layout)
        return group



    def save_rnn_model(self):
        """Save the trained RNN model (.h5)"""
        if not hasattr(self, "rnn_trained_model"):
            self.show_error("No trained RNN model to save.")
            return

        try:
            filename, _ = QFileDialog.getSaveFileName(self, "Save RNN Model", "", "Model Files (*.h5)")
            if filename:
                self.rnn_trained_model.save(filename)
                self.status_bar.showMessage(f"RNN model saved to: {filename}")
        except Exception as e:
            self.show_error(f"Error saving RNN model: {str(e)}")


    def load_rnn_model(self):
        try:
            filename, _ = QFileDialog.getOpenFileName(self, "Load RNN Model", "", "Model files (*.h5)")
            if filename:
                self.rnn_trained_model = tf.keras.models.load_model(filename)
                self.status_bar.showMessage(f"RNN model loaded from: {filename}")
        except Exception as e:
            self.show_error(f"Error loading RNN model: {str(e)}")



    def save_rnn_model_architecture(self):
        """Save RNN model architecture to JSON file"""
        if not hasattr(self, "rnn_trained_model") or self.rnn_trained_model is None:
            self.show_error("No trained RNN model to save architecture.")
            return
        try:
            filename, _ = QFileDialog.getSaveFileName(
                self,
                "Save RNN Architecture",
                "",
                "JSON Files (*.json)"
            )
            if filename:
                model_json = self.rnn_trained_model.to_json()
                with open(filename, "w") as json_file:
                    json_file.write(model_json)
                self.status_bar.showMessage(f"RNN architecture saved to: {filename}")
        except Exception as e:
            self.show_error(f"Error saving RNN architecture: {str(e)}")



    
    def save_mlp_model(self):
        if not hasattr(self, "trained_model"):
            self.show_error("No trained MLP model to save.")
            return

        try:
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save MLP Model", "", "Model files (*.h5)"
            )
            if filename:
                self.trained_model.save(filename)
                self.status_bar.showMessage(f"Model saved to: {filename}")
        except Exception as e:
            self.show_error(f"Error saving MLP model: {str(e)}")

    def load_mlp_model(self):
        try:
            filename, _ = QFileDialog.getOpenFileName(self, "Load MLP Model", "", "Model files (*.h5)")
            if filename:
                self.mlp_trained_model = tf.keras.models.load_model(filename)
                self.status_bar.showMessage(f"MLP model loaded from: {filename}")
        except Exception as e:
            self.show_error(f"Error loading MLP model: {str(e)}")


    def save_mlp_model_architecture(self):
        if not hasattr(self, "trained_model"):
            self.show_error("No trained MLP model to save.")
            return

        try:
            filename, _ = QFileDialog.getSaveFileName(
                self, "Save MLP Architecture", "", "JSON files (*.json)"
            )
            if filename:
                # Modeli JSON string'e çevir
                model_json = self.trained_model.to_json()
                with open(filename, "w") as json_file:
                    json.dump(json.loads(model_json), json_file, indent=4)
                self.status_bar.showMessage(f"Model architecture saved to: {filename}")
        except Exception as e:
            self.show_error(f"Error saving MLP architecture: {str(e)}")

    def load_mlp_model_architecture(self):
        try:
            filename, _ = QFileDialog.getOpenFileName(self, "Load MLP Architecture", "", "JSON Files (*.json)")
            if filename:
                with open(filename, "r") as json_file:
                    model_json = json_file.read()
                self.mlp_trained_model = tf.keras.models.model_from_json(model_json)
                self.status_bar.showMessage(f"MLP architecture loaded from: {filename}")
        except Exception as e:
            self.show_error(f"Error loading MLP architecture: {str(e)}")


    def load_pretrained_model_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Pretrained Model")
        layout = QVBoxLayout(dialog)

        combo = QComboBox()
        combo.addItems(["VGG16", "ResNet50"])
        layout.addWidget(combo)

        btn = QPushButton("Load")
        btn.clicked.connect(lambda: dialog.accept())
        layout.addWidget(btn)

        if dialog.exec() == QDialog.DialogCode.Accepted:
            model_name = combo.currentText()
            self.load_pretrained_model(model_name)

    def load_pretrained_model(self, model_name):
        from tensorflow.keras.applications import VGG16, ResNet50
        from tensorflow.keras.models import Model
        from tensorflow.keras.layers import GlobalAveragePooling2D, Dense

        num_classes = len(np.unique(self.y_train))

        if model_name == "VGG16":
            base_model = VGG16(include_top=False, weights="imagenet", input_shape=(224, 224, 3))
        elif model_name == "ResNet50":
            base_model = ResNet50(include_top=False, weights="imagenet", input_shape=(224, 224, 3))

        base_model.trainable = False  # İlk başta dondur

        x = base_model.output
        x = GlobalAveragePooling2D()(x)
        x = Dense(128, activation='relu')(x)
        predictions = Dense(num_classes, activation='softmax')(x)

        self.pretrained_model = Model(inputs=base_model.input, outputs=predictions)
        self.status_bar.showMessage(f"{model_name} loaded. Ready for fine-tuning.")

    def train_pretrained_model(self):
        import tensorflow as tf
        print("GPU available:", tf.config.list_physical_devices('GPU'))
        if not hasattr(self, 'pretrained_model'):
            self.show_error("Pretrained model not loaded.")
            return

        try:
            from tensorflow.keras.preprocessing.image import ImageDataGenerator

            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()

            optimizer_name = self.optimizer_combo.currentText()
            if optimizer_name == "Adam":
                optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            elif optimizer_name == "SGD":
                optimizer = tf.keras.optimizers.SGD(learning_rate=learning_rate)
            elif optimizer_name == "RMSprop":
                optimizer = tf.keras.optimizers.RMSprop(learning_rate=learning_rate)

            # Giriş şekillendirme
            def preprocess(images):
                if len(images.shape) == 3:
                    images = images[..., np.newaxis]
                images = images.astype("float32") / 255.0
                images = tf.image.resize(images, (224, 224))
                images = tf.repeat(images, 3, axis=-1)
                return images

            # Yalnızca subsetleri kullan (çok büyük veri varsa)
            max_train = min(5000, len(self.X_train))
            max_test = min(1000, len(self.X_test))

            X_train = preprocess(self.X_train[:max_train])
            y_train = self.y_train[:max_train]
            X_test = preprocess(self.X_test[:max_test])
            y_test = self.y_test[:max_test]

            num_classes = len(np.unique(y_train))
            y_train_cat = tf.keras.utils.to_categorical(y_train, num_classes)
            y_test_cat = tf.keras.utils.to_categorical(y_test, num_classes)

            # Verileri augment eden generator
            train_gen = ImageDataGenerator(
                rotation_range=15,
                zoom_range=0.1,
                horizontal_flip=True
            ).flow(X_train, y_train_cat, batch_size=batch_size)

            val_gen = ImageDataGenerator().flow(X_test, y_test_cat, batch_size=batch_size)

            self.pretrained_model.compile(
                optimizer=optimizer,
                loss="categorical_crossentropy",
                metrics=["accuracy"]
            )

            history = self.pretrained_model.fit(
                train_gen,
                validation_data=val_gen,
                epochs=epochs,
                callbacks=[self.create_progress_callback()]
            )

            self.plot_training_history(history)
            self.show_final_test_metrics(self.pretrained_model, X_test, y_test_cat)
            self.status_bar.showMessage("Fine-tuning complete.")

        except Exception as e:
            import traceback
            traceback.print_exc()
            self.show_error(f"Fine-tuning error: {str(e)}")




    def load_rnn_model_architecture(self):
        try:
            filename, _ = QFileDialog.getOpenFileName(self, "Load RNN Architecture", "", "JSON Files (*.json)")
            if filename:
                with open(filename, "r") as json_file:
                    model_json = json_file.read()
                self.rnn_trained_model = tf.keras.models.model_from_json(model_json)
                self.status_bar.showMessage(f"RNN architecture loaded from: {filename}")
        except Exception as e:
            self.show_error(f"Error loading RNN architecture: {str(e)}")

    def create_rnn_controls(self, model_type):
        """Create controls for Recurrent Neural Network (LSTM / GRU)"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()

        # RNN katmanlarını göster
        self.rnn_layer_display = QTextEdit()
        self.rnn_layer_display.setReadOnly(True)
        self.rnn_layer_display.setFixedHeight(100)
        layout.addWidget(self.rnn_layer_display)

        # Katman eklemek için combobox ve units
        form_layout = QHBoxLayout()

        self.rnn_type_combo = QComboBox()
        self.rnn_type_combo.addItems(["LSTM", "GRU"])
        form_layout.addWidget(QLabel("Layer Type:"))
        form_layout.addWidget(self.rnn_type_combo)

        self.rnn_units_spin = QSpinBox()
        self.rnn_units_spin.setRange(1, 512)
        self.rnn_units_spin.setValue(64)
        form_layout.addWidget(QLabel("Units:"))
        form_layout.addWidget(self.rnn_units_spin)

        layout.addLayout(form_layout)

        # Add Layer butonu
        add_btn = QPushButton("Add RNN Layer")
        add_btn.clicked.connect(self.add_rnn_layer)
        layout.addWidget(add_btn)

        # Clear butonu
        clear_btn = QPushButton("Clear RNN Layers")
        clear_btn.clicked.connect(self.clear_rnn_layers)
        layout.addWidget(clear_btn)

        # Eğitim parametreleri
        group_params, self.rnn_params = self.create_training_params_group(model_type)
        layout.addWidget(group_params)

        # Train butonu
        train_btn = QPushButton("Train RNN Network")
        train_btn.clicked.connect(self.train_rnn_network)
        layout.addWidget(train_btn)

        # Save/Load Buttons (.h5 ve .json)
        save_h5_btn = QPushButton("Save RNN (.h5)")
        save_h5_btn.clicked.connect(self.save_rnn_model)
        layout.addWidget(save_h5_btn)

        load_h5_btn = QPushButton("Load RNN (.h5)")
        load_h5_btn.clicked.connect(self.load_rnn_model)
        layout.addWidget(load_h5_btn)

        save_json_btn = QPushButton("Save RNN Architecture (.json)")
        save_json_btn.clicked.connect(self.save_rnn_model_architecture)
        layout.addWidget(save_json_btn)

        load_json_btn = QPushButton("Load RNN Architecture (.json)")
        load_json_btn.clicked.connect(self.load_rnn_model_architecture)
        layout.addWidget(load_json_btn)

        group.setLayout(layout)
        return group


    

    def save_cnn_model_architecture(self):
        try:
            filename, _ = QFileDialog.getSaveFileName(self, "Save CNN Architecture", "", "JSON Files (*.json)")
            if filename:
                with open(filename, "w") as f:
                    json.dump(self.mlp_layer_config, f, indent=4)
                self.status_bar.showMessage(f"CNN architecture saved to: {filename}")
        except Exception as e:
            self.show_error(f"Error saving CNN architecture: {str(e)}")




    def load_cnn_model_architecture(self):
        try:
            filename, _ = QFileDialog.getOpenFileName(self, "Load CNN Architecture", "", "JSON Files (*.json)")
            if filename:
                with open(filename, "r") as json_file:
                    loaded_json = json_file.read()
                self.cnn_trained_model = model_from_json(loaded_json)
                self.status_bar.showMessage(f"CNN architecture loaded from: {filename}")
        except Exception as e:
            self.show_error(f"Error loading CNN architecture: {str(e)}")


    def add_rnn_layer(self):
        """Add selected RNN layer to configuration"""
        layer_type = self.rnn_type_combo.currentText()
        units = self.rnn_units_spin.value()

        # layer_params değişkenini burada tanımlıyoruz
        layer_params = {"units": units}

        self.rnn_layer_config.append({
            "type": layer_type,
            "params": layer_params
        })

        # Mimariyi güncelle
        arch_text = "RNN Architecture:\n"
        for layer in self.rnn_layer_config:
            arch_text += f"- {layer['type']}(units={layer['params']['units']})\n"

        self.rnn_layer_display.setText(arch_text)
        self.status_bar.showMessage(f"{layer_type} layer with {units} units added.")


    def clear_rnn_layers(self):
        """Clear RNN layer configuration"""
        self.rnn_layer_config = []
        self.rnn_layer_display.clear()
        self.status_bar.showMessage("RNN mimarisi temizlendi.")

    def train_rnn_network(self):
        """Train the RNN (LSTM/GRU) network with current configuration"""
        if not self.rnn_layer_config:
            self.show_error("Please add at least one RNN layer.")
            return

        try:
            # Eğitim parametrelerini al
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()

            optimizer_name = self.optimizer_combo.currentText()
            if optimizer_name == "Adam":
                optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            elif optimizer_name == "SGD":
                optimizer = tf.keras.optimizers.SGD(learning_rate=learning_rate)
            elif optimizer_name == "RMSprop":
                optimizer = tf.keras.optimizers.RMSprop(learning_rate=learning_rate)

            # Giriş verisini uygun forma getir (örnek: [samples, timesteps, features])
            X_train = self.X_train.astype("float32")
            X_test = self.X_test.astype("float32")

            if len(X_train.shape) == 2:  # e.g., (samples, features) → (samples, timesteps=1, features)
                X_train = X_train[:, np.newaxis, :]
                X_test = X_test[:, np.newaxis, :]

            y_train = self.y_train
            y_test = self.y_test
            num_classes = len(np.unique(y_train))
            y_train_cat = tf.keras.utils.to_categorical(y_train, num_classes)
            y_test_cat = tf.keras.utils.to_categorical(y_test, num_classes)

            # Model oluştur
            model = tf.keras.Sequential()
            for idx, layer in enumerate(self.rnn_layer_config):
                layer_type = layer["type"]
                units = layer["params"]["units"]
                return_sequences = idx != len(self.rnn_layer_config) - 1

                if layer_type == "LSTM":
                    model.add(layers.LSTM(units, return_sequences=return_sequences,
                                        input_shape=X_train.shape[1:] if idx == 0 else None))
                elif layer_type == "GRU":
                    model.add(layers.GRU(units, return_sequences=return_sequences,
                                        input_shape=X_train.shape[1:] if idx == 0 else None))

            # Flatten veya doğrudan çıkış
            model.add(layers.Dense(num_classes, activation="softmax"))

            # Derleme
            model.compile(
                optimizer=optimizer,
                loss="categorical_crossentropy",
                metrics=["accuracy"]
            )

            # Eğitim
            callbacks = [self.create_progress_callback()]
            callbacks.append(self.create_logging_callback())

            sample_X = X_train[:32]
            sample_y = y_train_cat[:32]  # Burada one-hot kullanıldı
            gradient_cb = self.create_gradient_histogram_callback(model, sample_X, sample_y)
            callbacks.append(gradient_cb)

            scheduler_cb = None
            if "scheduler" in self.rnn_params:
                scheduler_cb = self.get_scheduler_callback(learning_rate, epochs, self.rnn_params["scheduler"].currentText())
            if scheduler_cb:
                callbacks.append(scheduler_cb)

            early_stop_cb = tf.keras.callbacks.EarlyStopping(
                monitor='val_loss', patience=3, restore_best_weights=True)
            callbacks.append(early_stop_cb)

            history = model.fit(
                    X_train, y_train_cat,
                    batch_size=batch_size,
                    epochs=epochs,
                    validation_data=(X_test, y_test_cat),
                    callbacks=callbacks
            )

            # ✅ Modeli eğittikten sonra kaydetmek için nesneye ata
            self.rnn_trained_model = model

            self.plot_training_history(history)
            self.status_bar.showMessage("RNN modeli başarıyla eğitildi.")
            self.show_final_test_metrics(model, X_test, y_test_cat)

        except Exception as e:
            self.show_error(f"RNN eğitimi sırasında hata: {str(e)}")


    def create_rnn_training_params_group(self):
        group = QGroupBox("Training Parameters")
        layout = QHBoxLayout()

        # Batch Size
        layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1024)
        self.batch_size_spin.setValue(32)  # Varsayılan
        layout.addWidget(self.batch_size_spin)

        # Epochs
        layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(20)  # Varsayılan
        layout.addWidget(self.epochs_spin)

        # Learning Rate
        layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setSingleStep(0.0001)
        self.lr_spin.setValue(0.001)  # Varsayılan
        layout.addWidget(self.lr_spin)

        # Optimizer Seçimi
        layout.addWidget(QLabel("Optimizer:"))
        self.optimizer_combo = QComboBox()
        self.optimizer_combo.addItems(["Adam", "SGD", "RMSprop"])
        layout.addWidget(self.optimizer_combo)

        group.setLayout(layout)
        return group

    
    def clear_cnn_layers(self):
        """Clear CNN layer configuration"""
        self.cnn_layer_config = []
        self.cnn_architecture_label.setText("Model Architecture:\n(Empty)")
        self.status_bar.showMessage("CNN mimarisi temizlendi.")

    
    def train_cnn_network(self):
        from tensorflow.keras.preprocessing.image import ImageDataGenerator
        from tensorflow.keras.callbacks import EarlyStopping
        from tensorflow.keras import regularizers, layers

        """Train the CNN network with current CNN layer configuration"""
        if not self.cnn_layer_config:
            self.show_error("Please add at least one CNN layer.")
            return

        if self.X_train is None or self.X_test is None:
            self.show_error("Veri yüklenmemiş. Lütfen önce veri seti seçin.")
            return

        try:
            # Eğitim parametreleri sözlükten alınıyor
            batch_size = self.cnn_training_params["batch_size"].value()
            epochs = self.cnn_training_params["epochs"].value()
            learning_rate = self.cnn_training_params["lr"].value()

            optimizer_name = self.cnn_training_params["optimizer"].currentText()
            if optimizer_name == "Adam":
                optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            elif optimizer_name == "SGD":
                optimizer = tf.keras.optimizers.SGD(learning_rate=learning_rate)
            elif optimizer_name == "RMSprop":
                optimizer = tf.keras.optimizers.RMSprop(learning_rate=learning_rate)
            else:
                self.show_error("Unsupported optimizer selected.")
                return

            # Veri ön işleme (normalize + kanal boyutu)
            X_train = np.array(self.X_train).astype("float32") / 255.0
            X_test = np.array(self.X_test).astype("float32") / 255.0

            # Debug için shape yazdırma (isteğe bağlı)
            print("Shape of X_train before expand_dims:", X_train.shape)
            print("Shape of X_test before expand_dims:", X_test.shape)

            if len(X_train.shape) == 3:
                X_train = np.expand_dims(X_train, axis=-1)
                X_test = np.expand_dims(X_test, axis=-1)

            print("Shape of X_train after expand_dims:", X_train.shape)
            print("Shape of X_test after expand_dims:", X_test.shape)

            y_train = self.y_train
            y_test = self.y_test
            num_classes = len(np.unique(y_train))
            y_train_cat = tf.keras.utils.to_categorical(y_train, num_classes)
            y_test_cat = tf.keras.utils.to_categorical(y_test, num_classes)

            # Model oluştur
            model = tf.keras.Sequential()
            first_layer = True

            for layer in self.cnn_layer_config:
                ltype = layer["type"]
                params = layer["params"]

                if ltype == "Conv2D":
                    if isinstance(params.get("kernel_size"), str):
                        try:
                            kernel_tuple = tuple(map(int, params["kernel_size"].split(',')))
                            if len(kernel_tuple) != 2:
                                raise ValueError("Kernel size must be two integers.")
                            params["kernel_size"] = kernel_tuple
                        except Exception as e:
                            self.show_error(f"Invalid kernel size: {str(e)}")
                            return

                    l2_value = params.get("l2", 0.0)
                    regularizer = regularizers.l2(l2_value) if l2_value > 0 else None

                    layer_args = dict(
                        filters=params["filters"],
                        kernel_size=params["kernel_size"],
                        activation="relu",
                        kernel_regularizer=regularizer
                    )
                    if first_layer:
                        layer_args["input_shape"] = X_train.shape[1:]
                        first_layer = False

                    model.add(layers.Conv2D(**layer_args))

                elif ltype == "MaxPooling2D":
                    model.add(layers.MaxPooling2D(pool_size=(2, 2)))

                elif ltype == "Flatten":
                    model.add(layers.Flatten())

                elif ltype == "Dense":
                    l2_value = params.get("l2", 0.0)
                    regularizer = regularizers.l2(l2_value) if l2_value > 0 else None
                    model.add(layers.Dense(units=params["units"], activation=params["activation"], kernel_regularizer=regularizer))

                elif ltype == "Dropout":
                    model.add(layers.Dropout(params["rate"]))

            # Flatten unutulduysa ekle
            if not any(l["type"] == "Flatten" for l in self.cnn_layer_config):
                model.add(layers.Flatten())

            # Çıkış katmanı
            model.add(layers.Dense(num_classes, activation="softmax"))

            # Derleme
            model.compile(optimizer=optimizer, loss="categorical_crossentropy", metrics=["accuracy"])

            # Callbacks
            callbacks = [self.create_progress_callback()]
            callbacks.append(self.create_logging_callback())

            # Scheduler callback'i parametreyle çağırıyoruz
            scheduler_cb = None
            if hasattr(self, "cnn_training_params") and "scheduler" in self.cnn_training_params:
                scheduler_combo = self.cnn_training_params["scheduler"]
                scheduler_cb = self.get_scheduler_callback(learning_rate, epochs, scheduler_combo)
            if scheduler_cb:
                callbacks.append(scheduler_cb)


            early_stop_cb = EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)
            callbacks.append(early_stop_cb)

            # Gradient histogram için örnek veri
            sample_X = X_train[:32]
            sample_y = y_train_cat[:32]
            gradient_cb = self.create_gradient_histogram_callback(model, sample_X, sample_y)
            callbacks.append(gradient_cb)

            # Augmentation aktifse kullan
            if self.cnn_training_params["augment_enable"].isChecked():
                rotation = self.cnn_training_params["augment_rotation"].value()
                zoom = self.cnn_training_params["augment_zoom"].value()
                flip = self.cnn_training_params["augment_flip"].isChecked()

                datagen = ImageDataGenerator(
                    rotation_range=rotation,
                    zoom_range=zoom,
                    horizontal_flip=flip
                )
                datagen.fit(X_train)

                history = model.fit(
                    datagen.flow(X_train, y_train_cat, batch_size=batch_size),
                    epochs=epochs,
                    validation_data=(X_test, y_test_cat),
                    callbacks=callbacks
                )
            else:
                # Augmentation pasifse doğrudan eğit
                # Eğitimden önce
                num_classes = len(np.unique(y_train))
                y_train_cat = tf.keras.utils.to_categorical(y_train, num_classes)
                y_test_cat = tf.keras.utils.to_categorical(y_test, num_classes)

                # Model eğitimi
                history = model.fit(
                    X_train, y_train_cat,
                    batch_size=batch_size,
                    epochs=epochs,
                    validation_data=(X_test, y_test_cat),
                    callbacks=callbacks
)


            self.trained_model = model
            self.plot_training_history(history)
            self.show_final_test_metrics(model, X_test, y_test_cat)
            self.status_bar.showMessage("CNN modeli başarıyla eğitildi.")

        except Exception as e:
            self.show_error(f"CNN eğitimi sırasında hata: {str(e)}")






    


    def train_gan(self):
        from tensorflow.keras.models import Sequential
        from tensorflow.keras.layers import Dense, LeakyReLU, BatchNormalization, Reshape, Flatten
        from tensorflow.keras.optimizers import Adam
        import matplotlib.pyplot as plt

        # Parametreler
        latent_dim = 100
        epochs = 5000
        batch_size = 128
        sample_interval = 1000

        # 1. Generator
        def build_generator():
            model = Sequential()
            model.add(Dense(256, input_dim=latent_dim))
            model.add(LeakyReLU(alpha=0.2))
            model.add(BatchNormalization(momentum=0.8))
            model.add(Dense(512))
            model.add(LeakyReLU(alpha=0.2))
            model.add(BatchNormalization(momentum=0.8))
            model.add(Dense(784, activation='tanh'))
            model.add(Reshape((28, 28, 1)))
            return model

        # 2. Discriminator
        def build_discriminator():
            model = Sequential()
            model.add(Flatten(input_shape=(28, 28, 1)))
            model.add(Dense(512))
            model.add(LeakyReLU(alpha=0.2))
            model.add(Dense(256))
            model.add(LeakyReLU(alpha=0.2))
            model.add(Dense(1, activation='sigmoid'))
            return model

        # 3. Eğitim
        try:
            # Veriyi yükle
            (X_train, _), (_, _) = tf.keras.datasets.mnist.load_data()
            X_train = (X_train.astype(np.float32) - 127.5) / 127.5
            X_train = np.expand_dims(X_train, axis=-1)

            valid = np.ones((batch_size, 1))
            fake = np.zeros((batch_size, 1))

            optimizer = Adam(0.0002, 0.5)

            generator = build_generator()
            discriminator = build_discriminator()
            discriminator.compile(loss='binary_crossentropy', optimizer=optimizer, metrics=['accuracy'])

            z = tf.keras.Input(shape=(latent_dim,))
            img = generator(z)
            discriminator.trainable = False
            validity = discriminator(img)
            combined = tf.keras.Model(z, validity)
            combined.compile(loss='binary_crossentropy', optimizer=optimizer)

            for epoch in range(epochs + 1):
                # Gerçek
                idx = np.random.randint(0, X_train.shape[0], batch_size)
                real_imgs = X_train[idx]

                # Sahte
                noise = np.random.normal(0, 1, (batch_size, latent_dim))
                gen_imgs = generator.predict(noise, verbose=0)

                # Eğitim
                d_loss_real = discriminator.train_on_batch(real_imgs, valid)
                d_loss_fake = discriminator.train_on_batch(gen_imgs, fake)
                d_loss = 0.5 * np.add(d_loss_real, d_loss_fake)

                # Generator eğitimi
                noise = np.random.normal(0, 1, (batch_size, latent_dim))
                g_loss = combined.train_on_batch(noise, valid)

                if epoch % sample_interval == 0:
                    self.status_bar.showMessage(f"[GAN] Epoch {epoch}  D loss: {d_loss[0]:.4f}  G loss: {g_loss:.4f}")
                    print(f"[{epoch}] D: {d_loss[0]:.4f}, G: {g_loss:.4f}")
                    
                    # Görüntü örnekleri kaydet
                    r, c = 5, 5
                    noise = np.random.normal(0, 1, (r * c, latent_dim))
                    gen_imgs = generator.predict(noise, verbose=0)
                    gen_imgs = 0.5 * gen_imgs + 0.5

                    fig, axs = plt.subplots(r, c)
                    cnt = 0
                    for i in range(r):
                        for j in range(c):
                            axs[i,j].imshow(gen_imgs[cnt, :, :, 0], cmap='gray')
                            axs[i,j].axis('off')
                            cnt += 1
                    os.makedirs("gan_samples", exist_ok=True)
                    fig.savefig(f"gan_samples/gan_{epoch}.png")
                    plt.close()

        except Exception as e:
            self.show_error(f"GAN eğitimi sırasında hata: {str(e)}")



    
    def create_neural_network(self):
        model = models.Sequential()
        first_layer = True

        for layer_config in self.mlp_layer_config:  # MLP katmanları
            layer_type = layer_config["type"]
            params = layer_config["params"].copy()

            # L2 regularization varsa kernel_regularizer olarak ekle
            if "l2" in params:
                l2_value = params.pop("l2")
                if l2_value and l2_value > 0:
                    params["kernel_regularizer"] = tf.keras.regularizers.l2(l2_value)

            if layer_type == "Dense":
                if first_layer:
                    # İlk katman input_shape içermeli, 1D feature sayısı olarak
                    params["input_shape"] = (self.X_train.shape[1],)
                    first_layer = False

                # Dense katmanı için parametrelerin türlerini kontrol edip ayarla
                units = int(params.get("units", 32))
                activation = params.get("activation", "relu")
                kernel_regularizer = params.get("kernel_regularizer", None)

                model.add(layers.Dense(units=units, activation=activation, kernel_regularizer=kernel_regularizer))

            elif layer_type == "Dropout":
                rate = float(params.get("rate", 0.5))
                model.add(layers.Dropout(rate))

            elif layer_type == "Flatten":
                model.add(layers.Flatten())

            else:
                # MLP'de Conv2D, MaxPooling2D gibi katmanlar olmamalı, pas geç
                pass

        # Çıkış katmanı: sınıf sayısı kadar softmax çıkışı
        num_classes = len(np.unique(self.y_train))
        model.add(layers.Dense(num_classes, activation="softmax"))

        return model





 
            
    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
                
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
                
        return ProgressCallback(self.progress_bar)
    

    def create_logging_callback(self):
        """Create a callback to log training progress into metrics_text in real-time and into a log file"""
        class LoggingCallback(tf.keras.callbacks.Callback):
            def __init__(inner_self, gui):
                super().__init__()
                inner_self.gui = gui
                inner_self.log_file = open("training_log.txt", "w")  # log dosyası oluştur

            def on_train_batch_end(inner_self, batch, logs=None):
                if logs is None:
                    logs = {}
                log_text = (
                    f"Batch {batch + 1}: "
                    f"loss={logs.get('loss', 0):.4f}, "
                    f"acc={logs.get('accuracy', 0):.4f}\n"
                )
                # GUI güncellemesi
                old_text = inner_self.gui.metrics_text.toPlainText()
                updated_text = old_text + log_text
                inner_self.gui.metrics_text.setText(updated_text)
                inner_self.gui.metrics_text.verticalScrollBar().setValue(
                    inner_self.gui.metrics_text.verticalScrollBar().maximum()
                )
                # Dosyaya yaz
                inner_self.log_file.write(log_text)

            def on_epoch_end(inner_self, epoch, logs=None):
                if logs is None:
                    logs = {}
                log_text = (
                    f"Epoch {epoch + 1}: "
                    f"loss={logs.get('loss'):.4f}, "
                    f"acc={logs.get('accuracy', 0):.4f}, "
                    f"val_loss={logs.get('val_loss', 0):.4f}, "
                    f"val_acc={logs.get('val_accuracy', 0):.4f}\n"
                )
                # GUI güncellemesi
                old_text = inner_self.gui.metrics_text.toPlainText()
                updated_text = old_text + log_text
                inner_self.gui.metrics_text.setText(updated_text)
                inner_self.gui.metrics_text.verticalScrollBar().setValue(
                    inner_self.gui.metrics_text.verticalScrollBar().maximum()
                )
                # Dosyaya yaz
                inner_self.log_file.write(log_text)

            def on_train_end(inner_self, logs=None):
                inner_self.log_file.write("Training completed.\n")
                inner_self.log_file.close()

        return LoggingCallback(self)


        
    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        
        # Create appropriate visualization based on data
        if self.y_test.dtype.kind in "fc":  # Regression
            ax = self.figure.add_subplot(111)
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()],
                   [self.y_test.min(), self.y_test.max()],
                   'r--', lw=2)
            ax.set_xlabel("Actual Values")
            ax.set_ylabel("Predicted Values")
            
        else:  # Classification
            if self.X_train.shape[1] > 2:  # Use PCA for visualization
                from sklearn.decomposition import PCA
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
                
            else:  # Direct 2D visualization
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        
        self.canvas.draw()
        
    def update_metrics(self, y_pred):
        """Update metrics display"""
        metrics_text = "Model Performance Metrics:\n\n"
        
        # Calculate appropriate metrics based on problem type
        if self.y_test.dtype.kind in "fc":  # Regression
            mse = mean_squared_error(self.y_test, y_pred)
            rmse = np.sqrt(mse)
            r2 = self.current_model.score(self.X_test, self.y_test)
            
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Root Mean Squared Error: {rmse:.4f}\n"
            metrics_text += f"R² Score: {r2:.4f}"
            
        else:  # Classification
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)
            
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        
        self.metrics_text.setText(metrics_text)
        
    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        
        # Plot training & validation accuracy
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_ylabel('Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        # Plot training & validation loss
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        
        self.figure.tight_layout()
        self.canvas.draw()
        
    def show_final_test_metrics(self, model, X_test, y_test):
        """Final test metriklerini yan panelde göster"""
        y_pred = np.argmax(model.predict(X_test), axis=1)
        y_true = np.argmax(y_test, axis=1)

        acc = accuracy_score(y_true, y_pred)
        f1 = f1_score(y_true, y_pred, average="macro")
        precision = precision_score(y_true, y_pred, average="macro")
        recall = recall_score(y_true, y_pred, average="macro")

        # 🔁 Önceki logları koru
        previous_logs = self.metrics_text.toPlainText()

        text = (
            "\n📌 Final Test Metrics:\n\n"
            f"Accuracy:  {acc:.4f}\n"
            f"F1 Score:  {f1:.4f}\n"
            f"Precision: {precision:.4f}\n"
            f"Recall:    {recall:.4f}\n"
        )

        self.metrics_text.setText(previous_logs + text)
        self.metrics_text.verticalScrollBar().setValue(
            self.metrics_text.verticalScrollBar().maximum()
        )



    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
    def train_naive_bayes(self, smoothing_input):
        try:
            var_smoothing = smoothing_input.value()
            prior_type = self.nb_prior_combo.currentText()
            
            # Prior seçimi
            if prior_type == "Uniform":
                class_prior = None
            else:
                try:
                    prior_str = self.nb_prior_input.text()
                    class_prior = eval(prior_str)
                    
                    if not isinstance(class_prior, list) or not np.isclose(sum(class_prior), 1.0):
                        raise ValueError("Prior listesi geçersiz veya toplamı 1 değil.")
                except Exception as e:
                    self.show_error(f"Custom prior hatalı: {str(e)}")
                    return
            
            model = GaussianNB(var_smoothing=var_smoothing, priors=class_prior)

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            
            self.status_bar.showMessage("Gaussian Naive Bayes modeli eğitildi.")
        
        except Exception as e:
            self.show_error(f"Naive Bayes eğitimi sırasında hata: {str(e)}")

    def compare_missing_data_methods(self):
        try:
            # Yöntemler ve skorları sakla
            methods = ["Mean Imputation", "Interpolation", "Forward Fill", "Backward Fill"]
            scores = []
            for method in methods:
                # Veriyi sıfırla ve yeniden yükle
                dataset_name = self.dataset_combo.currentText()
                if dataset_name == "Breast Cancer Dataset":
                    data = datasets.load_breast_cancer()
                elif dataset_name == "Digits Dataset":
                    data = datasets.load_digits()
                else:
                    self.show_error("Bu karşılaştırma için desteklenen veri setleri: Breast Cancer, Digits")
                    return
                
                X, y = data.data.copy(), data.target.copy()
                # Eksik veri oluştur
                rng = np.random.default_rng(42)
                mask = rng.random(X.shape) < 0.1
                X[mask] = np.nan
                # Split
                test_size = self.split_spin.value()
                X_train, X_test, y_train, y_test = model_selection.train_test_split(
                    X, y, test_size=test_size, random_state=42
                )
                if method == "Mean Imputation":
                    from sklearn.impute import SimpleImputer
                    imputer = SimpleImputer(strategy="mean")
                elif method == "Interpolation":
                    X_train = pd.DataFrame(X_train).interpolate().values
                    X_test = pd.DataFrame(X_test).interpolate().values
                    imputer = None
                elif method == "Forward Fill":
                    X_train = pd.DataFrame(X_train).fillna(method="ffill").values
                    X_test = pd.DataFrame(X_test).fillna(method="ffill").values
                    imputer = None
                elif method == "Backward Fill":
                    X_train = pd.DataFrame(X_train).fillna(method="bfill").values
                    X_test = pd.DataFrame(X_test).fillna(method="bfill").values
                    imputer = None
                if imputer:
                    X_train = imputer.fit_transform(X_train)
                    X_test = imputer.transform(X_test)
            # Model eğit
                model = LogisticRegression(max_iter=200)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                acc = accuracy_score(y_test, y_pred)
                scores.append(acc)    
        # Grafik çiz
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.bar(methods, scores)
            ax.set_title("Eksik Veri Yöntemleri vs Doğruluk")
            ax.set_ylabel("Accuracy")
            ax.set_ylim(0, 1)
            self.canvas.draw()
            self.status_bar.showMessage("Eksik veri yöntemleri başarıyla karşılaştırıldı.")
        except Exception as e:
            self.show_error(f"Karşılaştırma hatası: {str(e)}")
    
    def train_lda(self):
        try:
            n_components = self.lda_components_spin.value()
            from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
            lda = LinearDiscriminantAnalysis(n_components=n_components)

            X_proj = lda.fit_transform(self.X_train, self.y_train)
            X_test_proj = lda.transform(self.X_test)

            explained_var = lda.explained_variance_ratio_
            explained_var_total = explained_var.sum()

            if explained_var_total >= 0.95:
                quality_comment = "Excellent separation (≥95% variance explained)."
            elif explained_var_total >= 0.85:
                quality_comment = "Good separation (≥85% variance explained)."
            elif explained_var_total >= 0.70:
                quality_comment = "Fair separation (≥70% variance explained)."
            else:
                quality_comment = "Poor separation (<70% variance explained)."

            self.figure.clear()
            ax = self.figure.add_subplot(111)

            if X_test_proj.shape[1] >= 2:
                scatter = ax.scatter(X_test_proj[:, 0], X_test_proj[:, 1], c=self.y_test, cmap='viridis')
                ax.set_title("LDA Projection (2D)")
            else:
                scatter = ax.scatter(X_test_proj[:, 0], np.zeros_like(X_test_proj[:, 0]), c=self.y_test, cmap='viridis')
                ax.set_title("LDA Projection (1D)")

            self.figure.colorbar(scatter)
            self.canvas.draw()

            self.status_bar.showMessage("LDA uygulandı ve görselleştirildi")
            
            result = (
                "LDA Results:\n\n"
                "Dimensionality reduction completed.\n\n"
                f"Number of Components: {n_components}\n"
                f"Explained Variance Ratio: {explained_var[0]:.4f}\n\n"
                f"Interpretation:\n"
                f"- {quality_comment}\n"
                "Note: LDA assumes linear boundaries and normal distribution within classes."
            )

            self.metrics_text.setText(result)
            
        except Exception as e:
            self.show_error(f"LDA eğitimi sırasında hata: {str(e)}")


    def train_tsne(self):
        try:
            from sklearn.manifold import TSNE

            perplexity = self.tsne_perplexity.value()
            n_iter = self.tsne_iter.value()
            learning_rate = self.tsne_lr.value()

            tsne = TSNE(n_components=2, perplexity=perplexity,
                        n_iter=n_iter, learning_rate=learning_rate,
                        random_state=42)

            X_proj = tsne.fit_transform(self.X_test)

            # Görselleştir
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=self.y_test, cmap='viridis')
            ax.set_title("t-SNE Projection")
            self.figure.colorbar(scatter)
            self.canvas.draw()

            # ✅ SAĞ PANEL METNİ EKLİYORUZ
            result = (
                " t-SNE Results:\n\n"
                " Dimensionality reduction completed.\n\n"
                f"Parameters:\n"
                f"- Perplexity: {perplexity}\n"
                f"- Learning Rate: {learning_rate}\n"
                f"- Iterations: {n_iter}\n\n"
                " Visual inspection recommended for cluster separation.\n\n"
                "Note: t-SNE does not provide explained variance scores."
            )
            self.metrics_text.setText(result)

            self.status_bar.showMessage("t-SNE başarıyla uygulandı ve görselleştirildi.")

        except Exception as e:
            self.show_error(f"t-SNE işlemi sırasında hata oluştu: {str(e)}")

    def train_umap(self):
        try:
            import umap
            from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

            # Parametreleri al
            n_neighbors = self.umap_neighbors.value()
            min_dist = self.umap_min_dist.value()

            # UMAP çalıştır
            metric = self.umap_metric_combo.currentText()
            reducer = umap.UMAP(n_neighbors=n_neighbors, min_dist=min_dist, metric=metric, random_state=42)
            X_proj = reducer.fit_transform(self.X_test)

            # Görselleştir
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=self.y_test, cmap='viridis')
            ax.set_title("UMAP Projection")
            self.figure.colorbar(scatter)
            self.canvas.draw()

            # Metrikleri hesapla
            silhouette = silhouette_score(X_proj, self.y_test)
            db_index = davies_bouldin_score(X_proj, self.y_test)
            ch_index = calinski_harabasz_score(X_proj, self.y_test)

            # Silhouette yorumları
            if silhouette >= 0.71:
                sil_comment = "Excellent"
            elif silhouette >= 0.51:
                sil_comment = "Good"
            elif silhouette >= 0.26:
                sil_comment = "Fair"
            else:
                sil_comment = "Poor"

            # Davies-Bouldin yorumları
            if db_index <= 0.5:
                db_comment = "Excellent"
            elif db_index <= 1.0:
                db_comment = "Good"
            elif db_index <= 2.0:
                db_comment = "Fair"
            else:
                db_comment = "Poor"

            # Calinski-Harabasz yorumları
            if ch_index >= 1000:
                ch_comment = "Excellent"
            elif ch_index >= 500:
                ch_comment = "Good"
            elif ch_index >= 100:
                ch_comment = "Fair"
            else:
                ch_comment = "Poor"

            # Genel yorum
            comments = [sil_comment, db_comment, ch_comment]
            counts = {c: comments.count(c) for c in ["Excellent", "Good", "Fair", "Poor"]}

            if counts["Excellent"] >= 2:
                overall_comment = "Overall Quality: Excellent clustering detected."
            elif counts["Good"] >= 2:
                overall_comment = "Overall Quality: Good clustering."
            elif counts["Fair"] >= 2:
                overall_comment = "Overall Quality: Fair clustering."
            else:
                overall_comment = "Overall Quality: Poor clustering; consider parameter tuning."

            # Yan panele yazılacak metin
            result = (
                "UMAP Results:\n\n"
                "Dimensionality reduction completed.\n\n"
                f"Parameters:\n"
                f"- n_neighbors: {n_neighbors}\n"
                f"- min_dist: {min_dist}\n\n"
                "Cluster Quality Metrics:\n"
                f"- Silhouette Score: {silhouette:.4f} ({sil_comment})\n"
                f"- Davies-Bouldin Index: {db_index:.4f} ({db_comment})\n"
                f"- Calinski-Harabasz Index: {ch_index:.4f} ({ch_comment})\n\n"
                f"{overall_comment}\n\n"
                "Visual inspection recommended for interpretation.\n\n"
                "Note: UMAP does not provide explained variance scores."
            )

            self.metrics_text.setText(result)

            self.status_bar.showMessage("UMAP başarıyla uygulandı ve görselleştirildi.")

        except Exception as e:
            self.show_error(f"UMAP işlemi sırasında hata oluştu: {str(e)}")
    
    def plot_elbow_method(self):
        try:
            from sklearn.cluster import KMeans

            inertias = []
            K_range = range(1, 11)
            for k in K_range:
                kmeans = KMeans(n_clusters=k, random_state=42)
                kmeans.fit(self.X_train)
                inertias.append(kmeans.inertia_)

            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(K_range, inertias, marker='o')
            ax.set_title("Elbow Method for K-Means")
            ax.set_xlabel("Number of Clusters (k)")
            ax.set_ylabel("Inertia")
            self.canvas.draw()

            self.status_bar.showMessage("Elbow Method grafiği çizildi.")

        except Exception as e:
            self.show_error(f"Elbow Method çizilirken hata oluştu: {str(e)}")


    def train_pca(self):
        try:
            from sklearn.decomposition import PCA

            # Parametreleri al
            n_components = self.pca_components_spin.value()
            whiten = self.pca_whiten_checkbox.isChecked()
            print("Seçilen n_components:", n_components)


            # PCA'yı önce TRAIN verisinde fit et
            pca = PCA(n_components=n_components, whiten=whiten)
            print("Seçilen n_components:", n_components)

            pca.fit(self.X_train)

            # Test verisini dönüştür
            X_proj = pca.transform(self.X_test)

            self.figure.clear()

            # Bar grafiği çiz
            ax1 = self.figure.add_subplot(211)
            ax1.bar(range(1, len(pca.explained_variance_ratio_) + 1), pca.explained_variance_ratio_)
            ax1.set_title("Explained Variance Ratio by PCA Components")
            ax1.set_xlabel("Component")
            ax1.set_ylabel("Variance Ratio")

            # Scatter grafiği çiz
            # Scatter grafiği çiz (her zaman 2D, ilk 2 bileşene göre)
            if X_proj.shape[1] >= 2:
                if X_proj.shape[1] >= 3 and self.pca_proj_combo.currentText() == "3D":
                    from mpl_toolkits.mplot3d import Axes3D
                    ax2 = self.figure.add_subplot(212, projection='3d')
                    scatter = ax2.scatter(X_proj[:, 0], X_proj[:, 1], X_proj[:, 2], c=self.y_test, cmap='viridis')
                    ax2.set_title("PCA Projection (First 3 Components)")

                else:
                    ax2 = self.figure.add_subplot(212)
                    scatter = ax2.scatter(X_proj[:, 0], X_proj[:, 1], c=self.y_test, cmap='viridis')
                    ax2.set_title("PCA Projection (First 2 Components)")
                self.figure.colorbar(scatter, ax=ax2)

            # PCA yorum metni oluştur
            expl_var = pca.explained_variance_ratio_
            cumulative_var = np.cumsum(expl_var)[-1] * 100

            text = f"📊 PCA Results:\n\n"
            text += f"Number of Components: {n_components}\n"
            text += f"Explained Variance Ratio per Component: {np.round(expl_var,4)}\n"
            text += f"Total Explained Variance: {cumulative_var:.2f}%\n\n"

            if cumulative_var >= 95:
                text += "✅ Excellent: ≥95% variance explained.\n"
            elif cumulative_var >= 80:
                text += "👍 Good: ≥80% variance explained.\n"
            elif cumulative_var >= 60:
                text += "⚠️ Moderate: ≥60% variance explained.\n"
            else:
                text += "❌ Poor: <60% variance explained. Consider increasing n_components.\n"

            # Yan metin alanına yaz
            self.metrics_text.setText(text)
            self.figure.tight_layout()
            self.canvas.draw()
            self.status_bar.showMessage("PCA başarıyla uygulandı ve görselleştirildi.")

        except Exception as e:
            self.show_error(f"PCA işlemi sırasında hata oluştu: {str(e)}")
    
    def open_covariance_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Manual Covariance + Eigenvectors")
        layout = QVBoxLayout(dialog)

        label = QLabel("Enter 2D data rows (e.g., 1,2; 3,4; 5,6):")
        layout.addWidget(label)

        data_input = QLineEdit()
        data_input.setPlaceholderText("1,2; 3,4; 5,6")
        layout.addWidget(data_input)

        compute_btn = QPushButton("Compute and Show in Visualization")
        layout.addWidget(compute_btn)

        def compute():
            try:
                text = data_input.text()
                rows = [list(map(float, row.strip().split(","))) for row in text.split(";")]
                cov = np.array(rows)  # Kullanıcının verdiği matris doğrudan kovaryans

                eigvals, eigvecs = np.linalg.eig(cov)
                principal = eigvecs[:, np.argmax(eigvals)]

                # Simülasyon için rastgele veri oluştur
                X = np.random.multivariate_normal([0, 0], cov, size=100)
                X_proj = X @ principal

                result = (
                    f"Covariance Matrix (user input):\n{cov}\n\n"
                    f"Eigenvalues:\n{eigvals}\n\n"
                    f"Eigenvectors:\n{eigvecs}\n\n"
                    f"Principal Eigenvector:\n{principal}\n\n"
                    f"Projected Values:\n{X_proj}"
                )

                self.metrics_text.setText(result)

                self.figure.clear()
                ax = self.figure.add_subplot(111)
                ax.scatter(X_proj, np.zeros_like(X_proj), alpha=0.5)
                ax.set_title("1D Projection Using Principal Eigenvector")
                self.canvas.draw()

                self.status_bar.showMessage("1D projection (manual covariance) complete.")

            except Exception as e:
                self.show_error(f"Error: {str(e)}")
        
        compute_btn.clicked.connect(compute)
        dialog.exec()
    
    def train_kmeans(self):
        print("[train_kmeans] Butondan çağrıldı.")
        try:
            kfold_metrics_text = ""
            scores = []
            mse_scores = []
            rmse_scores = []
            fold_sizes = []
            if self.kfold_checkbox.isChecked():
                from sklearn.model_selection import StratifiedKFold
                from scipy.stats import mode
                from sklearn.cluster import KMeans
                from sklearn.metrics import accuracy_score

                if self.y_train is None:
                    self.show_error("K-Fold için label'lı veri gerekir!")
                    return

                k = self.kfold_spin.value()
                skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=42)

                scores = []
                fold_sizes = []
                for train_idx, test_idx in skf.split(self.X_train, self.y_train):
                    X_tr, X_te = self.X_train[train_idx], self.X_train[test_idx]
                    y_tr, y_te = self.y_train[train_idx], self.y_train[test_idx]

                    kmeans = KMeans(n_clusters=len(np.unique(y_tr)), random_state=42)
                    kmeans.fit(X_tr)
                    y_pred = kmeans.predict(X_te)

                    labels = np.zeros_like(y_pred)
                    for i in range(len(np.unique(kmeans.labels_))):
                        mask = (y_pred == i)
                        if np.any(mask):
                            labels[mask] = mode(y_te[mask])[0]

                    acc = accuracy_score(y_te, labels)
                    scores.append(acc)
                    fold_sizes.append(len(test_idx))
                    from sklearn.metrics import mean_squared_error

                    mse = mean_squared_error(y_te, labels)
                    rmse = np.sqrt(mse)

                    mse_scores.append(mse)
                    rmse_scores.append(rmse)
                mean_acc = np.mean(scores)
                std_acc = np.std(scores)
                mean_mse = np.mean(mse_scores)
                std_mse = np.std(mse_scores)
                mean_rmse = np.mean(rmse_scores)
                std_rmse = np.std(rmse_scores)
                kfold_metrics_text=(
                    f"K-Fold Cross-Validation (k={k})\n"
                    f"Fold Sizes: {fold_sizes}\n"
                    f"Fold Accuracies: {scores}\n"
                    f"Mean Accuracy: {mean_acc:.4f}\n"
                    f"Std Dev: {std_acc:.4f}\n"
                    f"MSE per Fold: {', '.join(f'{val:.4f}' for val in mse_scores)}\n"
                    f"RMSE per Fold: {', '.join(f'{val:.4f}' for val in rmse_scores)}\n"
                    f"Mean MSE: {mean_mse:.4f}\n"
                    f"Std MSE: {std_mse:.4f}\n"
                    f"Mean RMSE: {mean_rmse:.4f}\n"
                    f"Std RMSE: {std_rmse:.4f}\n"
                )
                self.status_bar.showMessage(f"KMeans evaluated with K-Fold (mean acc = {mean_acc:.4f})")
                

                # → normal train_kmeans kodları aşağıda kalıyor
            from sklearn.cluster import KMeans
            from sklearn.decomposition import PCA
            from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

            # Parametreleri al
            n_clusters = self.kmeans_n_clusters.value()
            max_iter = self.kmeans_max_iter.value()
            n_init = self.kmeans_n_init.value()

            print(f"[K-Means] Parametreler: n_clusters={n_clusters}, max_iter={max_iter}, n_init={n_init}")

            # KMeans modelini eğit
            kmeans = KMeans(n_clusters=n_clusters, max_iter=max_iter, n_init=n_init, random_state=42)
            kmeans.fit(self.X_train)
            labels = kmeans.predict(self.X_test)

            # PCA ile 2D'ye indirgeme
            pca = PCA(n_components=2)
            X_proj = pca.fit_transform(self.X_test)

            # Görselleştirme
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=labels, cmap='viridis')
            ax.set_title(f"K-Means Clustering (k={n_clusters}) in PCA Space")
            self.figure.colorbar(scatter)
            self.canvas.draw()

            import plotly.express as px

            fig = px.scatter(
                x=X_proj[:, 0],
                y=X_proj[:, 1],
                color=labels.astype(str),
                title=f"K-Means Clustering (k={n_clusters}) in PCA Space (Plotly)"
            )

            fig.show()
            self.status_bar.showMessage("Plotly PCA visualization displayed.")

            # METRİKLERİ HESAPLA
            silhouette = silhouette_score(self.X_test, labels)
            davies_bouldin = davies_bouldin_score(self.X_test, labels)
            calinski_harabasz = calinski_harabasz_score(self.X_test, labels)

            # Silhouette yorumu
            if silhouette >= 0.71:
                sil_comment = "Excellent"
            elif silhouette >= 0.51:
                sil_comment = "Good"
            elif silhouette >= 0.26:
                sil_comment = "Fair"
            else:
                sil_comment = "Poor"

            # Davies-Bouldin yorumu (küçük daha iyi)
            if davies_bouldin <= 0.5:
                db_comment = "Excellent"
            elif davies_bouldin <= 1.0:
                db_comment = "Good"
            elif davies_bouldin <= 2.0:
                db_comment = "Fair"
            else:
                db_comment = "Poor"

            # Calinski-Harabasz yorumu (büyük daha iyi)
            if calinski_harabasz >= 1000:
                ch_comment = "Excellent"
            elif calinski_harabasz >= 500:
                ch_comment = "Good"
            elif calinski_harabasz >= 100:
                ch_comment = "Fair"
            else:
                ch_comment = "Poor"

            # Genel kalite yorumu
            comments = [sil_comment, db_comment, ch_comment]
            counts = {c: comments.count(c) for c in ["Excellent", "Good", "Fair", "Poor"]}

            if counts["Excellent"] >= 2:
                overall_comment = "Overall Quality: Excellent clustering detected."
            elif counts["Good"] >= 2:
                overall_comment = "Overall Quality: Good clustering with well-separated clusters."
            elif counts["Fair"] >= 2:
                overall_comment = "Overall Quality: Acceptable clustering, but could be improved."
            else:
                overall_comment = "Overall Quality: Poor clustering; consider tuning parameters."

                # Sonucu yan panelde göster
            metrics_text = (
                f"Cluster Quality Metrics:\n\n"
                f"Silhouette Score: {silhouette:.4f} ({sil_comment})\n"
                f"Davies-Bouldin Index: {davies_bouldin:.4f} ({db_comment})\n"
                f"Calinski-Harabasz Index: {calinski_harabasz:.4f} ({ch_comment})\n\n"
                f"{overall_comment}"
            )
            final_metrics_text = kfold_metrics_text + metrics_text
            self.metrics_text.setText(final_metrics_text)

            self.status_bar.showMessage(f"K-Means clustering evaluated. {overall_comment}")

        except Exception as e:
            self.show_error(f"K-Means eğitimi sırasında hata oluştu: {str(e)}")




    def train_model(self, model_name, param_widgets):
        try:
            params = {}
            for param_name, widget in param_widgets.items():
                if isinstance(widget, QSpinBox) or isinstance(widget, QDoubleSpinBox):
                    params[param_name] = widget.value()
                elif isinstance(widget, QCheckBox):
                    params[param_name] = widget.isChecked()
                elif isinstance(widget, QComboBox):
                    params[param_name] = widget.currentText()

            if model_name == "Linear Regression":
                from sklearn.metrics import mean_absolute_error
                model = LinearRegression(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
            elif model_name == "Support Vector Regression":
                model = SVR(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    from sklearn.metrics import mean_absolute_error
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
                self.current_model = model
                self.update_metrics(y_pred)
                self.update_visualization(y_pred)
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
                
            elif model_name == "Logistic Regression":
                model = LogisticRegression(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                try:
                    if hasattr(model, "predict_proba"):
                        y_pred_proba = model.predict_proba(self.X_test)
                        loss = log_loss(self.y_test, y_pred_proba)
                        loss_type = "Cross-Entropy"
                    else:
                        raise ValueError("Model predict_proba desteği vermiyor.")
                except Exception as e:
                    self.show_error(f"Cross-Entropy hesaplanamadı: {str(e)}")
                    return
                self.current_model = model
                self.update_metrics(y_pred)
                self.update_visualization(y_pred)
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
            elif model_name == "Support Vector Machine":
                model = SVC(probability = True, **params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.classification_loss_combo.currentText()
                if loss_type == "Cross-Entropy":
                    if hasattr(model, "predict_proba"):
                        y_pred_proba = model.predict_proba(self.X_test)
                    elif hasattr(model, "decision_function"):
                        scores = model.decision_function(self.X_test)
                        y_pred_proba = np.exp(scores) / np.sum(np.exp(scores), axis=1, keepdims=True)
                    else:
                        try:
                            y_pred_proba = model.predict_proba(self.X_Test)
                        except Exception:
                            raise ValueError("Modelden olasılık alınamıyor.")
                        loss = log_loss(self.y_test, y_pred_proba)

                elif loss_type == "Hinge":
                    if hasattr(model, "decision_function"):
                        scores = model.decision_function(self.X_test)
                    else:
                        raise ValueError("Model decision_function desteği vermiyor.")
                    classes = np.unique(self.y_test)
                    y_true = label_binarize(self.y_test, classes=classes)
                    loss = hinge_loss(y_true, scores)
            elif model_name == "K-Means":
                from sklearn.cluster import KMeans
                model = KMeans(**params, random_state=42)
                model.fit(self.X_train)
                y_pred = model.predict(self.X_test)

                # PCA ile görselleştirme (X_test üzerinde)
                from sklearn.decomposition import PCA
                pca = PCA(n_components=2)
                X_proj = pca.fit_transform(self.X_test)

                self.figure.clear()
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=y_pred, cmap='tab10')
                ax.set_title("K-Means Clustering (PCA 2D)")
                self.figure.colorbar(scatter)
                self.canvas.draw()

                self.status_bar.showMessage("K-Means modeli eğitildi ve görselleştirildi.")
        
            else:
                self.show_error(f"Unsupported model: {model_name}")
                return
            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            if 'loss_type' in locals() and 'loss' in locals():
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
            else:
                self.status_bar.showMessage(f"{model_name} trained successfully.")
        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")
            model.fit(self.X_train, self.y_train)
            y_pred = model.predict(self.X_test)
            if np.issubdtype(self.y_test.dtype, np.floating):  # Regression
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
            else:  # Classification
                loss_type = self.classification_loss_combo.currentText()

                if loss_type == "Cross-Entropy":
                    try:
                        if hasattr(model, "predict_proba"):
                            y_pred_proba = model.predict_proba(self.X_test)
                        elif hasattr(model, "decision_function"):
                            scores = model.decision_function(self.X_test)
                            y_pred_proba = np.exp(scores) / np.sum(np.exp(scores), axis=1, keepdims=True)
                        else:
                            raise ValueError("Modelden olasılık alınamıyor.")

                        loss = log_loss(self.y_test, y_pred_proba)
                    except Exception as e:
                        self.show_error(f"Cross-Entropy hesaplanamadı: {str(e)}")
                        return

                elif loss_type == "Hinge":
                    try:
                        if hasattr(model, "decision_function"):
                            scores = model.decision_function(self.X_test)
                        else:
                            raise ValueError("Model decision_function desteği vermiyor.")

                        classes = np.unique(self.y_test)
                        y_true = label_binarize(self.y_test, classes=classes)
                        loss = hinge_loss(y_true, scores)
                    except Exception as e:
                        self.show_error(f"Hinge loss hesaplanamadı: {str(e)}")
                        return

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")

            loss_type = self.regression_loss_combo.currentText()
            if loss_type == "MSE":
                loss = mean_squared_error(self.y_test, y_pred)
            elif loss_type == "MAE":
                loss = mean_absolute_error(self.y_test, y_pred)
            elif loss_type == "Huber":
                delta = 1.0
                error = self.y_test - y_pred
                loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")
    
    def load_boston_housing_dataset(self):
        try:
            data_url = "http://lib.stat.cmu.edu/datasets/boston"
            raw_df = pd.read_csv(data_url, sep="\s+", skiprows=22, header=None)
            X = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, 1:]])
            y = raw_df.values[1::2, 0]

            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
            model_selection.train_test_split(X, y, test_size=test_size, random_state=42)

            self.apply_scaling()
            self.status_bar.showMessage("Loaded Boston Housing Dataset")

        except Exception as e:
            self.show_error(f"Error loading Boston Housing Dataset: {str(e)}")

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()