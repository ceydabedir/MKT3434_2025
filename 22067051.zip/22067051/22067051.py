import sys
import numpy as np
import pandas as pd
from sklearn.svm import SVC, SVR
from sklearn.metrics import log_loss, hinge_loss
from sklearn.preprocessing import label_binarize
from sklearn.metrics import log_loss, hinge_loss, mean_squared_error, mean_absolute_error, accuracy_score, confusion_matrix
from sklearn.preprocessing import label_binarize


from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QTabWidget, QPushButton, QLabel,
    QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
    QGroupBox, QScrollArea, QTextEdit, QStatusBar,
    QProgressBar, QCheckBox, QGridLayout, QMessageBox,
    QDialog, QLineEdit
)

from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, mean_squared_error, confusion_matrix
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers

class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        # Regression loss combo (will be added in regression panel)
        self.regression_loss_combo = None
        self.classification_loss_combo = None
        self.current_model = None
        
        # Neural network configuration
        self.layer_config = []
        
        # Create components
        self.create_data_section()
        
        
    
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()
    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            # Load selected dataset
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            # Split data
            
            test_size = self.split_spin.value()
            random_state = self.seed_spin.value() 
            shuffle = self.shuffle_checkbox.isChecked()
            stratify = data.target if use_stratify and len(np.unique(data.target)) < len(data.target) else None
            
            
            
            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(data.data, data.target,
                                                 test_size=test_size,
                                                 random_state=random_state,
                                                 shuffle=shuffle,
                                                 stratify=stratify)
            print("Train sınıf dağılımı:", np.unique(self.y_train, return_counts=True))
            print("Test sınıf dağılımı:", np.unique(self.y_test, return_counts=True))
            # Apply scaling if selected
            self.apply_scaling()
            
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")
    
    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                # Load data
                data = pd.read_csv(file_name)
                
                # Ask user to select target column
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                if pd.api.types.is_numeric_dtype(y):
                    unique_values = y.nunique()
                    if unique_values > 10:
                        msg = QMessageBox.question(
                            self,
                            "Sınıf Dönüştürme",
                            f"Hedef sütunu sürekli sayısal ({unique_values} farklı değer var).\n"
                            "Bunu sınıflandırma için otomatik olarak 2 sınıfa çevirmek ister misiniz?",
                            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                        if msg == QMessageBox.StandardButton.Yes:
                            median = y.median()
                            y = (y > median).astype(int)  # medyan üstü = 1, altı = 0
                            self.status_bar.showMessage("Hedef sütunu sınıflara dönüştürüldü (otomatik).")
                    # Split data
                    test_size = self.split_spin.value()
                    random_state = self.seed_spin.value()
                    shuffle = self.shuffle_checkbox.isChecked()
                
                    stratify = y if self.stratified_checkbox.isChecked() else None
                    (self.X_train, self.X_test, self.y_train, self.y_test) =  model_selection.train_test_split(      
                        X, y,
                        test_size=test_size,
                        random_state=random_state,
                        shuffle=shuffle,
                        stratify=y if self.stratified_checkbox.isChecked() else None)
                    print("Train sınıf dağılımı:", np.unique(self.y_train, return_counts=True))
                    print("Test sınıf dağılımı:", np.unique(self.y_test, return_counts=True))
                    # Apply scaling if selected
                    self.apply_scaling()
                    
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")
    
    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None
    
    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                self.X_train = scaler.fit_transform(self.X_train)
                self.X_test = scaler.transform(self.X_test)
                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")
    def apply_missing_value_handling(self):
        """Uygun eksik veri doldurma yöntemini uygula"""
        method = self.missing_value_combo.currentText()

        try:
            if method == "No Fill":
                return

            if method == "Mean Imputation":
                from sklearn.impute import SimpleImputer
                imputer = SimpleImputer(strategy="mean")
                self.X_train = imputer.fit_transform(self.X_train)
                self.X_test = imputer.transform(self.X_test)

            elif method == "Interpolation":
                self.X_train = pd.DataFrame(self.X_train).interpolate().values
                self.X_test = pd.DataFrame(self.X_test).interpolate().values

            elif method == "Forward Fill":
                self.X_train = pd.DataFrame(self.X_train).fillna(method="ffill").values
                self.X_test = pd.DataFrame(self.X_test).fillna(method="ffill").values

            elif method == "Backward Fill":
                self.X_train = pd.DataFrame(self.X_train).fillna(method="bfill").values
                self.X_test = pd.DataFrame(self.X_test).fillna(method="bfill").values

            self.status_bar.showMessage(f"Applied missing value method: {method}")

        except Exception as e:
            self.show_error(f"Error handling missing values: {str(e)}")

    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_group.setStyleSheet("QGroupBox { background-color: #f8c8dc; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        data_layout = QHBoxLayout()
        
        # Dataset selection
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset",
            "Iris Dataset",
            "Breast Cancer Dataset",
            "Digits Dataset",
            "Boston Housing Dataset",
            "MNIST Dataset",   
        ])
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)
        
        # Data loading button
        self.load_btn = QPushButton("Load Data")
        self.load_btn.clicked.connect(self.load_custom_data)
        
        # Preprocessing options
        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems([
            "No Scaling",
            "Standard Scaling",
            "Min-Max Scaling",
            "Robust Scaling"
        ])
        self.missing_value_combo = QComboBox()
        self.missing_value_combo.addItems([
            "No Fill",
            "Mean Imputation",
            "Interpolation",
            "Forward Fill",
            "Backward Fill"
        ])
        
        # Train-test split options
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setValue(0.2)
        self.split_spin.setSingleStep(0.05)
        # Shuffle seçeneği
        self.shuffle_checkbox = QCheckBox("Shuffle")
        self.shuffle_checkbox.setChecked(True)

        # Random seed seçeneği  
        self.seed_spin = QSpinBox()
        self.seed_spin.setRange(0, 9999)
        self.seed_spin.setValue(42)

        self.stratified_checkbox = QCheckBox("Use Stratified Split (Classification Only)")
        self.stratified_checkbox.setChecked(False)

        data_layout.addWidget(QLabel("Dataset:"))
        data_layout.addWidget(self.dataset_combo)
        data_layout.addWidget(self.load_btn)
        
        data_layout.addWidget(QLabel("Scaling:"))
        data_layout.addWidget(self.scaling_combo)
        data_layout.addWidget(QLabel("Missing Values:"))
        data_layout.addWidget(self.missing_value_combo)
        
        
        data_layout.addWidget(QLabel("Test Split:"))
        data_layout.addWidget(self.split_spin)
        data_layout.addWidget(self.shuffle_checkbox)
        data_layout.addWidget(QLabel("Seed:"))
        data_layout.addWidget(self.seed_spin)
        
        
        data_layout.addWidget(self.stratified_checkbox)
        self.compare_btn = QPushButton("Compare Missing Data Methods")
        self.compare_btn.clicked.connect(self.compare_missing_data_methods)
        data_layout.addWidget(self.compare_btn)
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)

        
        
    
    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        # Create individual tabs
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab)
        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)
    
    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Regression section
        regression_group = QGroupBox("Regression")
        regression_group.setStyleSheet("QGroupBox { background-color: #fff9c4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        regression_layout = QVBoxLayout()
        
        # Linear Regression
        lr_group = self.create_algorithm_group(
            "Linear Regression",
            {"fit_intercept": "checkbox"})
             #"normalize": "checkbox"}
        #)
        regression_layout.addWidget(lr_group)
        
        # Logistic Regression
        logistic_group = self.create_algorithm_group(
            "Logistic Regression",
            {"C": "double",
             "max_iter": "int",
             "multi_class": ["ovr", "multinomial"]}
        )
        regression_layout.addWidget(logistic_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        layout.setColumnStretch(0, 1)
        layout.setColumnStretch(1, 1)


        # Support Vector Regression
        svr_group = self.create_algorithm_group(
        "Support Vector Regression",
        {
            "C": "double",
            "epsilon": "double",
            "kernel": ["linear", "rbf", "poly"]
        }
        )
        regression_layout.addWidget(svr_group)

        # Regression Loss Function Selector
        loss_layout = QHBoxLayout()
        loss_label = QLabel("Loss Function:")
        self.regression_loss_combo = QComboBox()
        self.regression_loss_combo.addItems(["MSE", "MAE", "Huber"])

        loss_layout.addWidget(loss_label)
        loss_layout.addWidget(self.regression_loss_combo)
        regression_layout.addLayout(loss_layout)


        # Classification section
        classification_group = QGroupBox("Classification")
        classification_group.setStyleSheet("QGroupBox { background-color: #bbdefb; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        classification_layout = QVBoxLayout()
        
       # Naive Bayes (Özel panel)
        nb_group = QGroupBox("Naive Bayes")
        nb_layout = QVBoxLayout()

        # var_smoothing input
        smoothing_layout = QHBoxLayout()
        smoothing_layout.addWidget(QLabel("var_smoothing:"))
        smoothing_input = QDoubleSpinBox()
        smoothing_input.setRange(0.0, 1.0)
        smoothing_input.setSingleStep(0.001)
        smoothing_input.setValue(1e-9)
        smoothing_layout.addWidget(smoothing_input)
        nb_layout.addLayout(smoothing_layout)

        # Prior türü seçimi
        prior_layout = QHBoxLayout()
        prior_layout.addWidget(QLabel("Prior Type:"))
        self.nb_prior_combo = QComboBox()
        self.nb_prior_combo.addItems(["Uniform", "Custom"])
        prior_layout.addWidget(self.nb_prior_combo)
        nb_layout.addLayout(prior_layout)

        # Custom prior input
        prior_input_layout = QHBoxLayout()
        prior_input_layout.addWidget(QLabel("Custom Prior:"))
        self.nb_prior_input = QLineEdit()
        self.nb_prior_input.setPlaceholderText("[0.3, 0.7]")
        prior_input_layout.addWidget(self.nb_prior_input)
        nb_layout.addLayout(prior_input_layout)

        # Train butonu
        train_btn = QPushButton("Train Naive Bayes")
        train_btn.clicked.connect(lambda: self.train_naive_bayes(smoothing_input))
        nb_layout.addWidget(train_btn)



        nb_group.setLayout(nb_layout)
        classification_layout.addWidget(nb_group)

        
        # SVM
        svm_group = self.create_algorithm_group(
            "Support Vector Machine",
            {"C": "double",
             "kernel": ["linear", "rbf", "poly"],
             "degree": "int"}
        )
        classification_layout.addWidget(svm_group)
        
        # Decision Trees
        dt_group = self.create_algorithm_group(
            "Decision Tree",
            {"max_depth": "int",
             "min_samples_split": "int",
             "criterion": ["gini", "entropy"]}
        )
        classification_layout.addWidget(dt_group)
        
        # Random Forest
        rf_group = self.create_algorithm_group(
            "Random Forest",
            {"n_estimators": "int",
             "max_depth": "int",
             "min_samples_split": "int"}
        )
        classification_layout.addWidget(rf_group)
        
        # KNN
        knn_group = self.create_algorithm_group(
            "K-Nearest Neighbors",
            {"n_neighbors": "int",
             "weights": ["uniform", "distance"],
             "metric": ["euclidean", "manhattan"]}
        )
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)
        
        # Classification Loss Function Selector
        class_loss_layout = QHBoxLayout()
        class_loss_label = QLabel("Loss Function:")
        self.classification_loss_combo = QComboBox()
        self.classification_loss_combo.addItems(["Cross-Entropy", "Hinge"])
        class_loss_layout.addWidget(class_loss_label)
        class_loss_layout.addWidget(self.classification_loss_combo)
        classification_layout.addLayout(class_loss_layout)


        return widget
    
    def create_dim_reduction_tab(self):
        """Create the dimensionality reduction tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # K-Means section
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_layout = QVBoxLayout()
        
        kmeans_params = self.create_algorithm_group(
            "K-Means Parameters",
            {"n_clusters": "int",
             "max_iter": "int",
             "n_init": "int"}
        )
        kmeans_layout.addWidget(kmeans_params)
        
        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 0, 0)
        
        # PCA section
        pca_group = QGroupBox("Principal Component Analysis")
        pca_layout = QVBoxLayout()
        
        pca_params = self.create_algorithm_group(
            "PCA Parameters",
            {"n_components": "int",
             "whiten": "checkbox"}
        )
        pca_layout.addWidget(pca_params)
        
        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 0, 1)
        
        return widget
    
    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Environment selection
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        
        self.env_combo = QComboBox()
        self.env_combo.addItems([
            "CartPole-v1",
            "MountainCar-v0",
            "Acrobot-v1"
        ])
        env_layout.addWidget(self.env_combo)
        
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm selection
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems([
            "Q-Learning",
            "SARSA",
            "DQN"
        ])
        algo_layout.addWidget(self.rl_algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget
    
    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_group.setStyleSheet("""
            QGroupBox {
                background-color: #f8c8dc;  /* Açık pembe */
                border: 1px solid gray;
                border-radius: 5px;
                margin-top: 10px;
                padding: 10px;
            }
        """)

        viz_layout = QHBoxLayout()

        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        viz_layout.addWidget(self.canvas)

        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        self.metrics_text.setStyleSheet("""
            QTextEdit {
                background-color: #fffde7;  /* Daha yumuşak pembe */
                border: 1px solid #ccc;
            }
        """)
        viz_layout.addWidget(self.metrics_text)

        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)

    
    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)
    
    def create_algorithm_group(self, name, params):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        
        # Create parameter inputs
        param_widgets = {}
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        # Add train button
        train_btn = QPushButton(f"Train {name}")
        train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))
        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
       
    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # MLP section
        mlp_group = QGroupBox("Multi-Layer Perceptron")
        mlp_layout = QVBoxLayout()
        
        # Layer configuration
        self.layer_config = []
        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)
        
        # Training parameters
        training_params_group = self.create_training_params_group()
        mlp_layout.addWidget(training_params_group)
        
        # Train button
        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)
        
        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)
        
        # CNN section
        cnn_group = QGroupBox("Convolutional Neural Network")
        cnn_layout = QVBoxLayout()
        
        # CNN architecture controls
        cnn_controls = self.create_cnn_controls()
        cnn_layout.addWidget(cnn_controls)
        
        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)
        
        # RNN section
        rnn_group = QGroupBox("Recurrent Neural Network")
        rnn_layout = QVBoxLayout()
        
        # RNN architecture controls
        rnn_controls = self.create_rnn_controls()
        rnn_layout.addWidget(rnn_controls)
        
        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0)
        
        return widget
    
    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        # Layer type selection
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        # Parameters input
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        
        # Dynamic parameter inputs based on layer type
        self.layer_param_inputs = {}
        
        def update_params():
            # Clear existing parameter inputs
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size:")
                kernel_input = QLineEdit()
                kernel_input.setText("3, 3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()  # Initial update
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            
            # Collect parameters
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    # Handle kernel size or other tuple-like inputs
                    if param_name == "kernel_size":
                        layer_params[param_name] = tuple(map(int, widget.text().split(',')))
            
            self.layer_config.append({
                "type": layer_type,
                "params": layer_params
            })
            
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        
        dialog.exec()
    
    def create_training_params_group(self):
        """Create group for neural network training parameters"""
        group = QGroupBox("Training Parameters")
        layout = QVBoxLayout()
        
        # Batch size
        batch_layout = QHBoxLayout()
        batch_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1000)
        self.batch_size_spin.setValue(32)
        batch_layout.addWidget(self.batch_size_spin)
        layout.addLayout(batch_layout)
        
        # Epochs
        epochs_layout = QHBoxLayout()
        epochs_layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(10)
        epochs_layout.addWidget(self.epochs_spin)
        layout.addLayout(epochs_layout)
        
        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setValue(0.001)
        self.lr_spin.setSingleStep(0.001)
        lr_layout.addWidget(self.lr_spin)
        layout.addLayout(lr_layout)
        
        group.setLayout(layout)
        return group
    
    def create_cnn_controls(self):
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for CNN-specific controls
        label = QLabel("CNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def create_rnn_controls(self):
        """Create controls for Recurrent Neural Network"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for RNN-specific controls
        label = QLabel("RNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def train_neural_network(self):
        """Train the neural network with current configuration"""
        if not self.layer_config:
            self.show_error("Please add at least one layer to the network")
            return
        
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Prepare data for neural network
            if len(self.X_train.shape) == 1:
                X_train = self.X_train.reshape(-1, 1)
                X_test = self.X_test.reshape(-1, 1)
            else:
                X_train = self.X_train
                X_test = self.X_test
            
            # One-hot encode target for classification
            y_train = tf.keras.utils.to_categorical(self.y_train)
            y_test = tf.keras.utils.to_categorical(self.y_test)
            
            # Compile model
            optimizer = optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                          loss='categorical_crossentropy',
                          metrics=['accuracy'])
            
            # Train model
            history = model.fit(X_train, y_train,
                                batch_size=batch_size,
                                epochs=epochs,
                                validation_data=(X_test, y_test),
                                callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
            self.status_bar.showMessage("Neural Network Training Complete")
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
    
    def create_neural_network(self):
        """Create neural network based on current configuration"""
        model = models.Sequential()
        
        # Add layers based on configuration
        for layer_config in self.layer_config:
            layer_type = layer_config["type"]
            params = layer_config["params"]
            
            if layer_type == "Dense":
                model.add(layers.Dense(**params))
            elif layer_type == "Conv2D":
                # Add input shape for the first layer
                if len(model.layers) == 0:
                    params['input_shape'] = self.X_train.shape[1:]
                model.add(layers.Conv2D(**params))
            elif layer_type == "MaxPooling2D":
                model.add(layers.MaxPooling2D())
            elif layer_type == "Flatten":
                model.add(layers.Flatten())
            elif layer_type == "Dropout":
                model.add(layers.Dropout(**params))
        
        # Add output layer based on number of classes
        num_classes = len(np.unique(self.y_train))
        model.add(layers.Dense(num_classes, activation='softmax'))
                
        return model

   
        
    def train_neural_network(self):
        """Train the neural network"""
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Compile model
            optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                        loss='categorical_crossentropy',
                        metrics=['accuracy'])
            
            # Train model
            history = model.fit(self.X_train, self.y_train,
                              batch_size=batch_size,
                              epochs=epochs,
                              validation_data=(self.X_test, self.y_test),
                              callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
            
    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
                
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
                
        return ProgressCallback(self.progress_bar)
        
    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        
        # Create appropriate visualization based on data
        if self.y_test.dtype.kind in "fc":  # Regression
            ax = self.figure.add_subplot(111)
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()],
                   [self.y_test.min(), self.y_test.max()],
                   'r--', lw=2)
            ax.set_xlabel("Actual Values")
            ax.set_ylabel("Predicted Values")
            
        else:  # Classification
            if self.X_train.shape[1] > 2:  # Use PCA for visualization
                from sklearn.decomposition import PCA
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
                
            else:  # Direct 2D visualization
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        
        self.canvas.draw()
        
    def update_metrics(self, y_pred):
        """Update metrics display"""
        metrics_text = "Model Performance Metrics:\n\n"
        
        # Calculate appropriate metrics based on problem type
        if self.y_test.dtype.kind in "fc":  # Regression
            mse = mean_squared_error(self.y_test, y_pred)
            rmse = np.sqrt(mse)
            r2 = self.current_model.score(self.X_test, self.y_test)
            
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Root Mean Squared Error: {rmse:.4f}\n"
            metrics_text += f"R² Score: {r2:.4f}"
            
        else:  # Classification
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)
            
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        
        self.metrics_text.setText(metrics_text)
        
    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        
        # Plot training & validation accuracy
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_ylabel('Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        # Plot training & validation loss
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        
        self.figure.tight_layout()
        self.canvas.draw()
        
    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
    def train_naive_bayes(self, smoothing_input):
        try:
            var_smoothing = smoothing_input.value()
            prior_type = self.nb_prior_combo.currentText()
            
            # Prior seçimi
            if prior_type == "Uniform":
                class_prior = None
            else:
                try:
                    prior_str = self.nb_prior_input.text()
                    class_prior = eval(prior_str)
                    
                    if not isinstance(class_prior, list) or not np.isclose(sum(class_prior), 1.0):
                        raise ValueError("Prior listesi geçersiz veya toplamı 1 değil.")
                except Exception as e:
                    self.show_error(f"Custom prior hatalı: {str(e)}")
                    return
            
            model = GaussianNB(var_smoothing=var_smoothing, priors=class_prior)
            model.fit(self.X_train, self.y_train)
            y_pred = model.predict(self.X_test)
            
            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            
            self.status_bar.showMessage("Gaussian Naive Bayes modeli eğitildi.")
        
        except Exception as e:
            self.show_error(f"Naive Bayes eğitimi sırasında hata: {str(e)}")
    def compare_missing_data_methods(self):
        try:
            # Yöntemler ve skorları sakla
            methods = ["Mean Imputation", "Interpolation", "Forward Fill", "Backward Fill"]
            scores = []
            for method in methods:
                # Veriyi sıfırla ve yeniden yükle
                dataset_name = self.dataset_combo.currentText()
                if dataset_name == "Breast Cancer Dataset":
                    data = datasets.load_breast_cancer()
                elif dataset_name == "Digits Dataset":
                    data = datasets.load_digits()
                else:
                    self.show_error("Bu karşılaştırma için desteklenen veri setleri: Breast Cancer, Digits")
                    return
                
                X, y = data.data.copy(), data.target.copy()
                # Eksik veri oluştur
                rng = np.random.default_rng(42)
                mask = rng.random(X.shape) < 0.1
                X[mask] = np.nan
                # Split
                test_size = self.split_spin.value()
                X_train, X_test, y_train, y_test = model_selection.train_test_split(
                    X, y, test_size=test_size, random_state=42
                )
                if method == "Mean Imputation":
                    from sklearn.impute import SimpleImputer
                    imputer = SimpleImputer(strategy="mean")
                elif method == "Interpolation":
                    X_train = pd.DataFrame(X_train).interpolate().values
                    X_test = pd.DataFrame(X_test).interpolate().values
                    imputer = None
                elif method == "Forward Fill":
                    X_train = pd.DataFrame(X_train).fillna(method="ffill").values
                    X_test = pd.DataFrame(X_test).fillna(method="ffill").values
                    imputer = None
                elif method == "Backward Fill":
                    X_train = pd.DataFrame(X_train).fillna(method="bfill").values
                    X_test = pd.DataFrame(X_test).fillna(method="bfill").values
                    imputer = None
                if imputer:
                    X_train = imputer.fit_transform(X_train)
                    X_test = imputer.transform(X_test)
            # Model eğit
                model = LogisticRegression(max_iter=200)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                acc = accuracy_score(y_test, y_pred)
                scores.append(acc)    
        # Grafik çiz
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.bar(methods, scores)
            ax.set_title("Eksik Veri Yöntemleri vs Doğruluk")
            ax.set_ylabel("Accuracy")
            ax.set_ylim(0, 1)
            self.canvas.draw()
            self.status_bar.showMessage("Eksik veri yöntemleri başarıyla karşılaştırıldı.")
        except Exception as e:
            self.show_error(f"Karşılaştırma hatası: {str(e)}")
    def train_model(self, model_name, param_widgets):
        try:
            params = {}
            for param_name, widget in param_widgets.items():
                if isinstance(widget, QSpinBox) or isinstance(widget, QDoubleSpinBox):
                    params[param_name] = widget.value()
                elif isinstance(widget, QCheckBox):
                    params[param_name] = widget.isChecked()
                elif isinstance(widget, QComboBox):
                    params[param_name] = widget.currentText()

            if model_name == "Linear Regression":
                from sklearn.metrics import mean_absolute_error
                model = LinearRegression(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
            elif model_name == "Support Vector Regression":
                model = SVR(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    from sklearn.metrics import mean_absolute_error
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
                self.current_model = model
                self.update_metrics(y_pred)
                self.update_visualization(y_pred)
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
                
            elif model_name == "Logistic Regression":
                model = LogisticRegression(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                try:
                    if hasattr(model, "predict_proba"):
                        y_pred_proba = model.predict_proba(self.X_test)
                        loss = log_loss(self.y_test, y_pred_proba)
                        loss_type = "Cross-Entropy"
                    else:
                        raise ValueError("Model predict_proba desteği vermiyor.")
                except Exception as e:
                    self.show_error(f"Cross-Entropy hesaplanamadı: {str(e)}")
                    return
                self.current_model = model
                self.update_metrics(y_pred)
                self.update_visualization(y_pred)
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
            elif model_name == "Support Vector Machine":
                model = SVC(probability = True, **params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.classification_loss_combo.currentText()
                if loss_type == "Cross-Entropy":
                    if hasattr(model, "predict_proba"):
                        y_pred_proba = model.predict_proba(self.X_test)
                    elif hasattr(model, "decision_function"):
                        scores = model.decision_function(self.X_test)
                        y_pred_proba = np.exp(scores) / np.sum(np.exp(scores), axis=1, keepdims=True)
                    else:
                        try:
                            y_pred_proba = model.predict_proba(self.X_Test)
                        except Exception:
                            raise ValueError("Modelden olasılık alınamıyor.")
                        loss = log_loss(self.y_test, y_pred_proba)

                elif loss_type == "Hinge":
                    if hasattr(model, "decision_function"):
                        scores = model.decision_function(self.X_test)
                    else:
                        raise ValueError("Model decision_function desteği vermiyor.")
                    classes = np.unique(self.y_test)
                    y_true = label_binarize(self.y_test, classes=classes)
                    loss = hinge_loss(y_true, scores)
            else:
                self.show_error(f"Unsupported model: {model_name}")
                return
            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")
            model.fit(self.X_train, self.y_train)
            y_pred = model.predict(self.X_test)
            if np.issubdtype(self.y_test.dtype, np.floating):  # Regression
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
            else:  # Classification
                loss_type = self.classification_loss_combo.currentText()

                if loss_type == "Cross-Entropy":
                    try:
                        if hasattr(model, "predict_proba"):
                            y_pred_proba = model.predict_proba(self.X_test)
                        elif hasattr(model, "decision_function"):
                            scores = model.decision_function(self.X_test)
                            y_pred_proba = np.exp(scores) / np.sum(np.exp(scores), axis=1, keepdims=True)
                        else:
                            raise ValueError("Modelden olasılık alınamıyor.")

                        loss = log_loss(self.y_test, y_pred_proba)
                    except Exception as e:
                        self.show_error(f"Cross-Entropy hesaplanamadı: {str(e)}")
                        return

                elif loss_type == "Hinge":
                    try:
                        if hasattr(model, "decision_function"):
                            scores = model.decision_function(self.X_test)
                        else:
                            raise ValueError("Model decision_function desteği vermiyor.")

                        classes = np.unique(self.y_test)
                        y_true = label_binarize(self.y_test, classes=classes)
                        loss = hinge_loss(y_true, scores)
                    except Exception as e:
                        self.show_error(f"Hinge loss hesaplanamadı: {str(e)}")
                        return

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")

            loss_type = self.regression_loss_combo.currentText()
            if loss_type == "MSE":
                loss = mean_squared_error(self.y_test, y_pred)
            elif loss_type == "MAE":
                loss = mean_absolute_error(self.y_test, y_pred)
            elif loss_type == "Huber":
                delta = 1.0
                error = self.y_test - y_pred
                loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")
    def load_boston_housing_dataset(self):
        try:
            data_url = "http://lib.stat.cmu.edu/datasets/boston"
            raw_df = pd.read_csv(data_url, sep="\s+", skiprows=22, header=None)
            X = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, 1:]])
            y = raw_df.values[1::2, 0]

            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
            model_selection.train_test_split(X, y, test_size=test_size, random_state=42)

            self.apply_scaling()
            self.status_bar.showMessage("Loaded Boston Housing Dataset")

        except Exception as e:
            self.show_error(f"Error loading Boston Housing Dataset: {str(e)}")
def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()