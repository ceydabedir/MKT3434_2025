import sys
import numpy as np
import pandas as pd
from sklearn.metrics import silhouette_score
from sklearn.svm import SVC, SVR
from sklearn.metrics import log_loss, hinge_loss
from sklearn.preprocessing import label_binarize
from sklearn.metrics import log_loss, hinge_loss, mean_squared_error, mean_absolute_error, accuracy_score, confusion_matrix
from sklearn.preprocessing import label_binarize


from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout,
    QHBoxLayout, QTabWidget, QPushButton, QLabel,
    QComboBox, QFileDialog, QSpinBox, QDoubleSpinBox,
    QGroupBox, QScrollArea, QTextEdit, QStatusBar,
    QProgressBar, QCheckBox, QGridLayout, QMessageBox,
    QDialog, QLineEdit
)

from PyQt6.QtCore import Qt
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from sklearn import datasets, preprocessing, model_selection
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, mean_squared_error, confusion_matrix
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers

class MLCourseGUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Machine Learning Course GUI")
        self.setGeometry(100, 100, 1400, 800)
        
        # Initialize main widget and layout
        self.main_widget = QWidget()
        self.setCentralWidget(self.main_widget)
        self.layout = QVBoxLayout(self.main_widget)
        
        # Initialize data containers
        self.X_train = None
        self.X_test = None
        self.y_train = None
        self.y_test = None
        # Regression loss combo (will be added in regression panel)
        self.regression_loss_combo = None
        self.classification_loss_combo = None
        self.current_model = None
        
        # Neural network configuration
        self.layer_config = []
        
        # Create components
        self.create_data_section()
        
        
    
        self.create_tabs()
        self.create_visualization()
        self.create_status_bar()
    def load_dataset(self):
        """Load selected dataset"""
        try:
            dataset_name = self.dataset_combo.currentText()
            
            if dataset_name == "Load Custom Dataset":
                return
            
            # Load selected dataset
            if dataset_name == "Iris Dataset":
                data = datasets.load_iris()
            elif dataset_name == "Breast Cancer Dataset":
                data = datasets.load_breast_cancer()
            elif dataset_name == "Digits Dataset":
                data = datasets.load_digits()
            elif dataset_name == "Boston Housing Dataset":
                data = datasets.load_boston()
            elif dataset_name == "MNIST Dataset":
                (X_train, y_train), (X_test, y_test) = tf.keras.datasets.mnist.load_data()
                self.X_train, self.X_test = X_train, X_test
                self.y_train, self.y_test = y_train, y_test
                self.status_bar.showMessage(f"Loaded {dataset_name}")
                return
            
            # Split data
            
            test_size = self.split_spin.value()
            random_state = self.seed_spin.value() 
            shuffle = self.shuffle_checkbox.isChecked()
            
            use_stratify = self.stratified_checkbox.isChecked()
            stratify = data.target if use_stratify and len(np.unique(data.target)) < len(data.target) else None


            self.X_train, self.X_test, self.y_train, self.y_test = \
                model_selection.train_test_split(data.data, data.target,
                                                 test_size=test_size,
                                                 random_state=random_state,
                                                 shuffle=shuffle,
                                                 stratify=stratify)
            print("Train sınıf dağılımı:", np.unique(self.y_train, return_counts=True))
            print("Test sınıf dağılımı:", np.unique(self.y_test, return_counts=True))
            # Apply scaling if selected
            self.apply_scaling()
            
            self.status_bar.showMessage(f"Loaded {dataset_name}")
            
        except Exception as e:
            self.show_error(f"Error loading dataset: {str(e)}")
    
    def load_custom_data(self):
        """Load custom dataset from CSV file"""
        try:
            file_name, _ = QFileDialog.getOpenFileName(
                self,
                "Load Dataset",
                "",
                "CSV files (*.csv)"
            )
            
            if file_name:
                # Load data
                data = pd.read_csv(file_name)
                
                # Ask user to select target column
                target_col = self.select_target_column(data.columns)
                
                if target_col:
                    X = data.drop(target_col, axis=1)
                    y = data[target_col]
                if pd.api.types.is_numeric_dtype(y):
                    unique_values = y.nunique()
                    if unique_values > 10:
                        msg = QMessageBox.question(
                            self,
                            "Sınıf Dönüştürme",
                            f"Hedef sütunu sürekli sayısal ({unique_values} farklı değer var).\n"
                            "Bunu sınıflandırma için otomatik olarak 2 sınıfa çevirmek ister misiniz?",
                            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
                        if msg == QMessageBox.StandardButton.Yes:
                            median = y.median()
                            y = (y > median).astype(int)  # medyan üstü = 1, altı = 0
                            self.status_bar.showMessage("Hedef sütunu sınıflara dönüştürüldü (otomatik).")
                    # Split data
                    test_size = self.split_spin.value()
                    random_state = self.seed_spin.value()
                    shuffle = self.shuffle_checkbox.isChecked()
                
                    stratify = y if self.stratified_checkbox.isChecked() else None
                    (self.X_train, self.X_test, self.y_train, self.y_test) =  model_selection.train_test_split(      
                        X, y,
                        test_size=test_size,
                        random_state=random_state,
                        shuffle=shuffle,
                        stratify=y if self.stratified_checkbox.isChecked() else None)
                    print("Train sınıf dağılımı:", np.unique(self.y_train, return_counts=True))
                    print("Test sınıf dağılımı:", np.unique(self.y_test, return_counts=True))
                    # Apply scaling if selected
                    self.apply_scaling()
                    
                    self.status_bar.showMessage(f"Loaded custom dataset: {file_name}")
                    
        except Exception as e:
            self.show_error(f"Error loading custom dataset: {str(e)}")
    
    def select_target_column(self, columns):
        """Dialog to select target column from dataset"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Target Column")
        layout = QVBoxLayout(dialog)
        
        combo = QComboBox()
        combo.addItems(columns)
        layout.addWidget(combo)
        
        btn = QPushButton("Select")
        btn.clicked.connect(dialog.accept)
        layout.addWidget(btn)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            return combo.currentText()
        return None
    
    def apply_scaling(self):
        """Apply selected scaling method to the data"""
        scaling_method = self.scaling_combo.currentText()
        
        if scaling_method != "No Scaling":
            try:
                if scaling_method == "Standard Scaling":
                    scaler = preprocessing.StandardScaler()
                elif scaling_method == "Min-Max Scaling":
                    scaler = preprocessing.MinMaxScaler()
                elif scaling_method == "Robust Scaling":
                    scaler = preprocessing.RobustScaler()
                
                self.X_train = scaler.fit_transform(self.X_train)
                self.X_test = scaler.transform(self.X_test)
                
            except Exception as e:
                self.show_error(f"Error applying scaling: {str(e)}")
    def apply_missing_value_handling(self):
        """Uygun eksik veri doldurma yöntemini uygula"""
        method = self.missing_value_combo.currentText()

        try:
            if method == "No Fill":
                return

            if method == "Mean Imputation":
                from sklearn.impute import SimpleImputer
                imputer = SimpleImputer(strategy="mean")
                self.X_train = imputer.fit_transform(self.X_train)
                self.X_test = imputer.transform(self.X_test)

            elif method == "Interpolation":
                self.X_train = pd.DataFrame(self.X_train).interpolate().values
                self.X_test = pd.DataFrame(self.X_test).interpolate().values

            elif method == "Forward Fill":
                self.X_train = pd.DataFrame(self.X_train).fillna(method="ffill").values
                self.X_test = pd.DataFrame(self.X_test).fillna(method="ffill").values

            elif method == "Backward Fill":
                self.X_train = pd.DataFrame(self.X_train).fillna(method="bfill").values
                self.X_test = pd.DataFrame(self.X_test).fillna(method="bfill").values

            self.status_bar.showMessage(f"Applied missing value method: {method}")

        except Exception as e:
            self.show_error(f"Error handling missing values: {str(e)}")

    def create_data_section(self):
        """Create the data loading and preprocessing section"""
        data_group = QGroupBox("Data Management")
        data_group.setStyleSheet("QGroupBox { background-color: #f8c8dc; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        data_layout = QVBoxLayout()

        row1 = QHBoxLayout()
        row2 = QHBoxLayout()

        # Dataset
        self.dataset_combo = QComboBox()
        self.dataset_combo.addItems([
            "Load Custom Dataset", "Iris Dataset", "Breast Cancer Dataset",
            "Digits Dataset", "Boston Housing Dataset", "MNIST Dataset"
        ])
        self.dataset_combo.setFixedWidth(140)
        self.dataset_combo.currentIndexChanged.connect(self.load_dataset)

        self.load_btn = QPushButton("Load Data")
        self.load_btn.setFixedWidth(90)
        self.load_btn.clicked.connect(self.load_custom_data)

        self.scaling_combo = QComboBox()
        self.scaling_combo.addItems(["No Scaling", "Standard Scaling", "Min-Max Scaling", "Robust Scaling"])
        self.scaling_combo.setFixedWidth(110)

        self.scaling_combo.setEditable(True)
        self.scaling_combo.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scaling_combo.setEditable(False)

        self.missing_value_combo = QComboBox()
        self.missing_value_combo.addItems(["No Fill", "Mean Imputation", "Interpolation", "Forward Fill", "Backward Fill"])
        self.missing_value_combo.setFixedWidth(100)

        self.missing_value_combo.setEditable(True)
        self.missing_value_combo.lineEdit().setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.missing_value_combo.setEditable(False)

        self.compare_btn = QPushButton("Compare Missing Data Methods")
        self.compare_btn.setFixedWidth(200)
        self.compare_btn.clicked.connect(self.compare_missing_data_methods)

        # Test split and seed
        self.split_spin = QDoubleSpinBox()
        self.split_spin.setRange(0.1, 0.9)
        self.split_spin.setSingleStep(0.05)
        self.split_spin.setValue(0.2)
        self.split_spin.setFixedWidth(70)

        self.shuffle_checkbox = QCheckBox("Shuffle")
        self.shuffle_checkbox.setChecked(True)

        self.seed_spin = QSpinBox()
        self.seed_spin.setRange(0, 9999)
        self.seed_spin.setValue(42)
        self.seed_spin.setFixedWidth(60)

        # Row 1
        row1.addWidget(QLabel("Dataset:"))
        row1.addWidget(self.dataset_combo)
        row1.addWidget(self.load_btn)
        row1.addWidget(QLabel("Scaling:"))
        row1.addWidget(self.scaling_combo)
        row1.addWidget(QLabel("Missing Values:"))
        row1.addWidget(self.missing_value_combo)
        row1.addWidget(self.compare_btn)
        row1.addWidget(QLabel("Test Split:"))
        row1.addWidget(self.split_spin)
        row1.addWidget(self.shuffle_checkbox)
        row1.addWidget(QLabel("Seed:"))
        row1.addWidget(self.seed_spin)
        row1.addStretch()

        self.stratified_checkbox = QCheckBox("Use Stratified Split (Classification Only)")

        # Yeni cross-validation bileşenleri (2. satıra ekliyoruz!)
        self.use_cv_checkbox = QCheckBox("Use Cross-Validation")
        self.use_cv_checkbox.setChecked(False)

        self.cv_train_ratio = QSpinBox()
        self.cv_train_ratio.setRange(10, 90)
        self.cv_train_ratio.setValue(70)
        self.cv_train_ratio.setSuffix("%")
        self.cv_train_ratio.setFixedWidth(70)

        self.cv_val_ratio = QSpinBox()
        self.cv_val_ratio.setRange(0, 40)
        self.cv_val_ratio.setValue(15)
        self.cv_val_ratio.setSuffix("%")
        self.cv_val_ratio.setFixedWidth(70)

        self.cv_test_ratio = QSpinBox()
        self.cv_test_ratio.setRange(10, 90)
        self.cv_test_ratio.setValue(15)
        self.cv_test_ratio.setSuffix("%")
        self.cv_test_ratio.setFixedWidth(70)

        self.kfold_checkbox = QCheckBox("Use K-Fold Cross-Validation")
        self.kfold_spin = QSpinBox()
        self.kfold_spin.setRange(2, 20)
        self.kfold_spin.setValue(5)


        # ✅ 2. satıra ekliyoruz
        row2.addWidget(self.use_cv_checkbox)
        row2.addWidget(QLabel("Train:"))
        row2.addWidget(self.cv_train_ratio)
        row2.addWidget(QLabel("Val:"))
        row2.addWidget(self.cv_val_ratio)
        row2.addWidget(QLabel("Test:"))
        row2.addWidget(self.cv_test_ratio)
        row2.addWidget(self.kfold_checkbox)
        row2.addWidget(QLabel("K:"))
        row2.addWidget(self.kfold_spin)
        row2.addStretch()

        self.kfold_spin.setEnabled(False)  # başlangıçta kapalı
        self.kfold_checkbox.stateChanged.connect(self.toggle_kfold_spin)

        self.use_cv_checkbox.stateChanged.connect(self.toggle_cv_spinboxes)
        self.cv_train_ratio.valueChanged.connect(self.validate_split_sum)
        self.cv_val_ratio.valueChanged.connect(self.validate_split_sum)
        self.cv_test_ratio.valueChanged.connect(self.validate_split_sum)

        self.cv_train_ratio.setEnabled(False)
        self.cv_val_ratio.setEnabled(False)
        self.cv_test_ratio.setEnabled(False)
        
        data_layout.addLayout(row1)
        data_layout.addLayout(row2)
        data_group.setLayout(data_layout)
        self.layout.addWidget(data_group)

    def toggle_kfold_spin(self, state):
        enabled = (state == Qt.CheckState.Checked.value)
        self.kfold_spin.setEnabled(enabled)


    def toggle_cv_spinboxes(self, state):
        print(f"Checkbox durumu: {state}")
        enabled = (state == Qt.CheckState.Checked.value)
        self.cv_train_ratio.setEnabled(enabled)
        print(f"enabled: {enabled}")
        self.cv_val_ratio.setEnabled(enabled)
        self.cv_test_ratio.setEnabled(enabled)


    def validate_split_sum(self):
        total = self.cv_train_ratio.value() + self.cv_val_ratio.value() + self.cv_test_ratio.value()
        if total > 100:
            QMessageBox.warning(self, "Invalid Split", "Total split percentage cannot exceed 100%.")

    
    def create_tabs(self):
        """Create tabs for different ML topics"""
        self.tab_widget = QTabWidget()
        
        # Create individual tabs
        tabs = [
            ("Classical ML", self.create_classical_ml_tab),
            ("Deep Learning", self.create_deep_learning_tab),
            ("Dimensionality Reduction", self.create_dim_reduction_tab),
            ("Reinforcement Learning", self.create_rl_tab)
        ]
        
        for tab_name, create_func in tabs:
            scroll = QScrollArea()
            tab_widget = create_func()
            scroll.setWidget(tab_widget)
            scroll.setWidgetResizable(True)
            self.tab_widget.addTab(scroll, tab_name)
        
        self.layout.addWidget(self.tab_widget)
    
    def create_classical_ml_tab(self):
        """Create the classical machine learning algorithms tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Regression section
        regression_group = QGroupBox("Regression")
        regression_group.setStyleSheet("QGroupBox { background-color: #fff9c4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        regression_layout = QVBoxLayout()
        
        # Linear Regression
        lr_group = self.create_algorithm_group(
            "Linear Regression",
            {"fit_intercept": "checkbox"})
             #"normalize": "checkbox"}
        #)
        regression_layout.addWidget(lr_group)
        
        # Logistic Regression
        logistic_group = self.create_algorithm_group(
            "Logistic Regression",
            {"C": "double",
             "max_iter": "int",
             "multi_class": ["ovr", "multinomial"]}
        )
        regression_layout.addWidget(logistic_group)
        
        regression_group.setLayout(regression_layout)
        layout.addWidget(regression_group, 0, 0)
        layout.setColumnStretch(0, 1)
        layout.setColumnStretch(1, 1)


        # Support Vector Regression
        svr_group = self.create_algorithm_group(
        "Support Vector Regression",
        {
            "C": "double",
            "epsilon": "double",
            "kernel": ["linear", "rbf", "poly"]
        }
        )
        regression_layout.addWidget(svr_group)

        # Regression Loss Function Selector
        loss_layout = QHBoxLayout()
        loss_label = QLabel("Loss Function:")
        self.regression_loss_combo = QComboBox()
        self.regression_loss_combo.addItems(["MSE", "MAE", "Huber"])

        loss_layout.addWidget(loss_label)
        loss_layout.addWidget(self.regression_loss_combo)
        regression_layout.addLayout(loss_layout)


        # Classification section
        classification_group = QGroupBox("Classification")
        classification_group.setStyleSheet("QGroupBox { background-color: #bbdefb; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        classification_layout = QVBoxLayout()

        self.stratified_checkbox = QCheckBox("Use Stratified Split")
        classification_layout.addWidget(self.stratified_checkbox)
        
       # Naive Bayes (Özel panel)
        nb_group = QGroupBox("Naive Bayes")
        nb_layout = QVBoxLayout()

        # var_smoothing input
        smoothing_layout = QHBoxLayout()
        smoothing_layout.addWidget(QLabel("var_smoothing:"))
        smoothing_input = QDoubleSpinBox()
        smoothing_input.setRange(0.0, 1.0)
        smoothing_input.setSingleStep(0.001)
        smoothing_input.setValue(1e-9)
        smoothing_layout.addWidget(smoothing_input)
        nb_layout.addLayout(smoothing_layout)

        # Prior türü seçimi
        prior_layout = QHBoxLayout()
        prior_layout.addWidget(QLabel("Prior Type:"))
        self.nb_prior_combo = QComboBox()
        self.nb_prior_combo.addItems(["Uniform", "Custom"])
        prior_layout.addWidget(self.nb_prior_combo)
        nb_layout.addLayout(prior_layout)

        # Custom prior input
        prior_input_layout = QHBoxLayout()
        prior_input_layout.addWidget(QLabel("Custom Prior:"))
        self.nb_prior_input = QLineEdit()
        self.nb_prior_input.setPlaceholderText("[0.3, 0.7]")
        prior_input_layout.addWidget(self.nb_prior_input)
        nb_layout.addLayout(prior_input_layout)

        # Train butonu
        train_btn = QPushButton("Train Naive Bayes")
        train_btn.clicked.connect(lambda: self.train_naive_bayes(smoothing_input))
        nb_layout.addWidget(train_btn)



        nb_group.setLayout(nb_layout)
        classification_layout.addWidget(nb_group)

        
        # SVM
        svm_group = self.create_algorithm_group(
            "Support Vector Machine",
            {"C": "double",
             "kernel": ["linear", "rbf", "poly"],
             "degree": "int"}
        )
        classification_layout.addWidget(svm_group)
        
        # Decision Trees
        dt_group = self.create_algorithm_group(
            "Decision Tree",
            {"max_depth": "int",
             "min_samples_split": "int",
             "criterion": ["gini", "entropy"]}
        )
        classification_layout.addWidget(dt_group)
        
        # Random Forest
        rf_group = self.create_algorithm_group(
            "Random Forest",
            {"n_estimators": "int",
             "max_depth": "int",
             "min_samples_split": "int"}
        )
        classification_layout.addWidget(rf_group)
        
        # KNN
        knn_group = self.create_algorithm_group(
            "K-Nearest Neighbors",
            {"n_neighbors": "int",
             "weights": ["uniform", "distance"],
             "metric": ["euclidean", "manhattan"]}
        )
        classification_layout.addWidget(knn_group)
        
        classification_group.setLayout(classification_layout)
        layout.addWidget(classification_group, 0, 1)

        # Classification Loss Function Selector
        class_loss_layout = QHBoxLayout()
        class_loss_label = QLabel("Loss Function:")
        self.classification_loss_combo = QComboBox()
        self.classification_loss_combo.addItems(["Cross-Entropy", "Hinge"])
        class_loss_layout.addWidget(class_loss_label)
        class_loss_layout.addWidget(self.classification_loss_combo)
        classification_layout.addLayout(class_loss_layout)


        return widget
    
    def create_dim_reduction_tab(self):
        widget = QWidget()
        layout = QGridLayout(widget)
        print("[create_dim_reduction_tab] Tab oluşturuluyor...")
        
        # K-Means paneli
        kmeans_group = QGroupBox("K-Means Clustering")
        kmeans_group.setStyleSheet("QGroupBox { background-color: #E0BBE4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        kmeans_layout = QVBoxLayout()

        # n_clusters
        n_clusters_layout = QHBoxLayout()
        n_clusters_layout.addWidget(QLabel("n_clusters:"))
        self.kmeans_n_clusters = QSpinBox()
        self.kmeans_n_clusters.setRange(1, 20)
        self.kmeans_n_clusters.setValue(3)
        n_clusters_layout.addWidget(self.kmeans_n_clusters)
        kmeans_layout.addLayout(n_clusters_layout)

        # max_iter
        max_iter_layout = QHBoxLayout()
        max_iter_layout.addWidget(QLabel("max_iter:"))
        self.kmeans_max_iter = QSpinBox()
        self.kmeans_max_iter.setRange(1, 1000)
        self.kmeans_max_iter.setValue(300)
        max_iter_layout.addWidget(self.kmeans_max_iter)
        kmeans_layout.addLayout(max_iter_layout)

        # n_init
        n_init_layout = QHBoxLayout()
        n_init_layout.addWidget(QLabel("n_init:"))
        self.kmeans_n_init = QSpinBox()
        self.kmeans_n_init.setRange(1, 100)
        self.kmeans_n_init.setValue(10)
        n_init_layout.addWidget(self.kmeans_n_init)
        kmeans_layout.addLayout(n_init_layout)

        # Train button
        kmeans_train_btn = QPushButton("Train K-Means")
        kmeans_train_btn.clicked.connect(self.train_kmeans)
        kmeans_layout.addWidget(kmeans_train_btn)

        # Elbow Method button
        elbow_btn = QPushButton("Plot Elbow Method (K-Means)")
        elbow_btn.clicked.connect(self.plot_elbow_method)
        kmeans_layout.addWidget(elbow_btn)

        # Hepsini gruba ekle
        kmeans_group.setLayout(kmeans_layout)
        layout.addWidget(kmeans_group, 0, 0)


        # PCA section
        pca_group = QGroupBox("Principal Component Analysis")
        pca_group.setStyleSheet("QGroupBox { background-color: #BFEFFF; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        pca_layout = QVBoxLayout()
        pca_layout.setSpacing(1)  # veya 0 yaparsan tamamen bitişik olur
        

        # n_components
        pca_param_layout = QHBoxLayout()
        pca_param_layout.addWidget(QLabel("n_components:"))
        self.pca_components_spin = QSpinBox()
        self.pca_components_spin.setRange(1, 10)
        self.pca_components_spin.setValue(2)
        pca_param_layout.addWidget(self.pca_components_spin)
        pca_layout.addLayout(pca_param_layout)

        # whiten
        whiten_layout = QHBoxLayout()
        whiten_layout.addWidget(QLabel("whiten:"))
        self.pca_whiten_checkbox = QCheckBox()
        whiten_layout.addWidget(self.pca_whiten_checkbox)
        pca_layout.addLayout(whiten_layout)

        # Projection Type (2D/3D) seçimi
        proj_layout = QHBoxLayout()
        proj_layout.addWidget(QLabel("Projection:"))
        self.pca_proj_combo = QComboBox()
        self.pca_proj_combo.addItems(["2D", "3D"])
        proj_layout.addWidget(self.pca_proj_combo)
        pca_layout.addLayout(proj_layout)

        # Train button
        pca_btn = QPushButton("Train PCA Parameters")
        pca_btn.clicked.connect(self.train_pca)
        pca_layout.addWidget(pca_btn)

        # Manual Covariance Entry Button
        manual_cov_btn = QPushButton("Manual Covariance Entry")
        manual_cov_btn.clicked.connect(self.open_covariance_dialog)
        pca_layout.addWidget(manual_cov_btn)


        pca_group.setLayout(pca_layout)
        layout.addWidget(pca_group, 0, 1)


        # --- LDA Section (YENİ EKLENEN KISIM) --- #
        lda_group = QGroupBox("Linear Discriminant Analysis")
        lda_group.setStyleSheet("QGroupBox { background-color: #BFEFFF; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        lda_layout = QVBoxLayout()

        lda_param_layout = QHBoxLayout()
        lda_param_layout.addWidget(QLabel("n_components:"))
        self.lda_components_spin = QSpinBox()
        self.lda_components_spin.setRange(1, 10)
        self.lda_components_spin.setValue(2)
        lda_param_layout.addWidget(self.lda_components_spin)
        lda_layout.addLayout(lda_param_layout)

        lda_btn = QPushButton("Train LDA")
        lda_btn.clicked.connect(self.train_lda)
        lda_layout.addWidget(lda_btn)

        lda_group.setLayout(lda_layout)
        layout.addWidget(lda_group, 1, 0)

            # --- t-SNE Section (YENİ EKLENEN KISIM) --- #
        tsne_group = QGroupBox("t-SNE")
        tsne_group.setStyleSheet("QGroupBox { background-color: #E0BBE4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        tsne_layout = QVBoxLayout()

        # Perplexity
        perplexity_layout = QHBoxLayout()
        perplexity_layout.addWidget(QLabel("Perplexity:"))
        self.tsne_perplexity = QDoubleSpinBox()
        self.tsne_perplexity.setRange(1.0, 100.0)
        self.tsne_perplexity.setValue(30)
        perplexity_layout.addWidget(self.tsne_perplexity)
        tsne_layout.addLayout(perplexity_layout)

        # Iterations
        iter_layout = QHBoxLayout()
        iter_layout.addWidget(QLabel("n_iter:"))
        self.tsne_iter = QSpinBox()
        self.tsne_iter.setRange(250, 5000)
        self.tsne_iter.setValue(1000)
        iter_layout.addWidget(self.tsne_iter)
        tsne_layout.addLayout(iter_layout)

        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.tsne_lr = QDoubleSpinBox()
        self.tsne_lr.setRange(10.0, 1000.0)
        self.tsne_lr.setValue(250)
        lr_layout.addWidget(self.tsne_lr)
        tsne_layout.addLayout(lr_layout)

        # Projection Type (2D/3D) seçimi
        proj_layout = QHBoxLayout()
        proj_layout.addWidget(QLabel("Projection:"))
        self.tsne_proj_combo = QComboBox()
        self.tsne_proj_combo.addItems(["2D", "3D"])
        proj_layout.addWidget(self.tsne_proj_combo)
        tsne_layout.addLayout(proj_layout)

        # Train button
        tsne_btn = QPushButton("Train t-SNE")
        tsne_btn.clicked.connect(self.train_tsne)
        tsne_layout.addWidget(tsne_btn)

        tsne_group.setLayout(tsne_layout)
        layout.addWidget(tsne_group, 1, 1)

        # --- UMAP Section --- #
        umap_group = QGroupBox("UMAP")
        umap_group.setStyleSheet("QGroupBox { background-color: #E0BBE4; border: 1px solid gray; border-radius: 5px; margin-top: 10px; padding: 10px; }")
        umap_layout = QVBoxLayout()

        # n_neighbors
        neighbors_layout = QHBoxLayout()
        neighbors_layout.addWidget(QLabel("n_neighbors:"))
        self.umap_neighbors = QSpinBox()
        self.umap_neighbors.setRange(2, 100)
        self.umap_neighbors.setValue(15)
        neighbors_layout.addWidget(self.umap_neighbors)
        umap_layout.addLayout(neighbors_layout)

        # min_dist
        min_dist_layout = QHBoxLayout()
        min_dist_layout.addWidget(QLabel("min_dist:"))
        self.umap_min_dist = QDoubleSpinBox()
        self.umap_min_dist.setRange(0.0, 1.0)
        self.umap_min_dist.setSingleStep(0.05)
        self.umap_min_dist.setValue(0.1)
        min_dist_layout.addWidget(self.umap_min_dist)
        umap_layout.addLayout(min_dist_layout)

        # metric seçimi
        metric_layout = QHBoxLayout()
        metric_layout.addWidget(QLabel("Metric:"))
        self.umap_metric_combo = QComboBox()
        self.umap_metric_combo.addItems(["euclidean", "manhattan", "cosine", "correlation"])
        metric_layout.addWidget(self.umap_metric_combo)
        umap_layout.addLayout(metric_layout)


        # Projection Type (2D/3D) seçimi
        proj_layout = QHBoxLayout()
        proj_layout.addWidget(QLabel("Projection:"))
        self.umap_proj_combo = QComboBox()
        self.umap_proj_combo.addItems(["2D", "3D"])
        proj_layout.addWidget(self.umap_proj_combo)
        umap_layout.addLayout(proj_layout)

        # Train button
        umap_btn = QPushButton("Train UMAP")
        umap_btn.clicked.connect(self.train_umap)
        umap_layout.addWidget(umap_btn)

        umap_group.setLayout(umap_layout)
        layout.addWidget(umap_group, 2, 0)


        widget.setLayout(layout)
        return widget

    
    def create_rl_tab(self):
        """Create the reinforcement learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # Environment selection
        env_group = QGroupBox("Environment")
        env_layout = QVBoxLayout()
        
        self.env_combo = QComboBox()
        self.env_combo.addItems([
            "CartPole-v1",
            "MountainCar-v0",
            "Acrobot-v1"
        ])
        env_layout.addWidget(self.env_combo)
        
        env_group.setLayout(env_layout)
        layout.addWidget(env_group, 0, 0)
        
        # RL Algorithm selection
        algo_group = QGroupBox("RL Algorithm")
        algo_layout = QVBoxLayout()
        
        self.rl_algo_combo = QComboBox()
        self.rl_algo_combo.addItems([
            "Q-Learning",
            "SARSA",
            "DQN"
        ])
        algo_layout.addWidget(self.rl_algo_combo)
        
        algo_group.setLayout(algo_layout)
        layout.addWidget(algo_group, 0, 1)
        
        return widget
    
    def create_visualization(self):
        """Create the visualization section"""
        viz_group = QGroupBox("Visualization")
        viz_group.setStyleSheet("""
            QGroupBox {
                background-color: #f8c8dc;  /* Açık pembe */
                border: 1px solid gray;
                border-radius: 5px;
                margin-top: 10px;
                padding: 10px;
            }
        """)

        viz_layout = QHBoxLayout()

        # Create matplotlib figure
        self.figure = Figure(figsize=(8, 6))
        self.canvas = FigureCanvas(self.figure)
        

        # Metrics display
        self.metrics_text = QTextEdit()
        self.metrics_text.setReadOnly(True)
        self.metrics_text.setStyleSheet("""
            QTextEdit {
                background-color: #fffde7;  /* Daha yumuşak pembe */
                border: 1px solid #ccc;
            }
        """)

        viz_layout.addWidget(self.canvas, 1)
        viz_layout.addWidget(self.metrics_text, 1)

        viz_group.setLayout(viz_layout)
        self.layout.addWidget(viz_group)

    
    def create_status_bar(self):
        """Create the status bar"""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        # Add progress bar
        self.progress_bar = QProgressBar()
        self.status_bar.addPermanentWidget(self.progress_bar)
    
    def create_algorithm_group(self, name, params):
        """Helper method to create algorithm parameter groups"""
        group = QGroupBox(name)
        layout = QVBoxLayout()
        
        # Create parameter inputs
        param_widgets = {}
        for param_name, param_type in params.items():
            param_layout = QHBoxLayout()
            param_layout.addWidget(QLabel(f"{param_name}:"))
            
            if param_type == "int":
                widget = QSpinBox()
                widget.setRange(1, 1000)
            elif param_type == "double":
                widget = QDoubleSpinBox()
                widget.setRange(0.0001, 1000.0)
                widget.setSingleStep(0.1)
            elif param_type == "checkbox":
                widget = QCheckBox()
            elif isinstance(param_type, list):
                widget = QComboBox()
                widget.addItems(param_type)
            
            param_layout.addWidget(widget)
            param_widgets[param_name] = widget
            layout.addLayout(param_layout)
        
        # Add train button
        train_btn = QPushButton(f"Train {name}")
        if name == "PCA Parameters":
            train_btn.clicked.connect(self.train_pca)
        else:
            train_btn.clicked.connect(lambda: self.train_model(name, param_widgets))

        layout.addWidget(train_btn)
        
        group.setLayout(layout)
        return group

    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
       
    def create_deep_learning_tab(self):
        """Create the deep learning tab"""
        widget = QWidget()
        layout = QGridLayout(widget)
        
        # MLP section
        mlp_group = QGroupBox("Multi-Layer Perceptron")
        mlp_layout = QVBoxLayout()
        
        # Layer configuration
        self.layer_config = []
        layer_btn = QPushButton("Add Layer")
        layer_btn.clicked.connect(self.add_layer_dialog)
        mlp_layout.addWidget(layer_btn)
        
        # Training parameters
        training_params_group = self.create_training_params_group()
        mlp_layout.addWidget(training_params_group)
        
        # Train button
        train_btn = QPushButton("Train Neural Network")
        train_btn.clicked.connect(self.train_neural_network)
        mlp_layout.addWidget(train_btn)
        
        mlp_group.setLayout(mlp_layout)
        layout.addWidget(mlp_group, 0, 0)
        
        # CNN section
        cnn_group = QGroupBox("Convolutional Neural Network")
        cnn_layout = QVBoxLayout()
        
        # CNN architecture controls
        cnn_controls = self.create_cnn_controls()
        cnn_layout.addWidget(cnn_controls)
        
        cnn_group.setLayout(cnn_layout)
        layout.addWidget(cnn_group, 0, 1)
        
        # RNN section
        rnn_group = QGroupBox("Recurrent Neural Network")
        rnn_layout = QVBoxLayout()
        
        # RNN architecture controls
        rnn_controls = self.create_rnn_controls()
        rnn_layout.addWidget(rnn_controls)
        
        rnn_group.setLayout(rnn_layout)
        layout.addWidget(rnn_group, 1, 0)
        
        return widget
    
    def add_layer_dialog(self):
        """Open a dialog to add a neural network layer"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Add Neural Network Layer")
        layout = QVBoxLayout(dialog)
        
        # Layer type selection
        type_layout = QHBoxLayout()
        type_label = QLabel("Layer Type:")
        type_combo = QComboBox()
        type_combo.addItems(["Dense", "Conv2D", "MaxPooling2D", "Flatten", "Dropout"])
        type_layout.addWidget(type_label)
        type_layout.addWidget(type_combo)
        layout.addLayout(type_layout)
        
        # Parameters input
        params_group = QGroupBox("Layer Parameters")
        params_layout = QVBoxLayout()
        
        # Dynamic parameter inputs based on layer type
        self.layer_param_inputs = {}
        
        def update_params():
            # Clear existing parameter inputs
            for widget in list(self.layer_param_inputs.values()):
                params_layout.removeWidget(widget)
                widget.deleteLater()
            self.layer_param_inputs.clear()
            
            layer_type = type_combo.currentText()
            if layer_type == "Dense":
                units_label = QLabel("Units:")
                units_input = QSpinBox()
                units_input.setRange(1, 1000)
                units_input.setValue(32)
                self.layer_param_inputs["units"] = units_input
                
                activation_label = QLabel("Activation:")
                activation_combo = QComboBox()
                activation_combo.addItems(["relu", "sigmoid", "tanh", "softmax"])
                self.layer_param_inputs["activation"] = activation_combo
                
                params_layout.addWidget(units_label)
                params_layout.addWidget(units_input)
                params_layout.addWidget(activation_label)
                params_layout.addWidget(activation_combo)
            
            elif layer_type == "Conv2D":
                filters_label = QLabel("Filters:")
                filters_input = QSpinBox()
                filters_input.setRange(1, 1000)
                filters_input.setValue(32)
                self.layer_param_inputs["filters"] = filters_input
                
                kernel_label = QLabel("Kernel Size:")
                kernel_input = QLineEdit()
                kernel_input.setText("3, 3")
                self.layer_param_inputs["kernel_size"] = kernel_input
                
                params_layout.addWidget(filters_label)
                params_layout.addWidget(filters_input)
                params_layout.addWidget(kernel_label)
                params_layout.addWidget(kernel_input)
            
            elif layer_type == "Dropout":
                rate_label = QLabel("Dropout Rate:")
                rate_input = QDoubleSpinBox()
                rate_input.setRange(0.0, 1.0)
                rate_input.setValue(0.5)
                rate_input.setSingleStep(0.1)
                self.layer_param_inputs["rate"] = rate_input
                
                params_layout.addWidget(rate_label)
                params_layout.addWidget(rate_input)
        
        type_combo.currentIndexChanged.connect(update_params)
        update_params()  # Initial update
        
        params_group.setLayout(params_layout)
        layout.addWidget(params_group)
        
        # Buttons
        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Add Layer")
        cancel_btn = QPushButton("Cancel")
        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)
        
        def add_layer():
            layer_type = type_combo.currentText()
            
            # Collect parameters
            layer_params = {}
            for param_name, widget in self.layer_param_inputs.items():
                if isinstance(widget, QSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QDoubleSpinBox):
                    layer_params[param_name] = widget.value()
                elif isinstance(widget, QComboBox):
                    layer_params[param_name] = widget.currentText()
                elif isinstance(widget, QLineEdit):
                    # Handle kernel size or other tuple-like inputs
                    if param_name == "kernel_size":
                        layer_params[param_name] = tuple(map(int, widget.text().split(',')))
            
            self.layer_config.append({
                "type": layer_type,
                "params": layer_params
            })
            
            dialog.accept()
        
        add_btn.clicked.connect(add_layer)
        cancel_btn.clicked.connect(dialog.reject)
        
        dialog.exec()
    
    def create_training_params_group(self):
        """Create group for neural network training parameters"""
        group = QGroupBox("Training Parameters")
        layout = QVBoxLayout()
        
        # Batch size
        batch_layout = QHBoxLayout()
        batch_layout.addWidget(QLabel("Batch Size:"))
        self.batch_size_spin = QSpinBox()
        self.batch_size_spin.setRange(1, 1000)
        self.batch_size_spin.setValue(32)
        batch_layout.addWidget(self.batch_size_spin)
        layout.addLayout(batch_layout)
        
        # Epochs
        epochs_layout = QHBoxLayout()
        epochs_layout.addWidget(QLabel("Epochs:"))
        self.epochs_spin = QSpinBox()
        self.epochs_spin.setRange(1, 1000)
        self.epochs_spin.setValue(10)
        epochs_layout.addWidget(self.epochs_spin)
        layout.addLayout(epochs_layout)
        
        # Learning rate
        lr_layout = QHBoxLayout()
        lr_layout.addWidget(QLabel("Learning Rate:"))
        self.lr_spin = QDoubleSpinBox()
        self.lr_spin.setRange(0.0001, 1.0)
        self.lr_spin.setValue(0.001)
        self.lr_spin.setSingleStep(0.001)
        lr_layout.addWidget(self.lr_spin)
        layout.addLayout(lr_layout)
        
        group.setLayout(layout)
        return group
    
    def create_cnn_controls(self):
        """Create controls for Convolutional Neural Network"""
        group = QGroupBox("CNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for CNN-specific controls
        label = QLabel("CNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def create_rnn_controls(self):
        """Create controls for Recurrent Neural Network"""
        group = QGroupBox("RNN Architecture")
        layout = QVBoxLayout()
        
        # Placeholder for RNN-specific controls
        label = QLabel("RNN Controls (To be implemented)")
        layout.addWidget(label)
        
        group.setLayout(layout)
        return group
    
    def train_neural_network(self):
        """Train the neural network with current configuration"""
        if not self.layer_config:
            self.show_error("Please add at least one layer to the network")
            return
        
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Prepare data for neural network
            if len(self.X_train.shape) == 1:
                X_train = self.X_train.reshape(-1, 1)
                X_test = self.X_test.reshape(-1, 1)
            else:
                X_train = self.X_train
                X_test = self.X_test
            
            # One-hot encode target for classification
            y_train = tf.keras.utils.to_categorical(self.y_train)
            y_test = tf.keras.utils.to_categorical(self.y_test)
            
            # Compile model
            optimizer = optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                          loss='categorical_crossentropy',
                          metrics=['accuracy'])
            
            # Train model
            history = model.fit(X_train, y_train,
                                batch_size=batch_size,
                                epochs=epochs,
                                validation_data=(X_test, y_test),
                                callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
            self.status_bar.showMessage("Neural Network Training Complete")
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
    
    def create_neural_network(self):
        """Create neural network based on current configuration"""
        model = models.Sequential()
        
        # Add layers based on configuration
        for layer_config in self.layer_config:
            layer_type = layer_config["type"]
            params = layer_config["params"]
            
            if layer_type == "Dense":
                model.add(layers.Dense(**params))
            elif layer_type == "Conv2D":
                # Add input shape for the first layer
                if len(model.layers) == 0:
                    params['input_shape'] = self.X_train.shape[1:]
                model.add(layers.Conv2D(**params))
            elif layer_type == "MaxPooling2D":
                model.add(layers.MaxPooling2D())
            elif layer_type == "Flatten":
                model.add(layers.Flatten())
            elif layer_type == "Dropout":
                model.add(layers.Dropout(**params))
        
        # Add output layer based on number of classes
        num_classes = len(np.unique(self.y_train))
        model.add(layers.Dense(num_classes, activation='softmax'))
                
        return model

   
        
    def train_neural_network(self):
        """Train the neural network"""
        try:
            # Create and compile model
            model = self.create_neural_network()
            
            # Get training parameters
            batch_size = self.batch_size_spin.value()
            epochs = self.epochs_spin.value()
            learning_rate = self.lr_spin.value()
            
            # Compile model
            optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
            model.compile(optimizer=optimizer,
                        loss='categorical_crossentropy',
                        metrics=['accuracy'])
            
            # Train model
            history = model.fit(self.X_train, self.y_train,
                              batch_size=batch_size,
                              epochs=epochs,
                              validation_data=(self.X_test, self.y_test),
                              callbacks=[self.create_progress_callback()])
            
            # Update visualization with training history
            self.plot_training_history(history)
            
        except Exception as e:
            self.show_error(f"Error training neural network: {str(e)}")
            
    def create_progress_callback(self):
        """Create callback for updating progress bar during training"""
        class ProgressCallback(tf.keras.callbacks.Callback):
            def __init__(self, progress_bar):
                super().__init__()
                self.progress_bar = progress_bar
                
            def on_epoch_end(self, epoch, logs=None):
                progress = int(((epoch + 1) / self.params['epochs']) * 100)
                self.progress_bar.setValue(progress)
                
        return ProgressCallback(self.progress_bar)
        
    def update_visualization(self, y_pred):
        """Update the visualization with current results"""
        self.figure.clear()
        
        # Create appropriate visualization based on data
        if self.y_test.dtype.kind in "fc":  # Regression
            ax = self.figure.add_subplot(111)
            ax.scatter(self.y_test, y_pred)
            ax.plot([self.y_test.min(), self.y_test.max()],
                   [self.y_test.min(), self.y_test.max()],
                   'r--', lw=2)
            ax.set_xlabel("Actual Values")
            ax.set_ylabel("Predicted Values")
            
        else:  # Classification
            if self.X_train.shape[1] > 2:  # Use PCA for visualization
                from sklearn.decomposition import PCA
                pca = PCA(n_components=2)
                X_test_2d = pca.fit_transform(self.X_test)
                
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_test_2d[:, 0], X_test_2d[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
                
            else:  # Direct 2D visualization
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(self.X_test[:, 0], self.X_test[:, 1],
                                   c=y_pred, cmap='viridis')
                self.figure.colorbar(scatter)
        
        self.canvas.draw()
        
    def update_metrics(self, y_pred):
        """Update metrics display"""
        metrics_text = "Model Performance Metrics:\n\n"
        
        # Calculate appropriate metrics based on problem type
        if self.y_test.dtype.kind in "fc":  # Regression
            mse = mean_squared_error(self.y_test, y_pred)
            rmse = np.sqrt(mse)
            r2 = self.current_model.score(self.X_test, self.y_test)
            
            metrics_text += f"Mean Squared Error: {mse:.4f}\n"
            metrics_text += f"Root Mean Squared Error: {rmse:.4f}\n"
            metrics_text += f"R² Score: {r2:.4f}"
            
        else:  # Classification
            accuracy = accuracy_score(self.y_test, y_pred)
            conf_matrix = confusion_matrix(self.y_test, y_pred)
            
            metrics_text += f"Accuracy: {accuracy:.4f}\n\n"
            metrics_text += "Confusion Matrix:\n"
            metrics_text += str(conf_matrix)
        
        self.metrics_text.setText(metrics_text)
        
    def plot_training_history(self, history):
        """Plot neural network training history"""
        self.figure.clear()
        
        # Plot training & validation accuracy
        ax1 = self.figure.add_subplot(211)
        ax1.plot(history.history['accuracy'])
        ax1.plot(history.history['val_accuracy'])
        ax1.set_title('Model Accuracy')
        ax1.set_ylabel('Accuracy')
        ax1.set_xlabel('Epoch')
        ax1.legend(['Train', 'Test'])
        
        # Plot training & validation loss
        ax2 = self.figure.add_subplot(212)
        ax2.plot(history.history['loss'])
        ax2.plot(history.history['val_loss'])
        ax2.set_title('Model Loss')
        ax2.set_ylabel('Loss')
        ax2.set_xlabel('Epoch')
        ax2.legend(['Train', 'Test'])
        
        self.figure.tight_layout()
        self.canvas.draw()
        
    def show_error(self, message):
        """Show error message dialog"""
        QMessageBox.critical(self, "Error", message)
    def train_naive_bayes(self, smoothing_input):
        try:
            var_smoothing = smoothing_input.value()
            prior_type = self.nb_prior_combo.currentText()
            
            # Prior seçimi
            if prior_type == "Uniform":
                class_prior = None
            else:
                try:
                    prior_str = self.nb_prior_input.text()
                    class_prior = eval(prior_str)
                    
                    if not isinstance(class_prior, list) or not np.isclose(sum(class_prior), 1.0):
                        raise ValueError("Prior listesi geçersiz veya toplamı 1 değil.")
                except Exception as e:
                    self.show_error(f"Custom prior hatalı: {str(e)}")
                    return
            
            model = GaussianNB(var_smoothing=var_smoothing, priors=class_prior)

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            
            self.status_bar.showMessage("Gaussian Naive Bayes modeli eğitildi.")
        
        except Exception as e:
            self.show_error(f"Naive Bayes eğitimi sırasında hata: {str(e)}")

    def compare_missing_data_methods(self):
        try:
            # Yöntemler ve skorları sakla
            methods = ["Mean Imputation", "Interpolation", "Forward Fill", "Backward Fill"]
            scores = []
            for method in methods:
                # Veriyi sıfırla ve yeniden yükle
                dataset_name = self.dataset_combo.currentText()
                if dataset_name == "Breast Cancer Dataset":
                    data = datasets.load_breast_cancer()
                elif dataset_name == "Digits Dataset":
                    data = datasets.load_digits()
                else:
                    self.show_error("Bu karşılaştırma için desteklenen veri setleri: Breast Cancer, Digits")
                    return
                
                X, y = data.data.copy(), data.target.copy()
                # Eksik veri oluştur
                rng = np.random.default_rng(42)
                mask = rng.random(X.shape) < 0.1
                X[mask] = np.nan
                # Split
                test_size = self.split_spin.value()
                X_train, X_test, y_train, y_test = model_selection.train_test_split(
                    X, y, test_size=test_size, random_state=42
                )
                if method == "Mean Imputation":
                    from sklearn.impute import SimpleImputer
                    imputer = SimpleImputer(strategy="mean")
                elif method == "Interpolation":
                    X_train = pd.DataFrame(X_train).interpolate().values
                    X_test = pd.DataFrame(X_test).interpolate().values
                    imputer = None
                elif method == "Forward Fill":
                    X_train = pd.DataFrame(X_train).fillna(method="ffill").values
                    X_test = pd.DataFrame(X_test).fillna(method="ffill").values
                    imputer = None
                elif method == "Backward Fill":
                    X_train = pd.DataFrame(X_train).fillna(method="bfill").values
                    X_test = pd.DataFrame(X_test).fillna(method="bfill").values
                    imputer = None
                if imputer:
                    X_train = imputer.fit_transform(X_train)
                    X_test = imputer.transform(X_test)
            # Model eğit
                model = LogisticRegression(max_iter=200)
                model.fit(X_train, y_train)
                y_pred = model.predict(X_test)
                acc = accuracy_score(y_test, y_pred)
                scores.append(acc)    
        # Grafik çiz
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.bar(methods, scores)
            ax.set_title("Eksik Veri Yöntemleri vs Doğruluk")
            ax.set_ylabel("Accuracy")
            ax.set_ylim(0, 1)
            self.canvas.draw()
            self.status_bar.showMessage("Eksik veri yöntemleri başarıyla karşılaştırıldı.")
        except Exception as e:
            self.show_error(f"Karşılaştırma hatası: {str(e)}")
    
    def train_lda(self):
        try:
            n_components = self.lda_components_spin.value()
            from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
            lda = LinearDiscriminantAnalysis(n_components=n_components)

            X_proj = lda.fit_transform(self.X_train, self.y_train)
            X_test_proj = lda.transform(self.X_test)

            explained_var = lda.explained_variance_ratio_
            explained_var_total = explained_var.sum()

            if explained_var_total >= 0.95:
                quality_comment = "Excellent separation (≥95% variance explained)."
            elif explained_var_total >= 0.85:
                quality_comment = "Good separation (≥85% variance explained)."
            elif explained_var_total >= 0.70:
                quality_comment = "Fair separation (≥70% variance explained)."
            else:
                quality_comment = "Poor separation (<70% variance explained)."

            self.figure.clear()
            ax = self.figure.add_subplot(111)

            if X_test_proj.shape[1] >= 2:
                scatter = ax.scatter(X_test_proj[:, 0], X_test_proj[:, 1], c=self.y_test, cmap='viridis')
                ax.set_title("LDA Projection (2D)")
            else:
                scatter = ax.scatter(X_test_proj[:, 0], np.zeros_like(X_test_proj[:, 0]), c=self.y_test, cmap='viridis')
                ax.set_title("LDA Projection (1D)")

            self.figure.colorbar(scatter)
            self.canvas.draw()

            self.status_bar.showMessage("LDA uygulandı ve görselleştirildi")
            
            result = (
                "LDA Results:\n\n"
                "Dimensionality reduction completed.\n\n"
                f"Number of Components: {n_components}\n"
                f"Explained Variance Ratio: {explained_var[0]:.4f}\n\n"
                f"Interpretation:\n"
                f"- {quality_comment}\n"
                "Note: LDA assumes linear boundaries and normal distribution within classes."
            )

            self.metrics_text.setText(result)
            
        except Exception as e:
            self.show_error(f"LDA eğitimi sırasında hata: {str(e)}")


    def train_tsne(self):
        try:
            from sklearn.manifold import TSNE

            perplexity = self.tsne_perplexity.value()
            n_iter = self.tsne_iter.value()
            learning_rate = self.tsne_lr.value()

            tsne = TSNE(n_components=2, perplexity=perplexity,
                        n_iter=n_iter, learning_rate=learning_rate,
                        random_state=42)

            X_proj = tsne.fit_transform(self.X_test)

            # Görselleştir
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=self.y_test, cmap='viridis')
            ax.set_title("t-SNE Projection")
            self.figure.colorbar(scatter)
            self.canvas.draw()

            # ✅ SAĞ PANEL METNİ EKLİYORUZ
            result = (
                " t-SNE Results:\n\n"
                " Dimensionality reduction completed.\n\n"
                f"Parameters:\n"
                f"- Perplexity: {perplexity}\n"
                f"- Learning Rate: {learning_rate}\n"
                f"- Iterations: {n_iter}\n\n"
                " Visual inspection recommended for cluster separation.\n\n"
                "Note: t-SNE does not provide explained variance scores."
            )
            self.metrics_text.setText(result)

            self.status_bar.showMessage("t-SNE başarıyla uygulandı ve görselleştirildi.")

        except Exception as e:
            self.show_error(f"t-SNE işlemi sırasında hata oluştu: {str(e)}")

    def train_umap(self):
        try:
            import umap
            from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

            # Parametreleri al
            n_neighbors = self.umap_neighbors.value()
            min_dist = self.umap_min_dist.value()

            # UMAP çalıştır
            metric = self.umap_metric_combo.currentText()
            reducer = umap.UMAP(n_neighbors=n_neighbors, min_dist=min_dist, metric=metric, random_state=42)
            X_proj = reducer.fit_transform(self.X_test)

            # Görselleştir
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=self.y_test, cmap='viridis')
            ax.set_title("UMAP Projection")
            self.figure.colorbar(scatter)
            self.canvas.draw()

            # Metrikleri hesapla
            silhouette = silhouette_score(X_proj, self.y_test)
            db_index = davies_bouldin_score(X_proj, self.y_test)
            ch_index = calinski_harabasz_score(X_proj, self.y_test)

            # Silhouette yorumları
            if silhouette >= 0.71:
                sil_comment = "Excellent"
            elif silhouette >= 0.51:
                sil_comment = "Good"
            elif silhouette >= 0.26:
                sil_comment = "Fair"
            else:
                sil_comment = "Poor"

            # Davies-Bouldin yorumları
            if db_index <= 0.5:
                db_comment = "Excellent"
            elif db_index <= 1.0:
                db_comment = "Good"
            elif db_index <= 2.0:
                db_comment = "Fair"
            else:
                db_comment = "Poor"

            # Calinski-Harabasz yorumları
            if ch_index >= 1000:
                ch_comment = "Excellent"
            elif ch_index >= 500:
                ch_comment = "Good"
            elif ch_index >= 100:
                ch_comment = "Fair"
            else:
                ch_comment = "Poor"

            # Genel yorum
            comments = [sil_comment, db_comment, ch_comment]
            counts = {c: comments.count(c) for c in ["Excellent", "Good", "Fair", "Poor"]}

            if counts["Excellent"] >= 2:
                overall_comment = "Overall Quality: Excellent clustering detected."
            elif counts["Good"] >= 2:
                overall_comment = "Overall Quality: Good clustering."
            elif counts["Fair"] >= 2:
                overall_comment = "Overall Quality: Fair clustering."
            else:
                overall_comment = "Overall Quality: Poor clustering; consider parameter tuning."

            # Yan panele yazılacak metin
            result = (
                "UMAP Results:\n\n"
                "Dimensionality reduction completed.\n\n"
                f"Parameters:\n"
                f"- n_neighbors: {n_neighbors}\n"
                f"- min_dist: {min_dist}\n\n"
                "Cluster Quality Metrics:\n"
                f"- Silhouette Score: {silhouette:.4f} ({sil_comment})\n"
                f"- Davies-Bouldin Index: {db_index:.4f} ({db_comment})\n"
                f"- Calinski-Harabasz Index: {ch_index:.4f} ({ch_comment})\n\n"
                f"{overall_comment}\n\n"
                "Visual inspection recommended for interpretation.\n\n"
                "Note: UMAP does not provide explained variance scores."
            )

            self.metrics_text.setText(result)

            self.status_bar.showMessage("UMAP başarıyla uygulandı ve görselleştirildi.")

        except Exception as e:
            self.show_error(f"UMAP işlemi sırasında hata oluştu: {str(e)}")
    
    def plot_elbow_method(self):
        try:
            from sklearn.cluster import KMeans

            inertias = []
            K_range = range(1, 11)
            for k in K_range:
                kmeans = KMeans(n_clusters=k, random_state=42)
                kmeans.fit(self.X_train)
                inertias.append(kmeans.inertia_)

            self.figure.clear()
            ax = self.figure.add_subplot(111)
            ax.plot(K_range, inertias, marker='o')
            ax.set_title("Elbow Method for K-Means")
            ax.set_xlabel("Number of Clusters (k)")
            ax.set_ylabel("Inertia")
            self.canvas.draw()

            self.status_bar.showMessage("Elbow Method grafiği çizildi.")

        except Exception as e:
            self.show_error(f"Elbow Method çizilirken hata oluştu: {str(e)}")


    def train_pca(self):
        try:
            from sklearn.decomposition import PCA

            # Parametreleri al
            n_components = self.pca_components_spin.value()
            whiten = self.pca_whiten_checkbox.isChecked()
            print("Seçilen n_components:", n_components)


            # PCA'yı önce TRAIN verisinde fit et
            pca = PCA(n_components=n_components, whiten=whiten)
            print("Seçilen n_components:", n_components)

            pca.fit(self.X_train)

            # Test verisini dönüştür
            X_proj = pca.transform(self.X_test)

            self.figure.clear()

            # Bar grafiği çiz
            ax1 = self.figure.add_subplot(211)
            ax1.bar(range(1, len(pca.explained_variance_ratio_) + 1), pca.explained_variance_ratio_)
            ax1.set_title("Explained Variance Ratio by PCA Components")
            ax1.set_xlabel("Component")
            ax1.set_ylabel("Variance Ratio")

            # Scatter grafiği çiz
            # Scatter grafiği çiz (her zaman 2D, ilk 2 bileşene göre)
            if X_proj.shape[1] >= 2:
                if X_proj.shape[1] >= 3 and self.pca_proj_combo.currentText() == "3D":
                    from mpl_toolkits.mplot3d import Axes3D
                    ax2 = self.figure.add_subplot(212, projection='3d')
                    scatter = ax2.scatter(X_proj[:, 0], X_proj[:, 1], X_proj[:, 2], c=self.y_test, cmap='viridis')
                    ax2.set_title("PCA Projection (First 3 Components)")

                else:
                    ax2 = self.figure.add_subplot(212)
                    scatter = ax2.scatter(X_proj[:, 0], X_proj[:, 1], c=self.y_test, cmap='viridis')
                    ax2.set_title("PCA Projection (First 2 Components)")
                self.figure.colorbar(scatter, ax=ax2)

            # PCA yorum metni oluştur
            expl_var = pca.explained_variance_ratio_
            cumulative_var = np.cumsum(expl_var)[-1] * 100

            text = f"📊 PCA Results:\n\n"
            text += f"Number of Components: {n_components}\n"
            text += f"Explained Variance Ratio per Component: {np.round(expl_var,4)}\n"
            text += f"Total Explained Variance: {cumulative_var:.2f}%\n\n"

            if cumulative_var >= 95:
                text += "✅ Excellent: ≥95% variance explained.\n"
            elif cumulative_var >= 80:
                text += "👍 Good: ≥80% variance explained.\n"
            elif cumulative_var >= 60:
                text += "⚠️ Moderate: ≥60% variance explained.\n"
            else:
                text += "❌ Poor: <60% variance explained. Consider increasing n_components.\n"

            # Yan metin alanına yaz
            self.metrics_text.setText(text)
            self.figure.tight_layout()
            self.canvas.draw()
            self.status_bar.showMessage("PCA başarıyla uygulandı ve görselleştirildi.")

        except Exception as e:
            self.show_error(f"PCA işlemi sırasında hata oluştu: {str(e)}")
    
    def open_covariance_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Manual Covariance + Eigenvectors")
        layout = QVBoxLayout(dialog)

        label = QLabel("Enter 2D data rows (e.g., 1,2; 3,4; 5,6):")
        layout.addWidget(label)

        data_input = QLineEdit()
        data_input.setPlaceholderText("1,2; 3,4; 5,6")
        layout.addWidget(data_input)

        compute_btn = QPushButton("Compute and Show in Visualization")
        layout.addWidget(compute_btn)

        def compute():
            try:
                text = data_input.text()
                rows = [list(map(float, row.strip().split(","))) for row in text.split(";")]
                cov = np.array(rows)  # Kullanıcının verdiği matris doğrudan kovaryans

                eigvals, eigvecs = np.linalg.eig(cov)
                principal = eigvecs[:, np.argmax(eigvals)]

                # Simülasyon için rastgele veri oluştur
                X = np.random.multivariate_normal([0, 0], cov, size=100)
                X_proj = X @ principal

                result = (
                    f"Covariance Matrix (user input):\n{cov}\n\n"
                    f"Eigenvalues:\n{eigvals}\n\n"
                    f"Eigenvectors:\n{eigvecs}\n\n"
                    f"Principal Eigenvector:\n{principal}\n\n"
                    f"Projected Values:\n{X_proj}"
                )

                self.metrics_text.setText(result)

                self.figure.clear()
                ax = self.figure.add_subplot(111)
                ax.scatter(X_proj, np.zeros_like(X_proj), alpha=0.5)
                ax.set_title("1D Projection Using Principal Eigenvector")
                self.canvas.draw()

                self.status_bar.showMessage("1D projection (manual covariance) complete.")

            except Exception as e:
                self.show_error(f"Error: {str(e)}")
        
        compute_btn.clicked.connect(compute)
        dialog.exec()
    
    def train_kmeans(self):
        print("[train_kmeans] Butondan çağrıldı.")
        try:
            kfold_metrics_text = ""
            scores = []
            mse_scores = []
            rmse_scores = []
            fold_sizes = []
            if self.kfold_checkbox.isChecked():
                from sklearn.model_selection import StratifiedKFold
                from scipy.stats import mode
                from sklearn.cluster import KMeans
                from sklearn.metrics import accuracy_score

                if self.y_train is None:
                    self.show_error("K-Fold için label'lı veri gerekir!")
                    return

                k = self.kfold_spin.value()
                skf = StratifiedKFold(n_splits=k, shuffle=True, random_state=42)

                scores = []
                fold_sizes = []
                for train_idx, test_idx in skf.split(self.X_train, self.y_train):
                    X_tr, X_te = self.X_train[train_idx], self.X_train[test_idx]
                    y_tr, y_te = self.y_train[train_idx], self.y_train[test_idx]

                    kmeans = KMeans(n_clusters=len(np.unique(y_tr)), random_state=42)
                    kmeans.fit(X_tr)
                    y_pred = kmeans.predict(X_te)

                    labels = np.zeros_like(y_pred)
                    for i in range(len(np.unique(kmeans.labels_))):
                        mask = (y_pred == i)
                        if np.any(mask):
                            labels[mask] = mode(y_te[mask])[0]

                    acc = accuracy_score(y_te, labels)
                    scores.append(acc)
                    fold_sizes.append(len(test_idx))
                    from sklearn.metrics import mean_squared_error

                    mse = mean_squared_error(y_te, labels)
                    rmse = np.sqrt(mse)

                    mse_scores.append(mse)
                    rmse_scores.append(rmse)
                mean_acc = np.mean(scores)
                std_acc = np.std(scores)
                mean_mse = np.mean(mse_scores)
                std_mse = np.std(mse_scores)
                mean_rmse = np.mean(rmse_scores)
                std_rmse = np.std(rmse_scores)
                kfold_metrics_text=(
                    f"K-Fold Cross-Validation (k={k})\n"
                    f"Fold Sizes: {fold_sizes}\n"
                    f"Fold Accuracies: {scores}\n"
                    f"Mean Accuracy: {mean_acc:.4f}\n"
                    f"Std Dev: {std_acc:.4f}\n"
                    f"MSE per Fold: {', '.join(f'{val:.4f}' for val in mse_scores)}\n"
                    f"RMSE per Fold: {', '.join(f'{val:.4f}' for val in rmse_scores)}\n"
                    f"Mean MSE: {mean_mse:.4f}\n"
                    f"Std MSE: {std_mse:.4f}\n"
                    f"Mean RMSE: {mean_rmse:.4f}\n"
                    f"Std RMSE: {std_rmse:.4f}\n"
                )
                self.status_bar.showMessage(f"KMeans evaluated with K-Fold (mean acc = {mean_acc:.4f})")
                

                # → normal train_kmeans kodları aşağıda kalıyor
            from sklearn.cluster import KMeans
            from sklearn.decomposition import PCA
            from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

            # Parametreleri al
            n_clusters = self.kmeans_n_clusters.value()
            max_iter = self.kmeans_max_iter.value()
            n_init = self.kmeans_n_init.value()

            print(f"[K-Means] Parametreler: n_clusters={n_clusters}, max_iter={max_iter}, n_init={n_init}")

            # KMeans modelini eğit
            kmeans = KMeans(n_clusters=n_clusters, max_iter=max_iter, n_init=n_init, random_state=42)
            kmeans.fit(self.X_train)
            labels = kmeans.predict(self.X_test)

            # PCA ile 2D'ye indirgeme
            pca = PCA(n_components=2)
            X_proj = pca.fit_transform(self.X_test)

            # Görselleştirme
            self.figure.clear()
            ax = self.figure.add_subplot(111)
            scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=labels, cmap='viridis')
            ax.set_title(f"K-Means Clustering (k={n_clusters}) in PCA Space")
            self.figure.colorbar(scatter)
            self.canvas.draw()

            import plotly.express as px

            fig = px.scatter(
                x=X_proj[:, 0],
                y=X_proj[:, 1],
                color=labels.astype(str),
                title=f"K-Means Clustering (k={n_clusters}) in PCA Space (Plotly)"
            )

            fig.show()
            self.status_bar.showMessage("Plotly PCA visualization displayed.")

            # METRİKLERİ HESAPLA
            silhouette = silhouette_score(self.X_test, labels)
            davies_bouldin = davies_bouldin_score(self.X_test, labels)
            calinski_harabasz = calinski_harabasz_score(self.X_test, labels)

            # Silhouette yorumu
            if silhouette >= 0.71:
                sil_comment = "Excellent"
            elif silhouette >= 0.51:
                sil_comment = "Good"
            elif silhouette >= 0.26:
                sil_comment = "Fair"
            else:
                sil_comment = "Poor"

            # Davies-Bouldin yorumu (küçük daha iyi)
            if davies_bouldin <= 0.5:
                db_comment = "Excellent"
            elif davies_bouldin <= 1.0:
                db_comment = "Good"
            elif davies_bouldin <= 2.0:
                db_comment = "Fair"
            else:
                db_comment = "Poor"

            # Calinski-Harabasz yorumu (büyük daha iyi)
            if calinski_harabasz >= 1000:
                ch_comment = "Excellent"
            elif calinski_harabasz >= 500:
                ch_comment = "Good"
            elif calinski_harabasz >= 100:
                ch_comment = "Fair"
            else:
                ch_comment = "Poor"

            # Genel kalite yorumu
            comments = [sil_comment, db_comment, ch_comment]
            counts = {c: comments.count(c) for c in ["Excellent", "Good", "Fair", "Poor"]}

            if counts["Excellent"] >= 2:
                overall_comment = "Overall Quality: Excellent clustering detected."
            elif counts["Good"] >= 2:
                overall_comment = "Overall Quality: Good clustering with well-separated clusters."
            elif counts["Fair"] >= 2:
                overall_comment = "Overall Quality: Acceptable clustering, but could be improved."
            else:
                overall_comment = "Overall Quality: Poor clustering; consider tuning parameters."

                # Sonucu yan panelde göster
            metrics_text = (
                f"Cluster Quality Metrics:\n\n"
                f"Silhouette Score: {silhouette:.4f} ({sil_comment})\n"
                f"Davies-Bouldin Index: {davies_bouldin:.4f} ({db_comment})\n"
                f"Calinski-Harabasz Index: {calinski_harabasz:.4f} ({ch_comment})\n\n"
                f"{overall_comment}"
            )
            final_metrics_text = kfold_metrics_text + metrics_text
            self.metrics_text.setText(final_metrics_text)

            self.status_bar.showMessage(f"K-Means clustering evaluated. {overall_comment}")

        except Exception as e:
            self.show_error(f"K-Means eğitimi sırasında hata oluştu: {str(e)}")




    def train_model(self, model_name, param_widgets):
        try:
            params = {}
            for param_name, widget in param_widgets.items():
                if isinstance(widget, QSpinBox) or isinstance(widget, QDoubleSpinBox):
                    params[param_name] = widget.value()
                elif isinstance(widget, QCheckBox):
                    params[param_name] = widget.isChecked()
                elif isinstance(widget, QComboBox):
                    params[param_name] = widget.currentText()

            if model_name == "Linear Regression":
                from sklearn.metrics import mean_absolute_error
                model = LinearRegression(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
            elif model_name == "Support Vector Regression":
                model = SVR(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    from sklearn.metrics import mean_absolute_error
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
                self.current_model = model
                self.update_metrics(y_pred)
                self.update_visualization(y_pred)
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
                
            elif model_name == "Logistic Regression":
                model = LogisticRegression(**params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                try:
                    if hasattr(model, "predict_proba"):
                        y_pred_proba = model.predict_proba(self.X_test)
                        loss = log_loss(self.y_test, y_pred_proba)
                        loss_type = "Cross-Entropy"
                    else:
                        raise ValueError("Model predict_proba desteği vermiyor.")
                except Exception as e:
                    self.show_error(f"Cross-Entropy hesaplanamadı: {str(e)}")
                    return
                self.current_model = model
                self.update_metrics(y_pred)
                self.update_visualization(y_pred)
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
            elif model_name == "Support Vector Machine":
                model = SVC(probability = True, **params)
                model.fit(self.X_train, self.y_train)
                y_pred = model.predict(self.X_test)
                loss_type = self.classification_loss_combo.currentText()
                if loss_type == "Cross-Entropy":
                    if hasattr(model, "predict_proba"):
                        y_pred_proba = model.predict_proba(self.X_test)
                    elif hasattr(model, "decision_function"):
                        scores = model.decision_function(self.X_test)
                        y_pred_proba = np.exp(scores) / np.sum(np.exp(scores), axis=1, keepdims=True)
                    else:
                        try:
                            y_pred_proba = model.predict_proba(self.X_Test)
                        except Exception:
                            raise ValueError("Modelden olasılık alınamıyor.")
                        loss = log_loss(self.y_test, y_pred_proba)

                elif loss_type == "Hinge":
                    if hasattr(model, "decision_function"):
                        scores = model.decision_function(self.X_test)
                    else:
                        raise ValueError("Model decision_function desteği vermiyor.")
                    classes = np.unique(self.y_test)
                    y_true = label_binarize(self.y_test, classes=classes)
                    loss = hinge_loss(y_true, scores)
            elif model_name == "K-Means":
                from sklearn.cluster import KMeans
                model = KMeans(**params, random_state=42)
                model.fit(self.X_train)
                y_pred = model.predict(self.X_test)

                # PCA ile görselleştirme (X_test üzerinde)
                from sklearn.decomposition import PCA
                pca = PCA(n_components=2)
                X_proj = pca.fit_transform(self.X_test)

                self.figure.clear()
                ax = self.figure.add_subplot(111)
                scatter = ax.scatter(X_proj[:, 0], X_proj[:, 1], c=y_pred, cmap='tab10')
                ax.set_title("K-Means Clustering (PCA 2D)")
                self.figure.colorbar(scatter)
                self.canvas.draw()

                self.status_bar.showMessage("K-Means modeli eğitildi ve görselleştirildi.")
        
            else:
                self.show_error(f"Unsupported model: {model_name}")
                return
            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            if 'loss_type' in locals() and 'loss' in locals():
                self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")
            else:
                self.status_bar.showMessage(f"{model_name} trained successfully.")
        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")
            model.fit(self.X_train, self.y_train)
            y_pred = model.predict(self.X_test)
            if np.issubdtype(self.y_test.dtype, np.floating):  # Regression
                loss_type = self.regression_loss_combo.currentText()
                if loss_type == "MSE":
                    loss = mean_squared_error(self.y_test, y_pred)
                elif loss_type == "MAE":
                    loss = mean_absolute_error(self.y_test, y_pred)
                elif loss_type == "Huber":
                    delta = 1.0
                    error = self.y_test - y_pred
                    loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()
            else:  # Classification
                loss_type = self.classification_loss_combo.currentText()

                if loss_type == "Cross-Entropy":
                    try:
                        if hasattr(model, "predict_proba"):
                            y_pred_proba = model.predict_proba(self.X_test)
                        elif hasattr(model, "decision_function"):
                            scores = model.decision_function(self.X_test)
                            y_pred_proba = np.exp(scores) / np.sum(np.exp(scores), axis=1, keepdims=True)
                        else:
                            raise ValueError("Modelden olasılık alınamıyor.")

                        loss = log_loss(self.y_test, y_pred_proba)
                    except Exception as e:
                        self.show_error(f"Cross-Entropy hesaplanamadı: {str(e)}")
                        return

                elif loss_type == "Hinge":
                    try:
                        if hasattr(model, "decision_function"):
                            scores = model.decision_function(self.X_test)
                        else:
                            raise ValueError("Model decision_function desteği vermiyor.")

                        classes = np.unique(self.y_test)
                        y_true = label_binarize(self.y_test, classes=classes)
                        loss = hinge_loss(y_true, scores)
                    except Exception as e:
                        self.show_error(f"Hinge loss hesaplanamadı: {str(e)}")
                        return

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")

            loss_type = self.regression_loss_combo.currentText()
            if loss_type == "MSE":
                loss = mean_squared_error(self.y_test, y_pred)
            elif loss_type == "MAE":
                loss = mean_absolute_error(self.y_test, y_pred)
            elif loss_type == "Huber":
                delta = 1.0
                error = self.y_test - y_pred
                loss = np.where(np.abs(error) < delta,
                                0.5 * error ** 2,
                                delta * (np.abs(error) - 0.5 * delta)).mean()

            self.current_model = model
            self.update_metrics(y_pred)
            self.update_visualization(y_pred)
            self.status_bar.showMessage(f"{model_name} trained. {loss_type} = {loss:.4f}")

        except Exception as e:
            self.show_error(f"Error training {model_name}: {str(e)}")
    
    def load_boston_housing_dataset(self):
        try:
            data_url = "http://lib.stat.cmu.edu/datasets/boston"
            raw_df = pd.read_csv(data_url, sep="\s+", skiprows=22, header=None)
            X = np.hstack([raw_df.values[::2, :], raw_df.values[1::2, 1:]])
            y = raw_df.values[1::2, 0]

            test_size = self.split_spin.value()
            self.X_train, self.X_test, self.y_train, self.y_test = \
            model_selection.train_test_split(X, y, test_size=test_size, random_state=42)

            self.apply_scaling()
            self.status_bar.showMessage("Loaded Boston Housing Dataset")

        except Exception as e:
            self.show_error(f"Error loading Boston Housing Dataset: {str(e)}")

def main():
    """Main function to start the application"""
    app = QApplication(sys.argv)
    window = MLCourseGUI()
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()