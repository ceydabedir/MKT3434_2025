# MKT 3434 MACHINE LEARNING HOMEWORK ASSIGNMENT - 3

Run the following command to install the missing dependencies (to avoid import errors or warnings)!!

pip install umap-learn plotly PyQtWebEngine scipy

This is a multi-functional machine learning GUI developed with PyQt6.  
It includes classical machine learning algorithms, dimensionality reduction, and deep learning models such as MLP, CNN, and RNN with full architecture configuration and training capabilities.

## Implemented Features

- **Deep Learning**:
  - **MLP (Multi-Layer Perceptron)**:
    - Customizable layer structure: add multiple dense layers with user-defined neuron sizes.
    - Supports ReLU, Sigmoid, Tanh activation functions.
    - Training parameters (batch size, learning rate, optimizer, epochs) fully configurable via GUI.
  
  - **CNN (Convolutional Neural Network)**:
    - Layer types supported: Conv2D, MaxPooling2D, Dropout, Flatten.
    - Dynamic layer addition: users can define filter size, kernel size, padding, activation, etc.
    - GUI displays the CNN architecture summary textually as layers are added.
    - Includes a button to clear the CNN architecture and reconfigure it from scratch.
  
  - **RNN (Recurrent Neural Network)**:
    - LSTM and GRU layers can be added for sequence or time-series data modeling.
    - Number of units and activation functions customizable per layer.
    - Compatible with reshaped 3D input data required for RNNs.

  - **Training & Monitoring Enhancements**:
    - Training logs (loss, accuracy, val_loss, val_accuracy, learning rate) are displayed live in the GUI for each epoch.
    - Training curves (loss & accuracy over epochs) are plotted after training.
    - Gradient histogram visualization is provided for weight updates.
    - Early stopping is supported to prevent overfitting.
    - Learning rate scheduling options (Step Decay, Exponential Decay) available.
  
  - **Model Persistence**:
    - Trained models can be saved in `.h5` format (weights) and `.json` format (architecture).
    - Saved models can be loaded back into the GUI for evaluation or continued training.


Ceyda BEDİR - 22067051 